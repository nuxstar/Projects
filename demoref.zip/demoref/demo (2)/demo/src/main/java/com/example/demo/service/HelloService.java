package com.example.demo.service;

import com.example.demo.repository.HelloRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class HelloService {

    @Autowired
    private HelloRepo repo;

    public boolean confirm (String s) {
        return Objects.nonNull(repo.getData(s));
    }
}
