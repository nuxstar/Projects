package com.example.demo.repository;

import org.springframework.stereotype.Component;

@Component
public class HelloRepo {

    public String getData(String s) {
        String res = "Hello World" + s;
        return res;
    }
}
