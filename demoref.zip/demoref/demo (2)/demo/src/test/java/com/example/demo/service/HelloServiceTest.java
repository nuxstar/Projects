package com.example.demo.service;

import com.example.demo.repository.HelloRepo;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.junit.jupiter.api.Assertions.*;

@SpringJUnitConfig
class HelloServiceTest {

    @InjectMocks
    HelloService service;

    @Mock
    HelloRepo repo;

    @Test
    void confirm() {
        Mockito.when(repo.getData(Mockito.anyString())).thenReturn("hello");
        var res = service.confirm("test");
        assertEquals(true, res);
    }
}