package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * The UserRepository
 */
public interface UserRepository extends JpaRepository<User,Integer> {
}
