package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Like entity
 */
@Entity
@Data
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorColumn(name = "like_type")
public abstract class Likes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "likeId", nullable = false)
    private int likeId;
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn
    private User user;
}
