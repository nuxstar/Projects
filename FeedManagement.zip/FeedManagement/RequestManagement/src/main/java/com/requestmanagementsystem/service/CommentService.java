package com.requestmanagementsystem.service;

import com.requestmanagementsystem.dto.CommentDto;


public interface CommentService {
    /**
     * Add UserComments details
     * @param  commentDto
     * @return Comment details
     */
    CommentDto addComment(int userId,int ticketId,CommentDto commentDto);
    Boolean deleteComment(int commentId);
}
