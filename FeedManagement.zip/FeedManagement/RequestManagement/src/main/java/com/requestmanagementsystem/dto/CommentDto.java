package com.requestmanagementsystem.dto;

import com.requestmanagementsystem.entity.Ticket;
import com.requestmanagementsystem.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * The Comment entity
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentDto {

    private int commentId;
    private int commentLikeCount;
    private String commentDescription;
    private User user;
    private Ticket ticket;
}
