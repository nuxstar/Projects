package com.requestmanagementsystem.service;

import com.requestmanagementsystem.dto.TicketDto;

public interface TicketService {
    /**
     * Add User details
     * @param ticketDto UserDto
     * @return Ticket details
     */
    TicketDto addTicket(int userId,TicketDto ticketDto);
    /**
     * Delete Ticket details.
     *
     * @param  ticketId
     * @return Boolean
     */
    Boolean deleteTicket(int ticketId);
}
