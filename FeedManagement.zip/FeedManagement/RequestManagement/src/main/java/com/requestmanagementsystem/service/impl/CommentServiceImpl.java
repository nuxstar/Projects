package com.requestmanagementsystem.service.impl;

import com.requestmanagementsystem.dto.CommentDto;
import com.requestmanagementsystem.entity.Comment;
import com.requestmanagementsystem.entity.Ticket;
import com.requestmanagementsystem.entity.User;
import com.requestmanagementsystem.exception.NotFoundException;
import com.requestmanagementsystem.repository.CommentRepository;
import com.requestmanagementsystem.repository.TicketRepository;
import com.requestmanagementsystem.repository.UserRepository;
import com.requestmanagementsystem.service.CommentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentServiceImpl implements CommentService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    CommentRepository commentRepository;
    @Autowired
    TicketRepository ticketRepository;
    @Autowired
    ModelMapper modelMapper;
    @Override
    public CommentDto addComment(int userId,int ticketId, CommentDto commentDto) {
        userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepository.findById(userId).get();
        ticketRepository.findById(ticketId).orElseThrow(()-> new NotFoundException("Ticket not found..."));
        Ticket ticket = ticketRepository.findById(ticketId).get();
        Comment commentRequest = modelMapper.map(commentDto, Comment.class);
        commentRequest.setUser(user);
        commentRequest.setTicket(ticket);
        Comment commentResponse = commentRepository.save(commentRequest);
        return modelMapper.map(commentResponse, CommentDto.class);
    }

    @Override
    public Boolean deleteComment(int commentId) {
        Comment comment = commentRepository.findById(commentId).orElseThrow(() -> new NotFoundException("Ticket Does Not Exist"));
        commentRepository.deleteById(commentId);
        return true;
    }
}
