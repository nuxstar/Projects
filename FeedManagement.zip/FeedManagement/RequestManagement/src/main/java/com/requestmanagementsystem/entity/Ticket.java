package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Ticket entity
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ticketId", nullable = false)
    private int ticketId;
    private String ticketTitle;
    private String ticketDescription;
    private int ticketLikeCount;
    @Enumerated(EnumType.STRING)
    private PriorityLevel priorityLevel;
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn
    private User user;
    @OneToMany(mappedBy = "ticket", orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE})
    private List<Comment> comments;


}
