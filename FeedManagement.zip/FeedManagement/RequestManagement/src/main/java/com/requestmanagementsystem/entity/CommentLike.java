package com.requestmanagementsystem.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue(value = "comment")
public class CommentLike extends Likes {
    @ManyToOne()
    @JoinColumn
    private Comment comment;


}