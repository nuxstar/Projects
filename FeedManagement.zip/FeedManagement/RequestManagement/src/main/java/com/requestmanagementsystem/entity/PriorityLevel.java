package com.requestmanagementsystem.entity;
/**
 * The PriorityLevel entity
 */
public enum PriorityLevel {
   CRITICAL,
    HIGH,
    NORMAL;

}
