package com.requestmanagementsystem.service.impl;

import com.requestmanagementsystem.dto.UserDto;
import com.requestmanagementsystem.entity.User;
import com.requestmanagementsystem.repository.UserRepository;
import com.requestmanagementsystem.service.UserService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    ModelMapper modelMapper;
    @Override
    public UserDto addUser(UserDto userDto) {
        User user = modelMapper.map(userDto, User.class);
        User userDetails = userRepository.save(user);
        return modelMapper.map(userDetails, UserDto.class);
    }
}
