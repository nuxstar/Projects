package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Comment entity
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "commentId", nullable = false)
    private int commentId;
    private int commentLikeCount;
    private String commentDescription;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private User user;
    @ManyToOne()
    @JoinColumn
    private Ticket ticket;
    @OneToMany(mappedBy = "comment", orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE})
    private List<CommentLike>commentLikes;


}
