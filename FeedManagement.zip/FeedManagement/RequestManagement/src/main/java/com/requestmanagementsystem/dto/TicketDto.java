package com.requestmanagementsystem.dto;

import com.requestmanagementsystem.entity.Comment;
import com.requestmanagementsystem.entity.PriorityLevel;
import com.requestmanagementsystem.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The TicketDto entity
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TicketDto {

    private int ticketId;
    private String ticketTitle;
    private String ticketDescription;
    private int ticketLikeCount;
    private PriorityLevel priorityLevel;
    private User user;
    private List<Comment> comments;
}
