package com.requestmanagementsystem.dto;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The LikeDto entity
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LikesPostDto {

    private int userId;
    private int entityId;
    private String likeType;
}
