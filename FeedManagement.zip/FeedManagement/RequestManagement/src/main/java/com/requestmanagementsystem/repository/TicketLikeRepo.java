package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.TicketLike;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketLikeRepo extends JpaRepository<TicketLike,Integer> {
}
