package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * The CommentRepository
 */
public interface CommentRepository extends JpaRepository<Comment,Integer> {

}
