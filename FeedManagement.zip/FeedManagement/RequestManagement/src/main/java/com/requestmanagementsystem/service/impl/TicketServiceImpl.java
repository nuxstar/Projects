package com.requestmanagementsystem.service.impl;

import com.requestmanagementsystem.dto.TicketDto;
import com.requestmanagementsystem.entity.Comment;
import com.requestmanagementsystem.entity.Ticket;
import com.requestmanagementsystem.entity.User;
import com.requestmanagementsystem.exception.NotFoundException;
import com.requestmanagementsystem.repository.CommentRepository;
import com.requestmanagementsystem.repository.TicketRepository;
import com.requestmanagementsystem.repository.UserRepository;
import com.requestmanagementsystem.service.TicketService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TicketServiceImpl implements TicketService {
    @Autowired
    TicketRepository ticketRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ModelMapper modelMapper;

    @Override
    public TicketDto addTicket(int userId, TicketDto ticketDto) {
        userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepository.findById(userId).get();
        Ticket ticketRequest = modelMapper.map(ticketDto, Ticket.class);
        ticketRequest.setUser(user);
        Ticket ticketResponse = ticketRepository.save(ticketRequest);
        return modelMapper.map(ticketResponse, TicketDto.class);
    }

    @Override
    public Boolean deleteTicket(int ticketId) {

        Ticket ticket = ticketRepository.findById(ticketId).orElseThrow(() -> new NotFoundException("Ticket Does Not Exist"));
//        Optional<Comment> comment =  commentRepository.findById(ticketId);
//        commentRepository.deleteAll((Iterable<? extends Comment>) comment.get());
        ticketRepository.deleteById(ticketId);
        return true;
    }
}
