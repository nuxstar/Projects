package com.requestmanagementsystem.controller;

import com.requestmanagementsystem.dto.LikesDto;
import com.requestmanagementsystem.dto.LikesPostDto;
import com.requestmanagementsystem.service.LikesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LikesController {

    @Autowired
    LikesService likesService;

    @PostMapping("like")
    public LikesDto addLike(@RequestBody LikesPostDto likesPostDto){
     return likesService.addLike(likesPostDto);
    }
}
