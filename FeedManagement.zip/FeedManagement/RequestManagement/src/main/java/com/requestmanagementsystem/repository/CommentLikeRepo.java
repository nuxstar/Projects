package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.CommentLike;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentLikeRepo extends JpaRepository<CommentLike,Integer> {
}
