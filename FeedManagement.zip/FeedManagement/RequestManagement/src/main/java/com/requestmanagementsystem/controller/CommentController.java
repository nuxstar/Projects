package com.requestmanagementsystem.controller;

import com.requestmanagementsystem.dto.CommentDto;
import com.requestmanagementsystem.dto.TicketDto;
import com.requestmanagementsystem.service.CommentService;
import com.requestmanagementsystem.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The CommentController
 */
@RestController
public class CommentController  {
    @Autowired
    CommentService commentService;
    @PostMapping("Comment/{userId}/{ticketId}")
    public CommentDto addComment(@PathVariable("userId") int userId, @PathVariable("ticketId") int ticketId, @RequestBody CommentDto commentDto ){
        return commentService.addComment(userId,ticketId,commentDto);
    }
    @DeleteMapping("comment/{commentId}")
    public Boolean deleteTicket(@PathVariable int commentId) {

        return commentService.deleteComment(commentId);
    }
}
