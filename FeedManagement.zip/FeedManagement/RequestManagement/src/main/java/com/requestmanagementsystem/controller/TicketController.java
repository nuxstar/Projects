package com.requestmanagementsystem.controller;

import com.requestmanagementsystem.dto.TicketDto;
import com.requestmanagementsystem.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The TicketController
 */
@RestController
public class TicketController {
    @Autowired
    TicketService ticketService;
    @PostMapping("ticket/{userId}")
    public TicketDto addTicket(@PathVariable int userId,@RequestBody TicketDto ticketDto ){
return ticketService.addTicket(userId,ticketDto);
    }
    @DeleteMapping("ticket/{ticketId}")
    public Boolean deleteTicket(@PathVariable int ticketId) {

        return ticketService.deleteTicket(ticketId);
    }
}
