package com.requestmanagementsystem.service;


import com.requestmanagementsystem.dto.LikesDto;
import com.requestmanagementsystem.dto.LikesPostDto;

public interface LikesService {
    LikesDto addLike(LikesPostDto likesPostDto);
}
