package com.requestmanagementsystem.service.impl;

import com.requestmanagementsystem.dto.LikesDto;
import com.requestmanagementsystem.dto.LikesPostDto;
import com.requestmanagementsystem.entity.*;
import com.requestmanagementsystem.exception.NotFoundException;
import com.requestmanagementsystem.repository.*;
import com.requestmanagementsystem.service.LikesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LikesServiceImpl implements LikesService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    CommentRepository commentRepository;
    @Autowired
    TicketLikeRepo ticketLikeRepo;
    @Autowired
    TicketRepository ticketRepository;

    @Autowired
    CommentLikeRepo commentLikeRepo;

    @Override
    public LikesDto addLike(LikesPostDto likesPostDto) {
        userRepository.findById(likesPostDto.getUserId()).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepository.findById(likesPostDto.getUserId()).get();

        if (likesPostDto.getLikeType().contains("ticket")) {
            ticketRepository.findById(likesPostDto.getEntityId()).orElseThrow(() -> new NotFoundException("Ticket not found..."));
            Optional<Ticket> ticket = ticketRepository.findById(likesPostDto.getEntityId());
            Ticket ticketDetails = ticket.get();
            int actualCount = ticketDetails.getTicketLikeCount();
            actualCount++;
            ticketDetails.setTicketLikeCount(actualCount);
            TicketLike  t = new TicketLike();
            t.setUser(user);
            t.setTicket(ticketDetails);
            ticketLikeRepo.save(t);
            LikesDto likesDto = new LikesDto();
            likesDto.setUser(user);
            likesDto.setTicket(t.getTicket());
            return likesDto;

        } else {
            commentRepository.findById(likesPostDto.getEntityId()).orElseThrow(() -> new NotFoundException("Comment not found..."));
            Optional<Comment> comment = commentRepository.findById(likesPostDto.getEntityId());
            Comment commentDetails = comment.get();
            int actualCount = commentDetails.getCommentLikeCount();
            actualCount++;
            commentDetails.setCommentLikeCount(actualCount);
            CommentLike like  = new CommentLike();
            like.setUser(user);
            like.setComment(commentDetails);
            commentLikeRepo.save(like);
            LikesDto likesDto = new LikesDto();
            likesDto.setUser(user);
            likesDto.setComment(like.getComment());
            return likesDto;
        }

    }
}
