package com.flyerssoft.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectAllotmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
