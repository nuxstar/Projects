package com.flyerssoft.com.ProjectAllotment.controller.advice;


import com.flyerssoft.com.ProjectAllotment.exception.ApiError;
import com.flyerssoft.com.ProjectAllotment.exception.AppException;
import com.flyerssoft.com.ProjectAllotment.exception.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.Objects;

@RestControllerAdvice
public class AppErrorController {

    @ExceptionHandler(NotFoundException.class)
    public ApiError handleEntityNotFound(AppException ex) {
        ApiError apiError = new ApiError(HttpStatus.NOT_FOUND);
        apiError.setMessage(ex.getMessage());
        apiError.setTimestamp(LocalDateTime.now());
        return apiError;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ApiError customValidation(MethodArgumentNotValidException e){
        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
        apiError.setMessage(Objects.requireNonNull(e.getBindingResult().getFieldError()).getDefaultMessage());
        apiError.setTimestamp(LocalDateTime.now());
        return  apiError;
    }

}
