package com.flyerssoft.com.ProjectAllotment.service.impl;

import com.flyerssoft.com.ProjectAllotment.config.ModelMapperConfig;
import com.flyerssoft.com.ProjectAllotment.dto.ProjectDto;
import com.flyerssoft.com.ProjectAllotment.entity.Client;
import com.flyerssoft.com.ProjectAllotment.entity.Employee;
import com.flyerssoft.com.ProjectAllotment.entity.Project;
import com.flyerssoft.com.ProjectAllotment.exception.NotFoundException;
import com.flyerssoft.com.ProjectAllotment.repository.ClientRepo;
import com.flyerssoft.com.ProjectAllotment.repository.EmployeeRepo;
import com.flyerssoft.com.ProjectAllotment.repository.ProjectRepo;
import com.flyerssoft.com.ProjectAllotment.service.ProjectService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    ClientRepo clientRepo;
    @Autowired
    ProjectRepo projectRepo;

    @Autowired
    EmployeeRepo employeeRepo;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public ProjectDto addProject(int clientId, Project project) {

        Client client = clientRepo.findById(clientId).orElseThrow(()-> new NotFoundException("Client Not Found"));

        List<Project> projects = Objects.nonNull(client.getProjects()) ? client.getProjects() : new ArrayList<>();
        projects.add(project);
        client.setProjects(projects);
        if (Objects.nonNull(project.getEmployees())){
            int count=0;
            for (Employee employeeList:project.getEmployees()) {
                count++;
            }
            project.setEmployeeCount(count);
        }
        Project project1 =  projectRepo.save(project);
        return modelMapper.map(project1,ProjectDto.class);
    }

    @Override
    public Project getProject(int projectId) {

        return projectRepo.findById(projectId).orElseThrow(()->new NotFoundException("Project Not Found Exception"));
    }

    @Override
    public List<Project> getAllProject() {
        return projectRepo.findAll();
    }
}
