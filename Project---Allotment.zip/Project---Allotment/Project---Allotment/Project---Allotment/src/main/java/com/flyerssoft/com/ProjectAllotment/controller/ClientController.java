package com.flyerssoft.com.ProjectAllotment.controller;

import com.flyerssoft.com.ProjectAllotment.dto.ClientDto;
import com.flyerssoft.com.ProjectAllotment.entity.Client;
import com.flyerssoft.com.ProjectAllotment.service.impl.ClientServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * The client controller
 */
@RestController
public class ClientController {

    Logger logger = LoggerFactory.getLogger(ClientController.class);

    @Autowired
    ClientServiceImpl clientService;

    @PostMapping("/client")
    public ClientDto addClient(@RequestBody Client client) {
        logger.info("ADD Client Method Accessed.........");
        logger.info("ADD Client Method Closed...........");
        ClientDto dto = clientService.addClient(client);
        logger.info("ADD Client Method Closed...........");
        return dto;
    }
}
