package com.flyerssoft.com.ProjectAllotment.service.impl;

import com.flyerssoft.com.ProjectAllotment.config.ModelMapperConfig;
import com.flyerssoft.com.ProjectAllotment.dto.EmployeeDto;
import com.flyerssoft.com.ProjectAllotment.entity.Employee;
import com.flyerssoft.com.ProjectAllotment.entity.Project;
import com.flyerssoft.com.ProjectAllotment.exception.NotFoundException;
import com.flyerssoft.com.ProjectAllotment.repository.EmployeeRepo;
import com.flyerssoft.com.ProjectAllotment.repository.ProjectRepo;
import com.flyerssoft.com.ProjectAllotment.service.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    ProjectRepo projectRepo;

    @Autowired
    EmployeeRepo employeeRepo;

    @Override
    public EmployeeDto addEmployee(Employee employee) {
        Employee employee1 = employeeRepo.save(employee);
        return modelMapper.map(employee1, EmployeeDto.class);
    }

    @Override
    public EmployeeDto updateEmployee(int projectId, int employeeId) {
        Project project = projectRepo.findById(projectId).orElseThrow(() -> new NotFoundException("Project Not Found"));
        Employee employee = employeeRepo.findById(employeeId).orElseThrow(() -> new NotFoundException("Employee Not Found"));
        List<Employee> employees = Objects.nonNull(project.getEmployees()) ? project.getEmployees() : new ArrayList<>();
        employees.add(employee);
        project.setEmployees(employees);
        int count = project.getEmployeeCount();
        project.setEmployeeCount(count++);
        Project project1 = projectRepo.saveAndFlush(project);
        return modelMapper.map(project1, EmployeeDto.class);

    }
}
