package com.flyerssoft.com.ProjectAllotment.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.flyerssoft.com.ProjectAllotment.entity.Project;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The employee dto
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeDto {
    private int employeeId;
    @NotBlank
    @Size(min = 1,max = 15,message = "Character Must Be In 1-15")
    private String employeeName;
    private String employeeEmail;
    private List<Project> projects;
}
