package com.flyerssoft.com.ProjectAllotment.service;

import com.flyerssoft.com.ProjectAllotment.dto.ClientDto;
import com.flyerssoft.com.ProjectAllotment.entity.Client;

/**
 * The client service
 */
public interface ClientService {

    /**
     * Add client details.
     *
     * @param client client
     * @return client details
     */
    ClientDto addClient(Client client);
}
