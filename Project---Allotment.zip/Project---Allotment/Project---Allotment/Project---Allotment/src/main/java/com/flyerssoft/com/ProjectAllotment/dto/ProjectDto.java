package com.flyerssoft.com.ProjectAllotment.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.flyerssoft.com.ProjectAllotment.entity.Employee;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The project dto
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectDto {

    private int projectId;
    @NotBlank
    @Size(min = 1,max = 15,message = "Character Must Be In 1-15")
    private String projectName;
    private int employeeCount;
    private List<Employee> employees;
}
