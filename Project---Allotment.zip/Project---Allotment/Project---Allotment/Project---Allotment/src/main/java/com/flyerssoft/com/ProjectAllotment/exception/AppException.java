package com.flyerssoft.com.ProjectAllotment.exception;

public class AppException extends RuntimeException{
    public AppException(String message){
            super(message);
    }
}
