package com.flyerssoft.com.ProjectAllotment.service.impl;

import com.flyerssoft.com.ProjectAllotment.config.ModelMapperConfig;
import com.flyerssoft.com.ProjectAllotment.dto.ClientDto;
import com.flyerssoft.com.ProjectAllotment.entity.Client;
import com.flyerssoft.com.ProjectAllotment.entity.Project;
import com.flyerssoft.com.ProjectAllotment.repository.ClientRepo;
import com.flyerssoft.com.ProjectAllotment.service.ClientService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class ClientServiceImpl implements ClientService {

    @Autowired
    ClientRepo clientRepo;

    @Autowired
    ModelMapper modelMapper;
    @Override
    public ClientDto addClient(Client client) {
        Client clientDetails = clientRepo.save(client);
        return modelMapper.map(clientDetails,ClientDto.class);
    }
}
