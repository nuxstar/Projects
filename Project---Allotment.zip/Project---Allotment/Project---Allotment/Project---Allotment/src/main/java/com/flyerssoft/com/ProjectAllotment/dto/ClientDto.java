package com.flyerssoft.com.ProjectAllotment.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.flyerssoft.com.ProjectAllotment.entity.Project;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The client dto
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientDto {

    private int clientId;
    @NotBlank
    @Size(min = 1,max = 15,message = "Character Must Be In 1-15")
    private String clientName;
    private List<Project> projects;
}
