package com.flyerssoft.com.ProjectAllotment.controller;

import com.flyerssoft.com.ProjectAllotment.dto.ProjectDto;
import com.flyerssoft.com.ProjectAllotment.entity.Project;
import com.flyerssoft.com.ProjectAllotment.service.impl.ClientServiceImpl;
import com.flyerssoft.com.ProjectAllotment.service.impl.ProjectServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The project controller
 */
@RestController
public class ProjectController {

    Logger logger = LoggerFactory.getLogger(ProjectController.class);

    @Autowired
    ProjectServiceImpl projectService;

    @PostMapping("/project/{clientId}")
    public ProjectDto addProject(@PathVariable int clientId, @RequestBody Project project) {
        logger.info("ADD Project Method Accessed.........");
        ProjectDto dto = projectService.addProject(clientId, project);
        logger.info("ADD Client Method Closed...........");
        return dto;
    }

    @GetMapping("/project/{projectId}")
    public Project getProject(@PathVariable int projectId) {
        logger.info("GET Project Method Accessed.........");
        Project project = projectService.getProject(projectId);
        logger.info("GET Project Method Closed...........");
        return project;
    }

    @GetMapping("/project")
    public List<Project> getAllProject() {
        logger.info("GET-ALL Project Method Accessed.........");
        List<Project> projects = projectService.getAllProject();
        logger.info("GET-ALL Project Method Closed...........");
        return projects;
    }
}
