package com.flyerssoft.com.ProjectAllotment.controller;

import com.flyerssoft.com.ProjectAllotment.dto.EmployeeDto;
import com.flyerssoft.com.ProjectAllotment.entity.Employee;
import com.flyerssoft.com.ProjectAllotment.repository.EmployeeRepo;
import com.flyerssoft.com.ProjectAllotment.service.impl.EmployeeServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The employee controller
 */
@RestController
public class EmployeeController {

    Logger logger = LoggerFactory.getLogger(EmployeeController.class);

    @Autowired
    EmployeeServiceImpl employeeService;
    @Autowired
    private EmployeeRepo employeeRepo;

    @PostMapping("/employee")
    public EmployeeDto addEmployee(@RequestBody Employee employee) {
        logger.info("ADD Employee Method Accessed.........");
        EmployeeDto employeeDetails = employeeService.addEmployee(employee);
        logger.info("ADD Employee Method Closed...........");
        return employeeDetails;
    }

    @PutMapping("/employee/{projectId}/{employeeId}")
    public EmployeeDto updateEmployee(@PathVariable int projectId, @PathVariable int employeeId) {
        logger.info("UPDATE Employee Method Accessed.........");
        EmployeeDto employeeDetails = employeeService.updateEmployee(projectId, employeeId);
        logger.info("UPDATE Employee Method Accessed.........");
        return employeeDetails;

    }
}
