package com.flyerssoft.com.ProjectAllotment.service;

import com.flyerssoft.com.ProjectAllotment.dto.EmployeeDto;
import com.flyerssoft.com.ProjectAllotment.entity.Employee;

/**
 * The employee service
 */
public interface EmployeeService {
    /**
     * Add employee details.
     *
     * @param employee employee
     * @return employee details
     */
    EmployeeDto addEmployee(Employee employee);

    /**
     * Update employee details.
     *
     * @param projectId projectId
     * @param employeeId employeeId
     * @return updated employee details
     */
    EmployeeDto updateEmployee(int projectId,int employeeId);

}
