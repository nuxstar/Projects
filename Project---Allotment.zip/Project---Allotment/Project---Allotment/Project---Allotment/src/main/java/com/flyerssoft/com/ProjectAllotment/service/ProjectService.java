package com.flyerssoft.com.ProjectAllotment.service;

import com.flyerssoft.com.ProjectAllotment.dto.ProjectDto;
import com.flyerssoft.com.ProjectAllotment.entity.Project;

import java.util.List;

/**
 * The project service
 */
public interface ProjectService {

    /**
     * Add project details.
     *
     * @param project project
     * @return project details
     */
    ProjectDto addProject(int clientId, Project project);

    /**
     * Get project details.
     *
     * @param projectId projectId
     * @return project details
     */
    Project getProject(int projectId);

    /**
     * Get all project details.
     *
     * @return al;l project details
     */
    List<Project> getAllProject();
}
