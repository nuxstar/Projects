package com.flyerssoft.com.ProjectAllotment.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

/**
 * The project entity
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "projectId", nullable = false)
    private int projectId;
    private String projectName;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private int employeeCount;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "project_employee",
            joinColumns = {@JoinColumn(name = "projectId")},
            inverseJoinColumns = @JoinColumn(name = "employeeId"))
    private List<Employee> employees;

}
