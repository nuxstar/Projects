package com.example.demoOauth.service;

import com.example.demoOauth.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@Transactional
public class PaymentServiceImpl implements PaymentService{

  private UserRepository userRepository;

  @Autowired
  private PaymentServiceImpl(UserRepository userRepository){
    this.userRepository = userRepository;
  }

  @Override
  public String sendFund(int sourceId, int destinationId, BigDecimal amount) {
    var sourceUser = userRepository.findById(sourceId).orElseThrow();
    var destinationUser = userRepository.findById(destinationId).orElseThrow();

    if (sourceUser.getAmount().compareTo(amount) < 0 ){
      throw new RuntimeException();
    }
    sourceUser.setAmount(sourceUser.getAmount().subtract(amount));
    destinationUser.setAmount(destinationUser.getAmount().add(amount));
    userRepository.save(sourceUser);
    userRepository.save(destinationUser);
    return null;
  }
}
