package com.example.demoOauth.model;

import jakarta.persistence.Entity;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Data
public class User {

  private int userId;

  private String accountNo;

  private BigDecimal amount;
}
