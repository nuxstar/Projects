package com.example.demoOauth.model;

import com.example.demoOauth.service.PaymentService;

import java.math.BigDecimal;

public record Person(int age, int name) implements PaymentService {

  private static String employeeName = "ram";

  @Override
  public String sendFund(int sourceId, int destinationId, BigDecimal amount) {
    return null;
  }
}
