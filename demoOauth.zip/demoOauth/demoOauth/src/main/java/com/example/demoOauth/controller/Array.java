package com.example.demoOauth.controller;

import java.util.Arrays;
import java.util.Scanner;

public class Array {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 1st Array size:");
        int array1 = sc.nextInt();
        System.out.println("Enter " + array1 + " values: ");

        int[] arr1 = new int[array1];

        for (int i = 0; i < arr1.length; i++) {
            arr1[i] = sc.nextInt();

        }

        System.out.println("Enter 2nd Array size :");
        int array2 = sc.nextInt();

        int[] arr2 = new int[array2];

        System.out.println("Enter " + array2 + " values: ");
        for (int i = 0; i < arr2.length; i++) {
            arr2[i] = sc.nextInt();
        }
        sc.close();

        int n1 = arr1.length;
        int n2 = arr2.length;

        int arr[] = new int[n1 + n2];

        int k = 0;

        int temp = 0;

        for (int i = 0; i < arr1.length; i++) {

            for (int j = 0; j < arr2.length; j++) {

                if (arr1[i] < arr2[j]) {
                    arr[k++] = arr1[i];
                }
            }
        }

            System.out.println("After Merging Array :" + Arrays.toString(arr));

            int len = arr.length;

            int oddMedian = 0;
            int evenMedain = 0;
            if (len % 2 != 0) {

                int m = arr.length / 2;

                oddMedian = arr[m] ;

            } else {

                int m = arr.length / 2;

                evenMedain = (arr[m] + arr[m] - 1) / 2;
            }

            System.out.println("Odd Array Median Value :" + oddMedian);

            System.out.println("Even Array Median Value :" + evenMedain);

    }
}

