package com.example.demoOauth.service;

import java.math.BigDecimal;

public interface PaymentService {

  String sendFund(int sourceId, int destinationId, BigDecimal amount);
}
