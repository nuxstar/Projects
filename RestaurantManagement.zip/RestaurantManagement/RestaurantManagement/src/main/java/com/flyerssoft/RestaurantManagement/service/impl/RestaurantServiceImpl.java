package com.flyerssoft.RestaurantManagement.service.impl;

import com.flyerssoft.RestaurantManagement.entity.Franchise;
import com.flyerssoft.RestaurantManagement.entity.Restaurant;
import com.flyerssoft.RestaurantManagement.exception.NotFoundException;
import com.flyerssoft.RestaurantManagement.repository.FranchiseRepository;
import com.flyerssoft.RestaurantManagement.repository.RestaurantRepository;
import com.flyerssoft.RestaurantManagement.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RestaurantServiceImpl implements RestaurantService {
    @Autowired
    RestaurantRepository restaurantRepository;
    @Autowired
    FranchiseRepository franchiseRepository;

    @Override
    public Restaurant addRestaurant(int franchiseId,Restaurant restaurant) {

        fran

        return null;
    }

    @Override
    public Restaurant getRestaurant(int restaurantId) {
       Optional<Restaurant> checkRestaurant =  restaurantRepository.findById(restaurantId);
       if (checkRestaurant.isEmpty()){
           throw new NotFoundException("Restaurant Not Found Exception!!!!");
       }
        return  checkRestaurant.get();
    }
}
