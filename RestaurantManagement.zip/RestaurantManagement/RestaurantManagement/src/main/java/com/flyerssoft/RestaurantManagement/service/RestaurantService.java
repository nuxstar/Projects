package com.flyerssoft.RestaurantManagement.service;

import com.flyerssoft.RestaurantManagement.entity.Restaurant;

import java.util.Optional;

/**
 * The restaurant service
 */
public interface RestaurantService {
    /**
     * Add restaurant details.
     *
     * @param restaurant restaurant
     * @return restaurant details
     */
    Restaurant addRestaurant(int franchiseId,Restaurant restaurant);

    /**
     * Get restaurant details.
     *
     * @param restaurantId restaurantId
     * @return restaurant details
     */
    Restaurant getRestaurant(int restaurantId);
}
