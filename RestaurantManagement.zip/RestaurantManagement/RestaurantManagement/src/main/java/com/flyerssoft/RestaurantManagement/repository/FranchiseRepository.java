package com.flyerssoft.RestaurantManagement.repository;

import com.flyerssoft.RestaurantManagement.entity.Franchise;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * The franchise repository
 */
@Component
@Repository
public interface FranchiseRepository extends JpaRepository<Franchise,Integer> {

}
