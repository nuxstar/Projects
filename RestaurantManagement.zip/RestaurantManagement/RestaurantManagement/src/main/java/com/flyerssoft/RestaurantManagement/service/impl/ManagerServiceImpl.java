package com.flyerssoft.RestaurantManagement.service.impl;

import com.flyerssoft.RestaurantManagement.entity.Manager;
import com.flyerssoft.RestaurantManagement.entity.Restaurant;
import com.flyerssoft.RestaurantManagement.exception.NotFoundException;
import com.flyerssoft.RestaurantManagement.repository.ManagerRepository;
import com.flyerssoft.RestaurantManagement.repository.RestaurantRepository;
import com.flyerssoft.RestaurantManagement.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ManagerServiceImpl implements ManagerService {

    @Autowired
    RestaurantRepository restaurantRepository;

    @Autowired
    ManagerRepository managerRepository;

    @Override
    public Manager addManager(int restaurantId, Manager manager) {
        Optional<Restaurant> checkRestaurant =  restaurantRepository.findById(restaurantId);
        if (checkRestaurant.isEmpty()){
            throw new NotFoundException("Restaurant Not Found Exception!!!!");
        }
        return managerRepository.save(manager);
    }

    @Override
    public Manager updateManager(int managerId, Manager manager) {
        Optional<Manager> checkManager =  managerRepository.findById(managerId);
        if (checkManager.isEmpty()){
            throw new NotFoundException("Manager Not Found Exception!!!!");
        }
        return managerRepository.save(manager);
    }

    @Override
    public Manager getManager(int managerId) {
        Optional<Manager> checkManager =  managerRepository.findById(managerId);
        if (checkManager.isEmpty()){
            throw new NotFoundException("Manager Not Found Exception!!!!");
        }
        return checkManager.get();
    }

    @Override
    public Boolean deleteManager(int managerId) {
        Optional<Manager> checkManager =  managerRepository.findById(managerId);
        if (checkManager.isEmpty()){
            throw new NotFoundException("Manager Not Found Exception!!!!");
        }
        managerRepository.deleteById(managerId);
        return true;
    }
}
