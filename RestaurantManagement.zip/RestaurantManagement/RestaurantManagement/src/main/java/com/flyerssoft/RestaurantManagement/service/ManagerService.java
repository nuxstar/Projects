package com.flyerssoft.RestaurantManagement.service;

import com.flyerssoft.RestaurantManagement.entity.Manager;

/**
 * The manager service
 */
public interface ManagerService{
    /**
     * Add manager details.
     *
     * @param restaurantId restaurantId
     * @param manager manager
     * @return manager details
     */
    Manager addManager(int restaurantId,Manager manager);

    /**
     * Update manager details.
     *
     * @param managerId managerId
     * @param manager manager
     * @return manager details.
     */
    Manager updateManager(int managerId,Manager manager);

    /**
     * Get manager details.
     *
     * @param managerId managerId
     * @return manager details with restaurant & franchise.
     */
    Manager getManager(int managerId);

    /**
     * Delete manager details.
     *
     * @param managerId managerId
     * @return delete manager details
     */
    Boolean deleteManager(int managerId);
}
