package com.flyerssoft.RestaurantManagement.service.impl;

import com.flyerssoft.RestaurantManagement.entity.Franchise;
import com.flyerssoft.RestaurantManagement.exception.NotFoundException;
import com.flyerssoft.RestaurantManagement.repository.FranchiseRepository;
import com.flyerssoft.RestaurantManagement.service.FranchiseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class FranchiseServiceImpl implements FranchiseService {
    @Autowired
    FranchiseRepository franchiseRepository;

    @Override
    public Franchise addFranchise(Franchise franchise) {
        return  franchiseRepository.save(franchise);
    }

    @Override
    public Optional<Franchise> getFranchise(int franchiseId) {
        Optional<Franchise> checkFranchise =  franchiseRepository.findById(franchiseId);
        if (checkFranchise.isEmpty())
            throw new NotFoundException("Franchise Not Found!!!!");
        return checkFranchise;
    }

    @Override
    public Boolean deleteFranchise(int franchiseId) {
        Optional<Franchise> checkFranchise =  franchiseRepository.findById(franchiseId);
        if (checkFranchise.isEmpty()){
            throw new NotFoundException("Franchise Not Found!!!!!!");
        }
       franchiseRepository.deleteById(franchiseId);
        return true;
    }
}
