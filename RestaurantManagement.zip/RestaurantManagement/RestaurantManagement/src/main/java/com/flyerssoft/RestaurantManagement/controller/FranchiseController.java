package com.flyerssoft.RestaurantManagement.controller;

import com.flyerssoft.RestaurantManagement.entity.Franchise;
import com.flyerssoft.RestaurantManagement.service.FranchiseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class FranchiseController {
    @Autowired
    FranchiseService franchiseService;

    @PostMapping("/franchise")
    public Franchise addFranchise(@RequestBody Franchise franchise){
      return franchiseService.addFranchise(franchise);
    }

    @GetMapping("/franchise/{franchiseId}")
    public Optional<Franchise> getFranchise(@PathVariable int franchiseId){
       return franchiseService.getFranchise(franchiseId);
    }

    @DeleteMapping("/franchise/{franchiseId}")
    public Boolean deleteFranchise(@PathVariable int franchiseId){
      return franchiseService.deleteFranchise(franchiseId);
    }
}
