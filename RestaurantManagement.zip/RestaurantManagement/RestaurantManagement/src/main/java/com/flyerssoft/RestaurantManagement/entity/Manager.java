package com.flyerssoft.RestaurantManagement.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 * The manager entity
 */
@Entity
@Getter
@Setter
@Table(name = "tbl_manager")
public class Manager {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int managerId;
    private String managerName;
    private long managerNumber;
    @OneToOne
    private Restaurant restaurant;
}
