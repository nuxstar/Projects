package com.flyerssoft.RestaurantManagement.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The franchise entity
 */
@Entity
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "tbl_franchise")
public class Franchise {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int franchiseId;
    private String franchiseName;
    @OneToMany(targetEntity = Restaurant.class,cascade = CascadeType.ALL)
    @JoinColumn(name = "FR_FK" , referencedColumnName = "franchiseId")
    private List<Restaurant> restaurants;
}
