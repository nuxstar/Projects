package com.flyerssoft.RestaurantManagement.service;

import com.flyerssoft.RestaurantManagement.entity.Franchise;

import java.util.Optional;

/**
 * The franchise service
 */
public interface FranchiseService {
    /**
     * Add franchise details.
     *
     * @param franchise franchise
     * @return franchise details
     */
  Franchise addFranchise(Franchise franchise);

    /**
     * Get franchise details.
     *
     * @param franchiseId franchiseId
     * @return franchise details
     */
  Optional<Franchise> getFranchise(int franchiseId);

    /**
     *  Delete franchise details.
     *
     * @param franchiseId franchiseId
     * @return franchise details
     */
  Boolean deleteFranchise(int franchiseId);

}
