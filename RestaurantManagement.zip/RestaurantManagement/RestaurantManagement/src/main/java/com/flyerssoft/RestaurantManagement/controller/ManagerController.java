package com.flyerssoft.RestaurantManagement.controller;

import com.flyerssoft.RestaurantManagement.entity.Manager;
import com.flyerssoft.RestaurantManagement.service.impl.ManagerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ManagerController {

    @Autowired
    ManagerServiceImpl managerService;

    @PostMapping("/manager/{restaurantId}")
    public Manager addManager(@PathVariable int restaurantId, @RequestBody Manager manager){
        return managerService.addManager(restaurantId,manager);
    }

    @PutMapping("/manager/{managerId}")
    public Manager updateManager(int managerId, Manager manager){
      return managerService.updateManager(managerId,manager);
    }

    @GetMapping ("/manager/{managerId}")
    public Manager getManager(@PathVariable int managerId){
       return managerService.getManager(managerId);
    }

    @DeleteMapping("/manager/{managerId}")
    public Boolean deleteManager(int managerId){
       return managerService.deleteManager(managerId);
    }
}
