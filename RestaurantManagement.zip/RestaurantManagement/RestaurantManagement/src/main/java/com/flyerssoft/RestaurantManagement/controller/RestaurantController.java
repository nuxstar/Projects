package com.flyerssoft.RestaurantManagement.controller;

import com.flyerssoft.RestaurantManagement.entity.Restaurant;
import com.flyerssoft.RestaurantManagement.service.impl.RestaurantServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class RestaurantController {

    @Autowired
    RestaurantServiceImpl restaurantService;

    @PostMapping("/restaurant/{franchiseId}")
    public  Restaurant addRestaurant(@PathVariable int franchiseId,@RequestBody Restaurant restaurant){
         return restaurantService.addRestaurant(franchiseId,restaurant);
    }

    @GetMapping("/restaurant/{restaurantId}")
    public Restaurant getRestaurant(@PathVariable int restaurantId){
        return restaurantService.getRestaurant(restaurantId);
    }
}

