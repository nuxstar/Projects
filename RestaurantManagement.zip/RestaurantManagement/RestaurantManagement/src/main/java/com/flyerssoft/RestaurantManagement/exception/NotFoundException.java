package com.flyerssoft.RestaurantManagement.exception;

public class NotFoundException extends AppException{
    public NotFoundException(String message) {
        super(message);
    }
}
