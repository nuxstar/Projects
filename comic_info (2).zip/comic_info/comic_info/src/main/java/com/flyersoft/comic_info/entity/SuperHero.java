package com.flyersoft.comic_info.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "super_hero")
public class SuperHero {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int superHeroId;
    private String superheroName;

    @ManyToMany(mappedBy = "superHeros")
    private List<Power> powers;

    public int getSuperHeroId() {
        return superHeroId;
    }

    public void setSuperHeroId(int superHeroId) {
        this.superHeroId = superHeroId;
    }

    public String getSuperheroName() {
        return superheroName;
    }

    public void setSuperheroName(String superheroName) {
        this.superheroName = superheroName;
    }

    public List<Power> getPowers() {
        return powers;
    }

    public void setPowers(List<Power> powers) {
        this.powers = powers;
    }
}
