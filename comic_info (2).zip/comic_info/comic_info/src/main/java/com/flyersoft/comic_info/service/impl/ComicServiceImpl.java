package com.flyersoft.comic_info.service.impl;

import com.flyersoft.comic_info.entity.Comic;
import com.flyersoft.comic_info.repository.ComicRepository;
import com.flyersoft.comic_info.service.ComicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ComicServiceImpl implements ComicService {

    @Autowired
    private ComicRepository comicRepository;

    @Override
    public Comic addComic(Comic comic) {
        return comicRepository.save(comic);
    }
}
