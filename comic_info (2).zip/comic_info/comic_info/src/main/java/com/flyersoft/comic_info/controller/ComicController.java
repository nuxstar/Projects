package com.flyersoft.comic_info.controller;

import com.flyersoft.comic_info.entity.Comic;
import com.flyersoft.comic_info.service.ComicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ComicController {

    @Autowired
    private ComicService comicService;

    @PostMapping("/comic")
    public Comic addComic(@RequestBody Comic comic) {
        return comicService.addComic(comic);
    }
}
