package com.flyersoft.comic_info.service;


import com.flyersoft.comic_info.entity.SuperHero;

import java.util.List;

/**
 * The superhero service
 */
public interface SuperHeroService {

    /**
     * Add superhero details.
     *
     * @param heroId heroid
     * @param powers powers
     * @return hero details
     */
    SuperHero updateSuperHero(int heroId, SuperHero superHero);

    /**
     * Get all hero details.
     *
     * @return all hero details
     */
    List<SuperHero> getAllHero();

}
