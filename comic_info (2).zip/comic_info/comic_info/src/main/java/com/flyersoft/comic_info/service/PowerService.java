package com.flyersoft.comic_info.service;


import com.flyersoft.comic_info.entity.Power;

/**
 * The power service
 */
public interface PowerService {

    /**
     * Get power details.
     *
     * @param powerId powerId
     * @return power details
     */
    Power getPower(int powerId);

    /**
     * Delete power details.
     *
     * @param powerId powerId
     * @return delete power details
     */
    Boolean deletePower(int powerId);
}
