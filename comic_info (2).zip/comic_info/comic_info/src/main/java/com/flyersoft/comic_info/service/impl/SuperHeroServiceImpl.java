package com.flyersoft.comic_info.service.impl;

import com.flyersoft.comic_info.entity.Power;
import com.flyersoft.comic_info.entity.SuperHero;
import com.flyersoft.comic_info.repository.SuperHeroRepository;
import com.flyersoft.comic_info.service.SuperHeroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SuperHeroServiceImpl implements SuperHeroService {

    @Autowired
    private SuperHeroRepository superHeroRepository;

    @Override
    public SuperHero updateSuperHero(int heroId, SuperHero superHero) {
        Optional<SuperHero> optSuperHero = superHeroRepository.findById(heroId);
        if(optSuperHero.isEmpty()) {
            throw new RuntimeException("hero not found");
        }
        SuperHero existingSuperHero = optSuperHero.get();
        if(Objects.nonNull(superHero.getSuperheroName())) {
            existingSuperHero.setSuperheroName(superHero.getSuperheroName());
        }
        List<Power> powers = new ArrayList<>();
        if(Objects.nonNull(existingSuperHero.getPowers()) && existingSuperHero.getPowers().size()!=0) {
          powers.addAll(existingSuperHero.getPowers());
        }
        powers.addAll(superHero.getPowers());
        existingSuperHero.setPowers(powers);
        return superHeroRepository.save(existingSuperHero);
    }

    @Override
    public List<SuperHero> getAllHero() {
        List<SuperHero> superHeros = superHeroRepository.findAll();
        superHeros.sort((o1, o2) -> o2.getPowers().size() - o1.getPowers().size());
        return superHeros;
    }
}
