package com.flyersoft.comic_info.repository;

import com.flyersoft.comic_info.entity.SuperHero;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SuperHeroRepository extends JpaRepository<SuperHero, Integer> {
}
