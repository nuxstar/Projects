package com.flyersoft.comic_info.controller;

import com.flyersoft.comic_info.entity.SuperHero;
import com.flyersoft.comic_info.service.SuperHeroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SuperHeroController {

    @Autowired
    private SuperHeroService superHeroService;

    @PutMapping("/superhero")
    public SuperHero updateSuperHero(@RequestParam int heroId, @RequestBody SuperHero superHero) {
        return superHeroService.updateSuperHero(heroId,superHero);
    }
}
