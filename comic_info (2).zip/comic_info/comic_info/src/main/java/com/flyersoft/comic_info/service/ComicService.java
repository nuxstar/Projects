package com.flyersoft.comic_info.service;

import com.flyersoft.comic_info.entity.Comic;

public interface ComicService {

    Comic addComic(Comic comic);
}
