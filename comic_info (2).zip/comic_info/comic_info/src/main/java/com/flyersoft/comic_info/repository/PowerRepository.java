package com.flyersoft.comic_info.repository;

import com.flyersoft.comic_info.entity.Power;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PowerRepository extends JpaRepository<Power, Integer> {
}
