package com.flyersoft.comic_info.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Comic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ComicId;
    private String ComicName;

    //one to many, un-directional from comic to superheros

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "comic_id", referencedColumnName = "ComicId")
    private List<SuperHero> superHeroes;

    public int getComicId() {
        return ComicId;
    }

    public void setComicId(int comicId) {
        ComicId = comicId;
    }

    public String getComicName() {
        return ComicName;
    }

    public void setComicName(String comicName) {
        ComicName = comicName;
    }

    public List<SuperHero> getSuperHeroes() {
        return superHeroes;
    }

    public void setSuperHeroes(List<SuperHero> superHeroes) {
        this.superHeroes = superHeroes;
    }
}
