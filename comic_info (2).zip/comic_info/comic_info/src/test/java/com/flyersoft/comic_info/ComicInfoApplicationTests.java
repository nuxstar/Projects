package com.flyersoft.comic_info;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComicInfoApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
