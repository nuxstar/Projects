//<<<<<<< HEAD
////package com.flyers.logic;
//
////
////import org.slf4j.Logger;
////import org.slf4j.LoggerFactory;
////
////import java.util.function.Consumer;
////
////public class OwnFunctional {
////    final Logger logger = LoggerFactory.getLogger(OwnFunctional.class);
////
////    public <T> void execute(Consumer<T> consumer, T payload) {
////        logger.info("Execute Method Accessed");
////        try {
////            consumer.accept(payload);
////            logger.info("Execute Method Success");
////        } catch (Exception e) {
////            logger.info("Execute Method Getting Issue");
////            System.out.println(e.getMessage());
////        }
////
////    }
////
////
////}
//=======
//
//package com.flyers.logic;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.function.Consumer;
//
//public class OwnFunctional {
//    final Logger logger = LoggerFactory.getLogger(OwnFunctional.class);
//
//    public <T> void execute(Consumer<T> consumer, T payload) {
//        logger.info("Execute Method Accessed");
//        try {
//            consumer.accept(payload);
//            logger.info("Execute Method Success");
//        } catch (Exception e) {
//            logger.info("Execute Method Getting Issue");
//            System.out.println(e.getMessage());
//        }
//
//        System.out.println("dgfhjhkl;jhg");
//
//    }
//
//
//}
//>>>>>>> 4d10f47797b93bb9fafeb85ad11fa1739f0648a7
