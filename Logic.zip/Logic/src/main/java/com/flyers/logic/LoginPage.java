package com.flyers.logic;

public class LoginPage {
}
