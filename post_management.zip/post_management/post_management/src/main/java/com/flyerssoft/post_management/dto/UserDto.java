package com.flyerssoft.post_management.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UserDto {

    private Long userId;
    @NotNull
    @NotBlank
    @Size(min = 1,max = 25,message = "Character Must Be In 1 to 25")
    private String userName;
    @Email
    @NotNull
    @NotBlank
    private String email;
    @NotNull
    @NotBlank
    @Size(min = 6, max = 15 ,message = "Character Must Be In 6 to 15")
    private String password;
}
