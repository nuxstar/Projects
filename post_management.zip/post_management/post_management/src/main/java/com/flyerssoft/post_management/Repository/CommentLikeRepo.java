package com.flyerssoft.post_management.Repository;

import com.flyerssoft.post_management.entity.CommentLike;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentLikeRepo extends JpaRepository<CommentLike,Integer> {
}
