package com.flyerssoft.post_management.exception;

public class AppException extends RuntimeException{
    public AppException(String message){
        super(message);
    }
}
