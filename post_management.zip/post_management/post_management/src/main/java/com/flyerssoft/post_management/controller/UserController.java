package com.flyerssoft.post_management.controller;

import com.flyerssoft.post_management.dto.LoginRequestDto;
import com.flyerssoft.post_management.dto.UserDto;
import com.flyerssoft.post_management.service.UserService;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The UserController
 */

@RestController
public class UserController {
    Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    UserService userService;

    @PostMapping("/user/add")
    public UserDto addUser(@RequestBody @Valid UserDto userDto) {
        logger.info("Add User Method Accessed..........");
        return userService.addUser(userDto);
    }

    @GetMapping("user/{userId}")
    public UserDto getUser(@PathVariable int userId) {
        return userService.getUserById(userId);
    }

    @DeleteMapping("user/{userId}")
    public Boolean deleteUser(@PathVariable int userId) {
        logger.info("Delete User Method Accessed..........");
        return userService.deleteUser(userId);
    }

    @GetMapping("/user/welcome-page")
    public String login() {
        return "Welcome to the portal";
    }

    @PostMapping("/user/login")
    public String userLoginApi(@RequestBody LoginRequestDto loginRequestDto) throws Exception {
        return userService.userLoginApi(loginRequestDto.getEmail(), loginRequestDto.getPassword());
    }

}
