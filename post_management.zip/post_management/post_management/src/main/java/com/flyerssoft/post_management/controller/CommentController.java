package com.flyerssoft.post_management.controller;

import com.flyerssoft.post_management.dto.CommentDto;
import com.flyerssoft.post_management.service.CommentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The CommentController
 */
@RestController
public class CommentController {

    Logger logger = LoggerFactory.getLogger(CommentController.class);
    @Autowired
    CommentService commentService;

    @PostMapping("Comment/{userId}/{ticketId}")
    public CommentDto addComment(@PathVariable("userId") int userId, @PathVariable("ticketId") int ticketId, @RequestBody CommentDto commentDto) {
        logger.info("Add Comment Method Accessed");
        return commentService.addComment(userId, ticketId, commentDto);
    }

    @GetMapping("comment/{cmtId}")
    public CommentDto getUser(@PathVariable int cmtId){
        return commentService.getComment(cmtId);
    }
    @DeleteMapping("comment/{commentId}")
    public Boolean deleteTicket(@PathVariable int commentId) {
        logger.info("Delete Comment Method Accessed");
        return commentService.deleteComment(commentId);
    }
}
