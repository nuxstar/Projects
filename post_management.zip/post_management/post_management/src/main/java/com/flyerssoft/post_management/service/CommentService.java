package com.flyerssoft.post_management.service;

import com.flyerssoft.post_management.dto.CommentDto;
import com.flyerssoft.post_management.dto.UserDto;

public interface CommentService {

    /**
     * Add Comment details.
     *
     * @param commentDto commentDto
     * @return comment details
     */
    CommentDto addComment(int userId,int ticketId,CommentDto commentDto);

    /**
     * Get comment details.
     *
     * @param cmtId cmtId
     * @return comment details
     */
    CommentDto getComment(int cmtId);

    /**
     * Delete comment details.
     *
     * @param commentId commentId
     * @return boolean message
     */
    Boolean deleteComment(int commentId);
}
