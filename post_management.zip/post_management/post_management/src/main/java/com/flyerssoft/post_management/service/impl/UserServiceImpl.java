package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.UserRepo;
import com.flyerssoft.post_management.controller.LikesController;
import com.flyerssoft.post_management.dto.UserDto;
import com.flyerssoft.post_management.entity.User;
import com.flyerssoft.post_management.exception.NotFoundException;
import com.flyerssoft.post_management.security.JwtTokenUtils;
import com.flyerssoft.post_management.security.UserDataServiceImpl;
import com.flyerssoft.post_management.security.WebSecurityConfig;
import com.flyerssoft.post_management.service.UserService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserRepo userRepo;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private UserDataServiceImpl userServiceImpl;
    @Autowired
    private JwtTokenUtils tokenUtils;
    @Autowired
    private WebSecurityConfig webSecurityConfig;

    Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);


    @Override
    public UserDto addUser(UserDto userDto) {
        logger.info("Method Started For Add User");
        User userRequest = modelMapper.map(userDto, User.class);
        userRequest.setPassword(webSecurityConfig.passwordEncoder().encode(userRequest.getPassword()));
        User userResponse = userRepo.save(userRequest);
        logger.info("User Added Successfully");
        return modelMapper.map(userResponse, UserDto.class);
    }

    @Override
    public UserDto getUserById(int userId) {
        logger.info("Method Started For Get User");
        userRepo.findById((long) userId).orElseThrow(() -> new NotFoundException("User Not Found"));
        Optional<User> userDetails = userRepo.findById((long)userId);
        User userResponse = userDetails.get();
        return modelMapper.map(userResponse, UserDto.class);
    }

    @Override
    public Boolean deleteUser(int userId) {
        logger.info("Method Started For Delete User");
        userRepo.findById((long)userId).orElseThrow(() -> new NotFoundException("User Not Found"));
        userRepo.deleteById((long)userId);
        logger.info("User Deleted Successfully");
        return true;
    }

    @Override
    public String userLoginApi(String email, String password) throws Exception {

        User existUser =   userRepo.findByEmail(email);
        System.out.println("user - "+existUser.getEmail());
        if (webSecurityConfig.passwordEncoder().matches(password, existUser.getPassword())) {
            userServiceImpl.authenticate(email, password);
            return loginToken(existUser);
        } else {
            throw new Exception("User not found");
        }
    }

    public String loginToken(User user) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("USER"));
        Map<String, Object> claims = new HashMap<>();
        claims.put("name", user.getUserName());
        claims.put("role", "USER");
        return tokenUtils.generateToken(new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), authorities), claims);
    }
}
