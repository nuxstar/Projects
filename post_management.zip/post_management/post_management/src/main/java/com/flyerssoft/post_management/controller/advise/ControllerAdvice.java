package com.flyerssoft.post_management.controller.advise;

import com.flyerssoft.post_management.exception.ApiError;
import com.flyerssoft.post_management.exception.AppException;
import com.flyerssoft.post_management.exception.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestControllerAdvice
public class ControllerAdvice {

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ApiError handleEntityNotFound(AppException ex) {
        ApiError apiError = new ApiError(HttpStatus.NOT_FOUND);
        apiError.setMessage(ex.getMessage());
        apiError.setStatus(apiError.getStatus());
        return apiError;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiError customValidation(MethodArgumentNotValidException e){
        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
        String errorMessage = "Request has Invalid input.";
         Optional<FieldError> error = e.getB    indingResult().getFieldErrors().stream().findFirst();
         if(error.isPresent()) {
             errorMessage = error.get().getField() + " has Invalid input.";
         }
        apiError.setMessage(errorMessage);
        Object s = e.getDetailMessageArguments();
        return  apiError;
    }


}
