package com.flyerssoft.post_management.Repository;

import com.flyerssoft.post_management.entity.TicketLike;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketLikeRepo extends JpaRepository<TicketLike,Integer> {
}
