package com.flyerssoft.post_management.service;

import com.flyerssoft.post_management.dto.TicketDto;
import com.flyerssoft.post_management.dto.UserDto;

public interface TicketService {

    /**
     * Add ticket details.
     *
     * @param ticketDto ticketDto
     * @return user details
     */
    TicketDto addTicket(int userId, TicketDto ticketDto);

    /**
     * Get ticket details.
     *
     * @param ticketId ticketDto
     * @return ticket details
     */
    TicketDto getTicketById(int ticketId);

    /**
     * Delete ticket details.
     *
     * @param ticketId ticketId
     * @return boolean message
     */
    Boolean deleteTicket(int ticketId);
}
