package com.flyerssoft.post_management.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TicketLike extends Likes {
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private Ticket ticket;
}
