package com.flyerssoft.post_management.exception;

abstract class SubErrors {
}
