package com.flyerssoft.post_management.dto;

import com.flyerssoft.post_management.entity.User;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TicketDto {

    private Long ticketId;
    @NotBlank
    @Pattern(regexp = "^[a-zA-Z0-9 ]*$")
    private String ticketTitle;
    @NotBlank
    @Size(min = 1,max = 100)
    private String ticketDescription;
    private int ticket_Like_Count;
    private User user;

}
