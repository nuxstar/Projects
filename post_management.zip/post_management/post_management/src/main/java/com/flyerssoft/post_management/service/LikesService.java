package com.flyerssoft.post_management.service;


import com.flyerssoft.post_management.dto.LikesDto;
import com.flyerssoft.post_management.dto.LikesPostDto;


public interface LikesService {
    LikesDto addLike(LikesPostDto likesPostDto);

}
