package com.flyerssoft.post_management.entity;

import jakarta.persistence.*;
import lombok.*;
/**
 * The comment entity
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String cmtMessage;
    private int comment_Like_Count;
    @ManyToOne(cascade = CascadeType.PERSIST)
    private Ticket ticket;
    @ManyToOne(cascade = CascadeType.PERSIST)
    private User user;
}
