package com.flyerssoft.post_management.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LikesControllerTest {

    @Test
    void addLike() {

    }

    @Test
    void getAllTicketLike() {
    }
}