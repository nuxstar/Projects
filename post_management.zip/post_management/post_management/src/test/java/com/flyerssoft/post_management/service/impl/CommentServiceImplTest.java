package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.CommentRepo;
import com.flyerssoft.post_management.Repository.TicketRepo;
import com.flyerssoft.post_management.Repository.UserRepo;
import com.flyerssoft.post_management.dto.CommentDto;
import com.flyerssoft.post_management.entity.Comment;
import com.flyerssoft.post_management.entity.Ticket;
import com.flyerssoft.post_management.entity.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyInt;

@SpringJUnitConfig
@ExtendWith(MockitoExtension.class)
class CommentServiceImplTest {

    @Mock
    CommentRepo commentRepo;

    @Mock
    UserRepo userRepo;

    @Mock
    TicketRepo ticketRepo;

    @Mock
    ModelMapper modelMapper;

    @InjectMocks
    CommentServiceImpl commentService;

    private Comment comment;

    private CommentDto commentDto;

    @BeforeEach
    public void beforeAllMethod() {
        comment = new Comment();
        comment.setId(1L);
        comment.setCmtMessage("Test Comment Message");
        comment.setComment_Like_Count(1);
        commentDto = new CommentDto();
        commentDto.setId(comment.getId());
        commentDto.setCmtMessage(comment.getCmtMessage());
        commentDto.setComment_Like_Count(comment.getComment_Like_Count());
    }

    @Test
    void addComment() {
        User user = new User();
        Mockito.when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
        Ticket ticket = new Ticket();
        Mockito.when(ticketRepo.findById(anyInt())).thenReturn(Optional.of(ticket));
        Mockito.when(modelMapper.map(commentDto, Comment.class)).thenReturn(comment);
        comment.setUser(user);
        comment.setTicket(ticket);
        Mockito.when(commentRepo.save(Mockito.any())).thenReturn(comment);
        Mockito.when(modelMapper.map(comment, CommentDto.class)).thenReturn(commentDto);
        CommentDto commentResponse = commentService.addComment(1, 1, commentDto);
        Assertions.assertEquals(commentDto, commentResponse);
    }

    @Test
    void getComment() {
        Mockito.when(commentRepo.findById(anyInt())).thenReturn(Optional.of(comment));
        Mockito.when(modelMapper.map(comment, CommentDto.class)).thenReturn(commentDto);
       CommentDto commentDtoResponse =  commentService.getComment(anyInt());
       Assertions.assertEquals(commentDto,commentDtoResponse);
    }

    @Test
    void deleteComment() {

        Mockito.when(commentRepo.findById(anyInt())).thenReturn(Optional.of(comment));
        commentRepo.deleteById(anyInt());
        Boolean result = commentService.deleteComment(anyInt());
        Assertions.assertEquals(true, result);
    }
}