package com.flyerssoft.post_management.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flyerssoft.post_management.dto.CommentDto;
import com.flyerssoft.post_management.service.impl.CommentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringJUnitConfig
@WebMvcTest(CommentController.class)
class CommentControllerTest {

    @MockBean
    CommentServiceImpl commentService;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    MockMvc mockMvc;
    private CommentDto commentDto;
    @BeforeEach
    public void init(){
        commentDto=new CommentDto();
        commentDto.setId(1L);
        commentDto.setCmtMessage("commentMessage");
        commentDto.setComment_Like_Count(2);
    }

    @Test
    void addComment() throws Exception {
        when(commentService.addComment(anyInt(),anyInt(),any(CommentDto.class))).thenReturn(commentDto);
        this.mockMvc.perform(MockMvcRequestBuilders.post("/comment/{userId}/{ticketId}", 1,1)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(commentDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.cmtMessage", is(commentDto.getCmtMessage())))
                .andExpect(jsonPath("$.comment_Like_Count", is(commentDto.getComment_Like_Count())));

    }
    @Test
    void getComment() throws Exception {
        when(commentService.getComment(anyInt())).thenReturn(commentDto);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/comment/{commentId}", 1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.cmtMessage", is(commentDto.getCmtMessage())))
                .andExpect(jsonPath("$.comment_Like_Count", is(commentDto.getComment_Like_Count())));
    }
    @Test
    void deleteTicket() throws Exception {
        when(commentService.deleteComment(anyInt())).thenReturn(true);
        this.mockMvc.perform(delete("/comment/{commentId}", 1))
                .andExpect(status().is2xxSuccessful());
    }
}