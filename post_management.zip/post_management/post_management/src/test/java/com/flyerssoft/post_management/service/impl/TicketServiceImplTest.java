package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.TicketRepo;
import com.flyerssoft.post_management.Repository.UserRepo;
import com.flyerssoft.post_management.dto.TicketDto;
import com.flyerssoft.post_management.entity.Ticket;
import com.flyerssoft.post_management.entity.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;

@SpringJUnitConfig
@ExtendWith(MockitoExtension.class)
class TicketServiceImplTest {

    @Mock
    TicketRepo ticketRepo;
    @Mock
    UserRepo userRepo;
    @InjectMocks
    TicketServiceImpl ticketService;
    @Mock
    ModelMapper modelMapper;
    private Ticket ticket;

    private  TicketDto ticketDto;
    @BeforeEach
    public void beforeAllMethod() {
        ticket = new Ticket();
        ticket.setTicketId(1L);
        ticket.setTicketTitle("ticketTitle");
        ticket.setTicketDescription("Test method for ticket description");
        ticket.setTicket_Like_Count(1);
        ticketDto = new TicketDto();
        ticketDto.setTicketId(ticket.getTicketId());
        ticketDto.setTicketTitle(ticket.getTicketTitle());
        ticketDto.setTicketDescription(ticket.getTicketDescription());
        ticketDto.setTicket_Like_Count(ticket.getTicket_Like_Count());
    }

    @Test
    void addTicket() {
        User user = new User();
        user.setUserId(1L);
        user.setUserName("Ram");
        user.setUserMail("ram@gmail.com");
        Mockito.when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
        Mockito.when(modelMapper.map(ticketDto,Ticket.class)).thenReturn(ticket);
        Ticket ticket1 = new Ticket();
        ticket1.setTicketId(ticket.getTicketId());
        ticket1.setTicketTitle(ticket.getTicketTitle());
        ticket1.setTicketDescription(ticket.getTicketDescription());
        ticket1.setTicket_Like_Count(ticket.getTicket_Like_Count());
        ticket1.setUser(user);
        ticketDto.setUser(user);
        Mockito.when(ticketRepo.save(Mockito.any())).thenReturn(ticket1);
        Mockito.when(modelMapper.map(ticket1,TicketDto.class)).thenReturn(ticketDto);
        TicketDto ticketDtoResponse = ticketService.addTicket(anyInt(),ticketDto);
        Assertions.assertEquals(ticketDto,ticketDtoResponse,"Something Wrong In Your Code...");
    }

    @Test
    void getTicketById() {
        Mockito.when(ticketRepo.findById(anyInt())).thenReturn(Optional.of(ticket));
        Mockito.when(modelMapper.map(ticket, TicketDto.class)).thenReturn(ticketDto);
        TicketDto ticketResponse = ticketService.getTicketById(anyInt());
        Assertions.assertEquals(ticketDto, ticketResponse);
    }

    @Test
    void deleteTicket() {
        Mockito.when(ticketRepo.findById(anyInt())).thenReturn(Optional.of(ticket));
        Boolean result = ticketService.deleteTicket(anyInt());
        Assertions.assertEquals(true, result);
    }
}