package com.flyerssoft.post_management.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flyerssoft.post_management.dto.UserDto;
import com.flyerssoft.post_management.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringJUnitConfig
@WebMvcTest(UserController.class)
class UserControllerTest {

    @MockBean
    UserService userService;

    @InjectMocks
    UserController userController;

    @MockBean
    ModelMapper modelMapper;

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    private UserDto userDto;

    @BeforeEach
    public void beforeAllMethod() {
        userDto = new UserDto();
        userDto.setUserId(1L);
        userDto.setUserName("User1");
        userDto.setEmail("user1@gmail.com");
    }

    @Test
    void addUser() throws Exception {
        when(userService.addUser(any(UserDto.class))).thenReturn(userDto);
        this.mockMvc.perform(MockMvcRequestBuilders.post("/user")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId", is(1)))
                .andExpect(jsonPath("$.userName", is(userDto.getUserName())))
                .andExpect(jsonPath("$.userMail", is(userDto.getEmail())));
    }

    @Test
    void getUser() throws Exception {
        when(userService.getUserById(anyInt())).thenReturn(userDto);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/user/{userId}", 1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId", is(1)))
                .andExpect(jsonPath("$.userName", is(userDto.getUserName())))
                .andExpect(jsonPath("$.userMail", is(userDto.getEmail())));
    }

    @Test
    void testDeleteUser() throws Exception {
        when(userService.deleteUser(anyInt())).thenReturn(true);
        this.mockMvc.perform(delete("/employee/remove/{id}", 1L))
                .andExpect(status().is2xxSuccessful());
    }
}