package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.UserRepo;
import com.flyerssoft.post_management.dto.UserDto;
import com.flyerssoft.post_management.entity.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;

@SpringJUnitConfig
@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @InjectMocks
    UserServiceImpl userService;
    @Mock
    UserRepo userRepo;
    @Mock
    ModelMapper modelMapper;

    @Test
    void addUser() {
        UserDto userDto = new UserDto();
        userDto.setUserName("xxx");
        userDto.setUserMail("xxx");
        User user=new User();
        user.setUserId(1L);
        user.setUserName("xxx");
        user.setUserMail("xxx");
        Mockito.when(modelMapper.map(userDto, User.class)).thenReturn(user);
        Mockito.when(userRepo.save(Mockito.any())).thenReturn(user);
        UserDto userDto1=new UserDto();
        userDto1.setUserId(1L);
        userDto1.setUserName("xxx");
        userDto1.setUserMail("xxx");
        Mockito.when(modelMapper.map(user, UserDto.class)).thenReturn(userDto1);
        UserDto result=userService.addUser(userDto1);
        assertEquals(userDto1,result);
    }
    @Test
    void getUser() {
        User user=new User();
        user.setUserId(1L);
        user.setUserName("user1");
        user.setEmail("user1@gmail.com");
        UserDto userDto = new UserDto();
        user.setUserId(user.getUserId());
        userDto.setUserName(user.getUserName());
        userDto.setEmail(user.getEmail());
        Mockito.when(modelMapper.map(userDto,User.class)).thenReturn(user);
        Mockito.when(userRepo.save(Mockito.any())).thenReturn(user);
        Mockito.when(modelMapper.map(user,UserDto.class)).thenReturn(userDto);
        UserDto userDtoResponse = userService.addUser(userDto);
        Assertions.assertEquals(userDto,userDtoResponse);
    }
    @Test
    void deleteUser() {
        User user=new User();
        user.setUserId(1L);
        user.setUserName("xxx");
        user.setUserMail("xxx");
        Mockito.when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
        Boolean result=userService.deleteUser(1);
        assertEquals(true,result);
    }
}
