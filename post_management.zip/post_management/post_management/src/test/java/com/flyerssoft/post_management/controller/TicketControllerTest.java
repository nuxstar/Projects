package com.flyerssoft.post_management.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flyerssoft.post_management.dto.TicketDto;
import com.flyerssoft.post_management.service.impl.TicketServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringJUnitConfig
@WebMvcTest(TicketController.class)
class TicketControllerTest {

    @MockBean
    TicketServiceImpl ticketService;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    MockMvc mockMvc;
    private TicketDto ticketDto;

    @BeforeEach
    public void init() {
        ticketDto=new TicketDto();
        ticketDto.setTicketId(1L);
        ticketDto.setTicketTitle("xxxx");
        ticketDto.setTicketDescription("xxx");
        ticketDto.setTicket_Like_Count(1);
    }
    @Test
    void addTicket() throws Exception {
        when(ticketService.addTicket(anyInt(),any(TicketDto.class))).thenReturn(ticketDto);
        this.mockMvc.perform(MockMvcRequestBuilders.post("/ticket/{userId}",1)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(ticketDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ticketId", is(1)))
                .andExpect(jsonPath("$.ticketTitle", is(ticketDto.getTicketTitle())))
                .andExpect(jsonPath("$.ticketDescription", is(ticketDto.getTicketDescription())))
                .andExpect(jsonPath("$.ticket_Like_Count", is(ticketDto.getTicket_Like_Count())));
    }
    @Test
    void getTicket() throws Exception {
        when(ticketService.getTicketById(anyInt())).thenReturn(ticketDto);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/ticket/{ticketId}", 1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ticketId", is(1)))
                .andExpect(jsonPath("$.ticketTitle", is(ticketDto.getTicketTitle())))
                .andExpect(jsonPath("$.ticketDescription", is(ticketDto.getTicketDescription())))
                .andExpect(jsonPath("$.ticket_Like_Count", is(ticketDto.getTicket_Like_Count())));
    }
    @Test
    void deleteTicket() throws Exception {
        when(ticketService.deleteTicket(anyInt())).thenReturn(true);
        this.mockMvc.perform(delete("/ticket/{ticketId}", 1))
                .andExpect(status().is2xxSuccessful());
    }
}