package com.flyers.projectAllotment.dao.impl;

import com.flyers.projectAllotment.dao.ProjectDao;
import com.flyers.projectAllotment.entity.Employee;
import com.flyers.projectAllotment.entity.Project;
import com.flyers.projectAllotment.exception.AppException;
import com.flyers.projectAllotment.utility.MyConnection;

import java.sql.*;

public class ProjectDaoImpl implements ProjectDao {

    private MyConnection myConnection = new MyConnection();

    @Override
    public Project addProject(Project project, String clientName) {

        Connection connection=null;
        Statement statement;

        String checkClientQuery = "SELECT * FROM CLIENT_ WHERE client_name='"+clientName+"'";
        String addProjectQuery = "INSERT INTO PROJECT(projectName,project_StartDate,project_EndDate,employeeCount) VALUE(?,?,?,?)";
        String addEmployeeQuery= "INSERT INTO EMPLOYEE(employeeName,designation,employeeEmail) VALUE(?,?,?)";

        try {
             connection =  myConnection.connectJdbc();
           statement =  connection.createStatement();
        ResultSet clientResultSet =  statement.executeQuery(checkClientQuery);

        if (!clientResultSet.next()){
            System.out.println("Client Not Found");
        }

       PreparedStatement preparedStatement =  connection.prepareStatement(addProjectQuery);
        preparedStatement.setString(1,project.getProjectName());
        preparedStatement.setString(2,project.getProjectStartDate());
        preparedStatement.setString(3,project.getProjectEndDate());
        preparedStatement.setInt(4,project.getEmployeeCount());
       int result =  preparedStatement.executeUpdate();

       if (result == 1){

           PreparedStatement statement1 =  connection.prepareStatement(addEmployeeQuery);
           Employee employee = new Employee();
           statement1.setString(1,employee.getEmployeeName());
           statement1.setString(2,employee.getEmployeeDesignation());
           statement1.setString(3,employee.getEmployeeMail());
           statement1.executeUpdate();
       }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public Project updateProject(String projectName, Project project) {


        Connection connection = null;

        String updateQuery = "UPDATE PROJECT SET project_StartDate = (?), project_EndDate = (?) , employeeCount = (?) WHERE projectName =(?)";

        try {
          connection =    myConnection.connectJdbc();
         PreparedStatement preparedStatement =  connection.prepareStatement(updateQuery);
         preparedStatement.setString(1,project.getProjectStartDate());
         preparedStatement.setString(2,project.getProjectEndDate());
         preparedStatement.setInt(3,project.getEmployeeCount());
         preparedStatement.setString(4,projectName);
         preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return null;
    }

    @Override
    public Project getProjectDetail(String projectName) {

        Connection connection = null;
        Statement statement;

        try {
            connection =   myConnection.connectJdbc();
            statement =  connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM PROJECT WHERE projectName='"+projectName+"'");


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }
        

        return null;
    }

    @Override
    public Boolean deleteProjectDetail(String projectName) {


        Connection connection = null;
        Statement statement;

        try {
            connection =   myConnection.connectJdbc();
            statement =  connection.createStatement();
            ResultSet resultSet = statement.executeQuery("DELETE * FROM PROJECT WHERE projectName='"+projectName+"'");


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }
        return null;
    }
}
