package com.flyers.projectAllotment.service;
import com.flyers.projectAllotment.entity.Client;
import com.flyers.projectAllotment.entity.Project;

/**
 * The client service.
 */
public interface ClientService {

    /**
     * Add the client details.
     *
     * @param client client details
     * @return client properties
     */
    Client addClient(Client client);

    /**
     * Update the client details.
     *
     * @param clientName clientName
     * @param client  client details
     * @return client details after update
     */
    Client updateClient(String clientName,Client client);

    /**
     * Get the client details.
     *
     * @param clientName clientName
     * @return get client details
     */
    Client getClientDetail(String clientName);

    /**
     * Delete the client details.
     *
     * @param clientName clientName
     * @return delete client details
     */
    Boolean deleteClientDetail(String clientName);

}
