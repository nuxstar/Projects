package com.flyers.projectAllotment.service;
import com.flyers.projectAllotment.entity.Project;

/**
 * The project service.
 */
public interface ProjectService {

    /**
     * Add project details.
     *
     * @param project project
     * @param clientName client name
     * @return project properties
     */
    Project addProject(Project project,String clientName);

    /**
     * update project details.
     *
     * @param projectName project name
     * @param project project
     * @return Updated project details
     */
    Project updateProject(String projectName,Project project);

    /**
     * Get project details
     *
     * @param projectName project name
     * @return project details
     */
    Project getProjectDetail(String projectName);

    /**
     * Delete project details.
     *
     * @param projectName project name
     * @return delete project details
     */
    Boolean deleteProjectDetail(String projectName);
}
