package com.flyers.projectAllotment.dao.impl;

import com.flyers.projectAllotment.dao.ClientDao;
import com.flyers.projectAllotment.entity.Client;
import com.flyers.projectAllotment.entity.Project;
import com.flyers.projectAllotment.exception.AppException;
import com.flyers.projectAllotment.utility.MyConnection;

import java.sql.*;

public class ClientDaoImpl implements ClientDao {

    private MyConnection Myconnection = new MyConnection();
    @Override
    public Client addClient(Client client) {

        PreparedStatement preparedStatement;
        Connection connect = null;
        Statement statement;

        try {
              connect = Myconnection.connectJdbc();

            statement =  connect.createStatement();
            int resultSet =  statement.executeUpdate("INSERT INTO CLIENT_(client_Name,contract_StartDate,contract_EndDate,projectCount) VALUE('"+client.getClientName()+"','"+client.getStartDate()+"','"+client.getEndDate()+"','"+client.getProjectCount()+"')");

            ResultSet resultSet1 =  statement.executeQuery("SELECT * FROM CLIENT_ WHERE = '"+client.getClientName()+"'");

            while (resultSet1.next()){

                int clientId = resultSet1.getInt("clientId");

                Client client1 = new Client();
                client1.setClientId(clientId);

                return client1;

            }

            Project project = new Project();
          int resultSet2 =   statement.executeUpdate("INSERT INTO PROJECT(projectName,project_StartDate,project_EndDate) VALUE('"+project.getProjectName()+"','"+project.getProjectStartDate()+"','"+project.getProjectEndDate()+"')");





        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connect.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }


        return null;
    }

    @Override
    public Client updateClient(String clientName, Client client) {

        PreparedStatement preparedStatement;
        Connection connect = null;

        String updateClientQuery = "UPDATE CLIENT_ SET contract_StartDate = (?) , contract_EndDate = (?), projectCount=(?) WHERE client_Name=(?)";
        try {
            connect = Myconnection.connectJdbc();
            preparedStatement = connect.prepareStatement(updateClientQuery);
            preparedStatement.setString(1,client.getStartDate());
            preparedStatement.setString(2,client.getEndDate());
            preparedStatement.setByte(3,client.getProjectCount());
            preparedStatement.setString(4,clientName);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connect.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }

        return null;
    }

    @Override
    public Client getClientDetail(String clientName) {


        Connection connect = null;
        Statement statement;

        String getClientQuery = "SELECT * FROM CLIENT_ WHERE client_Name=(?)";
        try {
            connect = Myconnection.connectJdbc();
           statement =  connect.createStatement();
          ResultSet resultSet =  statement.executeQuery(getClientQuery);

          while (resultSet.next()){

              Client client = new Client();
             String name =    client.getClientName();
              String start =   client.getStartDate();
              String endDate =  client.getEndDate();
              Byte count =   client.getProjectCount();

              return  client;
          }


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connect.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }


        return null;
    }

    @Override
    public Boolean deleteClientDetail(String clientName) {

        String getClientQuery = "DELETE * FROM CLIENT_ WHERE client_Name=(?)";
        Statement statement;
        Connection connect = null;
        try {
            connect = Myconnection.connectJdbc();
            statement =  connect.createStatement();
            ResultSet resultSet =  statement.executeQuery(getClientQuery);

            if (resultSet.rowDeleted())
                return true;


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connect.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }
        return false;
    }
}
