package com.flyers.projectAllotment.client;

import com.flyers.projectAllotment.entity.Project;
import com.flyers.projectAllotment.service.ProjectService;
import com.flyers.projectAllotment.service.impl.ProjectServiceImpl;

public class ProjectClient {

    ProjectService projectService = new ProjectServiceImpl();

    public Project addProject(String name, String sDate, String eDate, int eCount,String clientName){

        Project project = new Project();
        project.setProjectName(name);
        project.setProjectStartDate(sDate);
        project.setProjectEndDate(eDate);
        project.setEmployeeCount(eCount);


      return  projectService.addProject(project,clientName);
    }

    public Project updateProject(String name, String sDate, String eDate, int eCount){

        Project project1 = new Project();
        project1.setProjectStartDate(sDate);
        project1.setProjectEndDate(eDate);
        project1.setEmployeeCount(eCount);

     return   projectService.updateProject(name,project1);
    }

    public Project getProject(String name){

     return    projectService.getProjectDetail(name);

    }

    public Boolean deleteProject(String name){

      return   projectService.deleteProjectDetail(name);
    }
}
