package com.flyers.projectAllotment.entity;

import java.util.List;

/**
 * The Client entity.
 */
public class Client {

    private  int clientId;
    private  String clientName;

    private  String startDate;

    private  String endDate;

    private  byte projectCount;

    private List<Project> projects;

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public byte getProjectCount() {
        return projectCount;
    }

    public void setProjectCount(byte projectCount) {
        this.projectCount = projectCount;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }
}
