package com.flyers.projectAllotment.client;

import com.flyers.projectAllotment.entity.Client;
import com.flyers.projectAllotment.entity.Project;
import com.flyers.projectAllotment.service.ClientService;
import com.flyers.projectAllotment.service.impl.ClientServiceImpl;

import java.util.List;

public class Client_Client {

    private ClientService clientService = new ClientServiceImpl();

    public Client addClient(String clientName, String startDate, String endDate, byte projectCount,String projectName,String Date,String end,int employeeCount){

        Client client = new Client();
        client.setClientName(clientName);
        client.setStartDate(startDate);
        client.setEndDate(endDate);
        client.setProjectCount(projectCount);

        Project project = new Project();
        project.setProjectName(projectName);
        project.setProjectStartDate(Date);
        project.setProjectEndDate(end);
        project.setEmployeeCount(employeeCount);


      return  clientService.addClient(client);
    }

    public Client updateClient(String clientName,String startDate,String endDate,Byte count){

        Client client1 = new Client();
        client1.setStartDate(startDate);
        client1.setEndDate(endDate);
        client1.setProjectCount(count);

        return  clientService.updateClient(clientName,client1);
    }

    public Client getClient(String clientName){

     return  clientService.getClientDetail(clientName);

    }

    public Boolean deleteClient(String clientName){

      return   clientService.deleteClientDetail(clientName);
    }

}
