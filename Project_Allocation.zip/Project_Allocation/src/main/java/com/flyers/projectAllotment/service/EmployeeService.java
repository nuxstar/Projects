package com.flyers.projectAllotment.service;
import com.flyers.projectAllotment.entity.Employee;

/**
 * The employee service.
 */
public interface EmployeeService {

    /**
     *Add employee details.
     *
     * @param employee employee
     * @return employee properties
     */
    Employee addEmployee(Employee employee,String projectName,String clientName);

    /**
     * Update employee details.
     *
     * @param employeeMail employeeMail
     * @param employee employee
     * @return updated employee details
     */
    Employee updateEmployee(String employeeMail,Employee employee);

    /**
     * Get employee details.
     *
     * @param employeeMail employeeMail
     * @return employee details
     */
    Employee getEmployee(String employeeMail);

    /**
     * Delete employee details.
     *
     * @param employeeMail employeeMail
     * @return delete employee details
     */
    Boolean deleteEmployee(String employeeMail);

}
