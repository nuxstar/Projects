package com.flyers.projectAllotment.entity;
import java.util.List;

/**
 * The employee entity.
 */
public class Employee {

    private int employeeId;

    private String employeeName;

    private String employeeDesignation;

    private  String employeeMail;

    private List<Skill> skills;
    private Project project;
    private Client client;

    public String getEmployeeMail() {
        return employeeMail;
    }

    public void setEmployeeMail(String employeeMail) {
        this.employeeMail = employeeMail;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeDesignation() {
        return employeeDesignation;
    }

    public void setEmployeeDesignation(String employeeDesignation) {
        this.employeeDesignation = employeeDesignation;
    }

    public List<Skill> getSkill() { return skill;}

    public void setSkill(List<Skill> skill) { this.skill = skill;}
}
