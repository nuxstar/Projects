package com.flyers.projectAllotment.service.impl;

import com.flyers.projectAllotment.dao.ClientDao;
import com.flyers.projectAllotment.dao.impl.ClientDaoImpl;
import com.flyers.projectAllotment.entity.Client;
import com.flyers.projectAllotment.entity.Project;
import com.flyers.projectAllotment.service.ClientService;

public class ClientServiceImpl implements ClientService {

    private ClientDao clientDao = new ClientDaoImpl();

    @Override
    public Client addClient(Client client) {

        return clientDao.addClient(client);
    }

    @Override
    public Client updateClient(String clientName, Client client) {

        return  clientDao.updateClient(clientName,client);

    }

    @Override
    public Client getClientDetail(String clientName) {

      return  clientDao.getClientDetail(clientName);

    }

    @Override
    public Boolean deleteClientDetail(String clientName) {

     return    clientDao.deleteClientDetail(clientName);

    }
}
