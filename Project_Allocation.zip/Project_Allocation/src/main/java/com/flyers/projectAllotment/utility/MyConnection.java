package com.flyers.projectAllotment.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    /**
     *
     * Connect JDBC Driver
     *
     */
    private final String user = "root";
    private final String pass = "admin";
    private final String url = "jdbc:mysql://localhost:3306/Project_Allocation";

    public Connection connectJdbc() throws SQLException {

        Connection connect = DriverManager.getConnection(url,user,pass);

        return connect;
    }
}
