package com.flyers.projectAllotment.dao.impl;

import com.flyers.projectAllotment.dao.EmployeeDao;
import com.flyers.projectAllotment.entity.Employee;

public class EmployeeDoaImpl implements EmployeeDao {
    @Override
    public Employee addEmployee(Employee employee, String projectName, String clientName) {
        return null;
    }

    @Override
    public Employee updateEmployee(String employeeMail, Employee employee) {
        return null;
    }

    @Override
    public Employee getEmployee(String employeeMail) {
        return null;
    }

    @Override
    public Boolean deleteEmployee(String employeeMail) {
        return null;
    }
}
