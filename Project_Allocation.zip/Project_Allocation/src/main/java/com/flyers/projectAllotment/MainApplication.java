package com.flyers.projectAllotment;

import com.flyers.projectAllotment.client.Client_Client;
import com.flyers.projectAllotment.client.ProjectClient;
import com.flyers.projectAllotment.entity.Client;
import com.flyers.projectAllotment.entity.Employee;
import com.flyers.projectAllotment.entity.Project;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class MainApplication {

    public static void main(String[] args) {

        Client_Client client = new Client_Client();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose Which Module You Want to Enter :");
        System.out.println("Enter 1 to Client :");
        System.out.println("Enter 2 to Project :");
        System.out.println("Enter 3 to Employee :");
        int module = scanner.nextInt();

        switch (module){
            case 1:{
                System.out.println("Enter Which Action You Want to perform in Client Module :");
                System.out.println("Enter 1 to ADD Client Details :");
                System.out.println("Enter 2 to Update Client Details :");
                System.out.println("Enter 3 to Get Client Details :");
                System.out.println("Enter 4 to Delete Client Details :");
                int clientAction = scanner.nextInt();

                switch (clientAction){

                    case 1:{
                        System.out.println("Enter Client Name :");
                        String clientName = scanner.next();
                        System.out.println("Enter Start Date :");
                        String startDate = scanner.next();
                        System.out.println("Enter End Date :");
                        String endDate = scanner.next();
                        System.out.println("Enter Project Count :");
                        Byte count = scanner.nextByte();
                        List<Project> projects = new ArrayList<>();
                        Project project = new Project();
                        for (int i=0; i<count; i++){
                            System.out.println("Enter Project Name :");
                            project.setProjectName(scanner.next());
                            System.out.println("Enter Project start date :");
                            project.setProjectStartDate(scanner.next());
                            System.out.println("Enter Project End date :");
                            project.setProjectEndDate(scanner.next());
                            System.out.println("Enter Employee Count :");
                            project.setEmployeeCount(scanner.nextInt());
                            projects.add(project);
                        }

                     Client result  =   client.addClient(clientName,startDate,endDate,count, project.getProjectName(), project.getProjectStartDate(), project.getProjectEndDate(), project.getEmployeeCount());
                        if (Objects.nonNull(result)){
                            System.out.println("Client Id :"+result.getClientId());
                        }
                     System.out.println("Client Added Successfully");

                     break;
                    }
                    case 2:{

                        System.out.println("Enter Client Name You Want To Update :");
                        String clientName = scanner.next();
                        System.out.println("Enter To Update Start Date :");
                        String startDate = scanner.next();
                        System.out.println("Enter To Update  End Date :");
                        String endDate = scanner.next();
                        System.out.println("Enter To Update  Project Count :");
                        Byte count = scanner.nextByte();

                        Client result  =   client.updateClient(clientName,startDate,endDate,count);
                        System.out.println("Client Updated Successfully");
                    }
                    case 3:{

                        System.out.println("Enter Client Name You Want To Get :");
                        String clientName = scanner.next();

                     Client result =   client.getClient(clientName);

                     if (Objects.nonNull(result))
                                System.out.println("Project Name :"+result.getClientName()+" "+"Project Count :"+result.getProjectCount());
                     else
                         System.out.println("Something went Wrong :");
                    }
                    case 4:{

                        System.out.println("Enter Client Name You Want To Delete :");
                        String clientName = scanner.next();

                      Boolean bool =  client.deleteClient(clientName);

                      if (bool)
                          System.out.println("Successfully Deleted :");
                      else
                          System.out.println("Something Went Wrong!!!");
                    }
                }

                break;
            }
            case 2:{

                System.out.println("Enter Which Action You Want to perform in Project Module :");
                System.out.println("Enter 1 to ADD Project Details :");
                System.out.println("Enter 2 to Update Project Details :");
                System.out.println("Enter 3 to Get Project Details :");
                System.out.println("Enter 4 to Delete Project Details :");
                int projectAction = scanner.nextInt();

                ProjectClient projectClient = new ProjectClient();

                switch (projectAction){

                    case 1:{
                        System.out.println("Enter Client Name :");
                        String clientName = scanner.next();
                        System.out.println("Enter Project Name :");
                        String projectName = scanner.next();
                        System.out.println("Enter Start Date :");
                        String startDate = scanner.next();
                        System.out.println("Enter End Date :");
                        String endDate = scanner.next();
                        System.out.println("Enter Employee Count :");
                        int count = scanner.nextByte();
                        List<Employee> employees = new ArrayList<>();
                        Employee employee = new Employee();
                        for (int i=0; i<count; i++){
                            System.out.println("Enter Employee Name :");
                            employee.setEmployeeName(scanner.next());
                            System.out.println("Enter Employee Designation :");
                            employee.setEmployeeName(scanner.next());
                            System.out.println("Enter Employee Email :");
                            employee.setEmployeeName(scanner.next());
                            employees.add(employee);
                        }

                      Project project =   projectClient.addProject(projectName,startDate,endDate,count,clientName);

                      System.out.println("Project Added Successfully");

                      break;
                    }

                    case 2:{

                        System.out.println("Enter Project Name You Want To Update :");
                        String projectName = scanner.next();
                        System.out.println("Enter To Update Start Date :");
                        String startDate = scanner.next();
                        System.out.println("Enter To Update  End Date :");
                        String endDate = scanner.next();
                        System.out.println("Enter To Update  Employee Count :");
                        System.out.println("Enter To Update  Employee Count :");
                        int employeeCount = scanner.nextInt();

                        Project result  =   projectClient.updateProject(projectName,startDate,endDate,employeeCount);
                        System.out.println("Project Updated Successfully");

                        break;
                    }

                    case 3:{

                        System.out.println("Enter Project Name You Want To Get :");
                        String ProjectName = scanner.next();

                        Project result =   projectClient.getProject(ProjectName);

                        break;
                    }

                    case 4:{

                        System.out.println("Enter Delete Name You Want To Get :");
                        String ProjectName = scanner.next();

                        Boolean result =   projectClient.deleteProject(ProjectName);

                        if (result)
                            System.out.println("Successfully Deleted");
                        else
                            System.out.println("Not Deleted");
                        break;
                    }

                    default:
                        System.out.println("Invalid Code :");

                }

                break;
            }
            case 3:{



            }

            default:
                System.out.println("Something Wrong!!!!!!!!");
        }

    }
}
