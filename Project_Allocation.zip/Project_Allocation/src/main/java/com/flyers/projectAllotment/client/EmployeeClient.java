package com.flyers.projectAllotment.client;

public class EmployeeClient {

    public void addEmployee(){



    }

    public void updateEmployee(){


    }

    public void getEmployee(){


    }

    public void deleteEmployee(){


    }
}
