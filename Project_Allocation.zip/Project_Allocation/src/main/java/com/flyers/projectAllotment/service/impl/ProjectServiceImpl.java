package com.flyers.projectAllotment.service.impl;

import com.flyers.projectAllotment.dao.ProjectDao;
import com.flyers.projectAllotment.dao.impl.ProjectDaoImpl;
import com.flyers.projectAllotment.entity.Project;
import com.flyers.projectAllotment.service.ProjectService;

public class ProjectServiceImpl implements ProjectService {

    ProjectDao projectDao = new ProjectDaoImpl();

    @Override
    public Project addProject(Project project, String clientName) {

        return projectDao.addProject(project,clientName);

    }

    @Override
    public Project updateProject(String projectName, Project project) {

       return projectDao.updateProject(projectName,project);

    }

    @Override
    public Project getProjectDetail(String projectName) {

      return   projectDao.getProjectDetail(projectName);

    }

    @Override
    public Boolean deleteProjectDetail(String projectName) {


        return projectDao.deleteProjectDetail(projectName);
    }
}
