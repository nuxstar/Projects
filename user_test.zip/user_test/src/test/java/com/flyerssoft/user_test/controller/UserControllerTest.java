package com.flyerssoft.user_test.controller;

import com.flyerssoft.user_test.entity.User;
import com.flyerssoft.user_test.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(MockitoJUnitRunner.class)
class UserControllerTest {

  private MockMvc  mockMvc;

  @Mock
  UserService userService;

  @InjectMocks
  UserController userController;

  @BeforeEach
  void setup(){
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void addUser() {
    User user = new User();
    user.setEmail("rajaramsri07@gmail.com");
    user.setName("ram");
    user.setId(1);



  }

  @Test
  void getTestDetails() {
  }
}