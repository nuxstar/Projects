package com.flyerssoft.user_test.controller;

import com.flyerssoft.user_test.entity.User;
import com.flyerssoft.user_test.service.UserService;
import com.flyerssoft.user_test.service.impl.UserServiceImpl;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    private UserService userService = new UserServiceImpl();

    @PostMapping("/user")
    public  User  addUser(@RequestBody  User user){
     User addUserResponse =  userService.addUser(user);
     return addUserResponse;
    }

    @GetMapping("/test")
    public String getTestDetails(){
        return "Up";
    }

}
