package com.flyerssoft.user_test.service.impl;

import com.flyerssoft.user_test.dao.UserDao;
import com.flyerssoft.user_test.dao.impl.UserDaoImplementation;
import com.flyerssoft.user_test.entity.User;
import com.flyerssoft.user_test.service.UserService;

public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDaoImplementation();

    @Override
    public User addUser(User user) {
        return userDao.addUser(user);
    }
}
