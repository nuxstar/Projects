package com.flyerssoft.user_test.dao;

import com.flyerssoft.user_test.entity.User;

/**
 * The user dao
 */
public interface UserDao {

    /**
     * Add user details.
     *
     * @param user user
     * @return user properties
     */
    User addUser(User user);
}
