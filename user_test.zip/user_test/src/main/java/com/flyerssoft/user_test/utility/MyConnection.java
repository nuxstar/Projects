package com.flyerssoft.user_test.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    private final String user = "root";
    private final String pass = "admin";
    private final String url = "jdbc:mysql://localhost:3306/UserDetail";

    public Connection  connectJdbc() throws SQLException {

        Connection connection =  DriverManager.getConnection(url,user,pass);

        return connection;
    }
}
