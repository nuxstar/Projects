package com.flyerssoft.user_test.service;

import com.flyerssoft.user_test.entity.User;

public interface UserService {

    User addUser(User user);
}
