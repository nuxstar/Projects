package com.flyerssoft.user_test.exception;

public class AppException extends RuntimeException{

    public AppException(String message){

        super(message);
    }
}
