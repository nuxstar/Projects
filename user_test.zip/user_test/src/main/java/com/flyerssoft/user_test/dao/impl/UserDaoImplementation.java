package com.flyerssoft.user_test.dao.impl;

import com.flyerssoft.user_test.dao.UserDao;
import com.flyerssoft.user_test.entity.User;
import com.flyerssoft.user_test.exception.AppException;
import com.flyerssoft.user_test.utility.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDaoImplementation implements UserDao {

    private MyConnection myConnection = new MyConnection();

    @Override
    public User addUser(User user) {

        Connection connection=null;
        Statement statement;

        String addUserQuery = "INSERT INTO USERINFORMATION(UserName,Age,Email) VALUE ('"+user.getName()+"','"+user.getAge()+"','"+user.getEmail()+"')";

        String getAddedUserQuery = "SELECT * FROM USERINFORMATION WHERE USERNAME = '"+user.getName()+"'";

        try {
             connection = myConnection.connectJdbc();
             statement =  connection.createStatement();
             int result = statement.executeUpdate(addUserQuery);

             if (result == 1){

              ResultSet resultSet =  statement.executeQuery(getAddedUserQuery);

              if (resultSet.next()){

               int userId = resultSet.getInt("Id");

               user.setId(userId);

              }
             }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }


        return user;
    }
}
