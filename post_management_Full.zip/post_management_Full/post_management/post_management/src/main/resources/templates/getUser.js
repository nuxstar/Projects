 const onClickGetUser = async (e) => {
    e.preventDefault();
    const rawResponse = await fetch("http://localhost:8080/user/15");
    const response = await rawResponse.json();
    console.log("raw response", rawResponse);
    console.log("response", response);
  }