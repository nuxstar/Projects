package com.flyerssoft.post_management.service;

import com.flyerssoft.post_management.dto.UserDto;

public interface UserService {

    /**
     * Add user details.
     *
     * @param userDto userDto
     * @return user details
     */
    UserDto addUser(UserDto userDto);

    /**
     * Get user details.
     *
     * @param userId userid
     * @return user details
     */
    UserDto getUserById(int userId);

    /**
     * Delete user details.
     *
     * @param userId userId
     * @return boolean message
     */
    Boolean deleteUser(int userId);
}
