package com.flyerssoft.post_management.htmlController;

import com.flyerssoft.post_management.controller.UserController;
import com.flyerssoft.post_management.dto.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

    @Autowired
    UserController userController;

        @RequestMapping(value = "/user")
        public String user() {
            return "usergetPage.html";
        }
        @RequestMapping(value = "/loginPage.html")
        public String login() {
            return "loginPage.html";
        }


}
