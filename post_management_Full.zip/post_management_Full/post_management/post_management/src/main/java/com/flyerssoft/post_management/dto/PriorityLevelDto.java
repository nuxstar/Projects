package com.flyerssoft.post_management.dto;
/**
 * The PriorityLevelDto entity
 */
public enum PriorityLevelDto {
    CRITICAL,
    HIGH,
    NORMAL;

}
