package com.flyerssoft.post_management.controller;

import com.flyerssoft.post_management.dto.TicketDto;
import com.flyerssoft.post_management.service.TicketService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The TicketController
 */
@RestController
public class TicketController {

    Logger logger = LoggerFactory.getLogger(TicketController.class);

    @Autowired
    TicketService ticketService;

    @PostMapping("ticket/{userId}")
    public TicketDto addTicket(@PathVariable int userId, @RequestBody TicketDto ticketDto) {
        logger.info("Add Ticket Method Accessed..........");
        return ticketService.addTicket(userId, ticketDto);
    }

    @GetMapping("ticket/{ticketId}")
    public TicketDto getTicket(@PathVariable int ticketId){
      return ticketService.getTicketById(ticketId);
    }

    @DeleteMapping("ticket/{ticketId}")
    public Boolean deleteTicket(@PathVariable int ticketId) {
        logger.info("Delete Ticket Method Accessed..........");
        return ticketService.deleteTicket(ticketId);
    }
}
