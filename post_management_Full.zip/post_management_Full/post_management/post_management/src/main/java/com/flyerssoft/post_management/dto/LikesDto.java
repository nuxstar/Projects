package com.flyerssoft.post_management.dto;


import com.flyerssoft.post_management.entity.Comment;
import com.flyerssoft.post_management.entity.Ticket;
import com.flyerssoft.post_management.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class LikesDto {
    private int likeId;
    private User user;
    private Ticket ticket;
    private Comment comment;
}
