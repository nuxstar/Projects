package com.flyerssoft.post_management.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * The Like entity
 */
@Entity
@Getter
@Setter
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public abstract class Likes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int likeId;

    @ManyToOne
    @JoinColumn
    private User user;
}
