package com.flyerssoft.post_management.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * The ticket entity
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;
    private String ticketTitle;
    private String ticketDescription;
    private int ticket_Like_Count;
    @Enumerated(EnumType.STRING)
    private PriorityLevel priorityLevel;
    @ManyToOne
    private User user;
    @OneToMany(mappedBy = "ticket", orphanRemoval = true)
    private List<Comment> comments;
}
