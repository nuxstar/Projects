package com.flyerssoft.post_management.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.flyerssoft.post_management.entity.Ticket;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UserDto {

    private Long userId;
    @NotNull
    @Size(min = 1,max = 25,message = "Character Must Be In 1 to 25")
    private String userName;
    @Email
    private String userMail;;
}
