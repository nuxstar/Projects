package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.*;
import com.flyerssoft.post_management.dto.LikesDto;
import com.flyerssoft.post_management.dto.LikesPostDto;
import com.flyerssoft.post_management.entity.*;
import com.flyerssoft.post_management.exception.NotFoundException;
import com.flyerssoft.post_management.service.LikesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LikesServiceImpl implements LikesService {
    @Autowired
    UserRepo userRepository;
    @Autowired
    CommentRepo commentRepository;
    @Autowired
    TicketLikeRepo ticketLikeRepo;
    @Autowired
    TicketRepo ticketRepository;
    @Autowired
    CommentLikeRepo commentLikeRepo;

    Logger logger = LoggerFactory.getLogger(LikesServiceImpl.class);

    @Override
    public LikesDto addLike(LikesPostDto likesPostDto) {
        logger.info("Method Started For Like The Ticket");
        userRepository.findById(likesPostDto.getUserId()).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepository.findById(likesPostDto.getUserId()).get();

        if (likesPostDto.getLikeType().contains("ticket")) {
            ticketRepository.findById(likesPostDto.getEntityId()).orElseThrow(() -> new NotFoundException("Ticket not found..."));
            Optional<Ticket> ticket = ticketRepository.findById(likesPostDto.getEntityId());
            Ticket ticketDetails = ticket.get();
            int actualCount = ticketDetails.getTicket_Like_Count();
            actualCount++;
            ticketDetails.setTicket_Like_Count(actualCount);
            TicketLike t = new TicketLike();
            t.setUser(user);
            t.setTicket(ticketDetails);
            ticketLikeRepo.save(t);
            LikesDto likesDto = new LikesDto();
            likesDto.setUser(user);
            likesDto.setTicket(t.getTicket());
            logger.info("Ticket Liked By User");
            return likesDto;

        } else {
            logger.info("Method Started For Like The Comment");
            commentRepository.findById(likesPostDto.getEntityId()).orElseThrow(() -> new NotFoundException("Comment not found..."));
            Optional<Comment> comment = commentRepository.findById(likesPostDto.getEntityId());
            Comment commentDetails = comment.get();
            int actualCount = commentDetails.getComment_Like_Count();
            actualCount++;
            commentDetails.setComment_Like_Count(actualCount);
            CommentLike like = new CommentLike();
            like.setUser(user);
            like.setComment(commentDetails);
            commentLikeRepo.save(like);
            LikesDto likesDto = new LikesDto();
            likesDto.setUser(user);
            likesDto.setComment(like.getComment());
            logger.info("Comment Liked By User");
            return likesDto;
        }

    }

    @Override
    public List<CommentLike> getAllCmtLike() {
         return commentLikeRepo.findAll();

    }

    @Override
    public List<TicketLike> getAllTicketLike() {
        return ticketLikeRepo.findAll();
    }


}
