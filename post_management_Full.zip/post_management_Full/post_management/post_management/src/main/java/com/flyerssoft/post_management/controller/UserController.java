package com.flyerssoft.post_management.controller;

import com.flyerssoft.post_management.dto.UserDto;
import com.flyerssoft.post_management.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * The UserController
 */
@RestController
public class UserController {
    Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    UserService userService;

    @PostMapping("/user")
    public UserDto addUser(@RequestBody UserDto userDto ) {
        logger.info("Add User Method Accessed..........");
        return userService.addUser(userDto);
    }

    @GetMapping("user/{userId}")
    public UserDto getUser(@PathVariable int userId){
        return userService.getUserById(userId);
    }

    @DeleteMapping("user/{userId}")
    public Boolean deleteUser(@PathVariable int userId) {
        logger.info("Delete User Method Accessed..........");
        return userService.deleteUser(userId);
    }
}
