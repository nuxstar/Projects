package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.CommentRepo;
import com.flyerssoft.post_management.Repository.TicketRepo;
import com.flyerssoft.post_management.Repository.UserRepo;
import com.flyerssoft.post_management.dto.CommentDto;
import com.flyerssoft.post_management.entity.Comment;
import com.flyerssoft.post_management.entity.Ticket;
import com.flyerssoft.post_management.entity.User;
import com.flyerssoft.post_management.exception.NotFoundException;
import com.flyerssoft.post_management.service.CommentService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    TicketRepo ticketRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    CommentRepo commentRepo;

    Logger logger = LoggerFactory.getLogger(CommentServiceImpl.class);

    @Override
    public CommentDto addComment(int userId, int ticketId, CommentDto commentDto) {
        logger.info("Method Started For Add Comment");
        userRepo.findById(userId).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepo.findById(userId).get();
        ticketRepo.findById(ticketId).orElseThrow(() -> new NotFoundException("Ticket not found..."));
        Ticket ticket = ticketRepo.findById(ticketId).get();
        Comment commentRequest = modelMapper.map(commentDto, Comment.class);
        commentRequest.setUser(user);
        commentRequest.setTicket(ticket);
        Comment commentResponse = commentRepo.save(commentRequest);
        logger.info("Comment Added Successfully");
        return modelMapper.map(commentResponse, CommentDto.class);
    }

    @Override
    public CommentDto getComment(int cmtId) {
        logger.info("Method Started For Get Comment");
        commentRepo.findById(cmtId).orElseThrow(()-> new NotFoundException("Comment not found"));
        Comment commentResponse = commentRepo.findById(cmtId).get();
        return modelMapper.map(commentResponse,CommentDto.class);
    }

    @Override
    public Boolean deleteComment(int commentId) {
        logger.info("Method Started For Delete Comment");
        Comment comment = commentRepo.findById(commentId).orElseThrow(() -> new NotFoundException("Ticket Does Not Exist"));
        commentRepo.deleteById(commentId);
        logger.info("Comment Deleted Successfully");
        return true;
    }
}
