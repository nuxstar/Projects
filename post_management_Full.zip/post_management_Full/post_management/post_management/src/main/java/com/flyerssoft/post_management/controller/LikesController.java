package com.flyerssoft.post_management.controller;

import com.flyerssoft.post_management.dto.LikesDto;
import com.flyerssoft.post_management.dto.LikesPostDto;
import com.flyerssoft.post_management.entity.TicketLike;
import com.flyerssoft.post_management.service.LikesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class LikesController {

    Logger logger = LoggerFactory.getLogger(LikesController.class);

    @Autowired
    LikesService likesService;

    @PostMapping("like")
    public LikesDto addLike(@RequestBody LikesPostDto likesPostDto){
        logger.info("Add Like Method Accessed.....");
     return likesService.addLike(likesPostDto);
    }
    @GetMapping("like")
    public List<TicketLike> getAllTicketLike(){
       return likesService.getAllTicketLike();
    }
}
