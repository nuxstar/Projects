package com.flyerssoft.post_management.service.impl;

import com.flyerssoft.post_management.Repository.TicketRepo;
import com.flyerssoft.post_management.Repository.UserRepo;
import com.flyerssoft.post_management.dto.TicketDto;
import com.flyerssoft.post_management.entity.Ticket;
import com.flyerssoft.post_management.entity.User;
import com.flyerssoft.post_management.exception.NotFoundException;
import com.flyerssoft.post_management.service.TicketService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketServiceImpl implements TicketService {
    @Autowired
    TicketRepo ticketRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    ModelMapper modelMapper;
    Logger logger = LoggerFactory.getLogger(TicketServiceImpl.class);

    @Override
    public TicketDto addTicket(int userId, TicketDto ticketDto) {
        logger.info("Method Started For Add Ticket");
        userRepo.findById(userId).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepo.findById(userId).get();
        Ticket ticketRequest = modelMapper.map(ticketDto, Ticket.class);
        ticketRequest.setUser(user);
        Ticket ticketResponse = ticketRepo.save(ticketRequest);
        logger.info("Ticket Added Successfully");
        return modelMapper.map(ticketResponse, TicketDto.class);
    }

    @Override
    public TicketDto getTicketById(int ticketId) {
        logger.info("Method Started For Get Ticket");
        ticketRepo.findById(ticketId).orElseThrow(() -> new NotFoundException("Ticket Does Not Exist"));
        Ticket ticketResponse = ticketRepo.findById(ticketId).get();
        return modelMapper.map(ticketResponse,TicketDto.class);
    }

    @Override
    public Boolean deleteTicket(int ticketId) {
        logger.info("Method Started For Delete Ticket");
        ticketRepo.findById(ticketId).orElseThrow(() -> new NotFoundException("Ticket Does Not Exist"));
        ticketRepo.deleteById(ticketId);
        logger.info("Ticket Deleted Successfully");
        return true;
    }
}
