package com.flyerssoft.post_management.dto;

import com.flyerssoft.post_management.entity.User;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TicketDto {

    private Long ticketId;
    @NotBlank
    private String ticketTitle;
    @NotBlank
    private String ticketDescription;
    private int ticket_Like_Count;
    private User user;

}
