package com.flyerssoft.post_management.service;


import com.flyerssoft.post_management.dto.LikesDto;
import com.flyerssoft.post_management.dto.LikesPostDto;
import com.flyerssoft.post_management.entity.CommentLike;
import com.flyerssoft.post_management.entity.TicketLike;

import java.util.List;

public interface LikesService {
    LikesDto addLike(LikesPostDto likesPostDto);
    List<CommentLike> getAllCmtLike();
    List<TicketLike> getAllTicketLike();
}
