package com.flyerssoft.ComicInformation.controller;

import com.flyerssoft.ComicInformation.entity.Comic;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.service.ComicService;
import com.flyerssoft.ComicInformation.service.impl.ComicServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * The comic controller
 */
@RestController
public class ComicController {
    @Autowired
    private  ComicService comicService;

    @PostMapping("/comic")
    public  Comic  addComic(@RequestBody Comic comic){
        return comicService.addComic(comic);
    }
}
