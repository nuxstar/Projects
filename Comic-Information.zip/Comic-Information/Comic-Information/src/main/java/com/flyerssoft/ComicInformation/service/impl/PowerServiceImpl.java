package com.flyerssoft.ComicInformation.service.impl;

import com.flyerssoft.ComicInformation.dao.PowerDao;
import com.flyerssoft.ComicInformation.dao.impl.PowerDaoImpl;
import com.flyerssoft.ComicInformation.entity.Power;
import com.flyerssoft.ComicInformation.service.PowerService;
import org.springframework.stereotype.Service;

/**
 * The power service implementation
 */
@Service
public class PowerServiceImpl implements PowerService {

    private final PowerDao powerDao = new PowerDaoImpl();
    @Override
    public Power getPower(int powerId) {
        return powerDao.getPower(powerId);
    }

    @Override
    public Boolean deletePower(int powerId) {
        return powerDao.deletePower(powerId);
    }
}
