package com.flyerssoft.ComicInformation.controller;

import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.service.SuperHeroService;
import com.flyerssoft.ComicInformation.service.impl.SuperHeroServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The superhero controller
 */
@RestController
public class SuperHeroController {
    private  final SuperHeroService superHeroService = new SuperHeroServiceImpl();

    @PutMapping("/superhero/{heroId}")
    public SuperHero updateSuperHero(@PathVariable int heroId, @RequestBody SuperHero superHero){
        return superHeroService.updateSuperHero(heroId,superHero);
    }

    @GetMapping("/superhero")
    public List<SuperHero> getAllHero(){
     return superHeroService.getAllHero();
    }

}
