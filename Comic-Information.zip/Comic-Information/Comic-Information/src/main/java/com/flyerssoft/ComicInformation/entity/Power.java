package com.flyerssoft.ComicInformation.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * The power entity
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Power {

    private int powerId;
    private String powerName;
    private List<SuperHero> superHeroes;

    public List<SuperHero> getSuperHeroes() {
        return superHeroes;
    }

    public void setSuperHeroes(List<SuperHero> superHeroes) {
        this.superHeroes = superHeroes;
    }

    public int getPowerId() {
        return powerId;
    }

    public void setPowerId(int powerId) {
        this.powerId = powerId;
    }

    public String getPowerName() {
        return powerName;
    }

    public void setPowerName(String powerName) {
        this.powerName = powerName;
    }

}
