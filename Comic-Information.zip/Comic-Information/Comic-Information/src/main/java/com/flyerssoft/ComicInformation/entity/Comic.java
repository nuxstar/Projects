package com.flyerssoft.ComicInformation.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * The comic entity
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Comic {
    private  int comicId;
    private String comicName;
    private List<SuperHero> superHeroes;

    public int getComicId() {
        return comicId;
    }

    public void setComicId(int comicId) {
        this.comicId = comicId;
    }

    public String getComicName() {
        return comicName;
    }

    public void setComicName(String comicName) {
        this.comicName = comicName;
    }

    public List<SuperHero> getSuperHeroes() {
        return superHeroes;
    }

    public void setSuperHeroes(List<SuperHero> superHeroes) {
        this.superHeroes = superHeroes;
    }
}
