package com.flyerssoft.ComicInformation.dao;

import com.flyerssoft.ComicInformation.entity.Comic;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import java.util.List;

/**
 * The comic dao
 */
public interface ComicDao {

    /**
     * Add comic details.
     *
     * @param comic comic
     * @param superHeroes superheros
     * @return comic details
     */
    Comic addComic(Comic comic);
}
