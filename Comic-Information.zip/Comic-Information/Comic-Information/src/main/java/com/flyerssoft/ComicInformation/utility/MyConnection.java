package com.flyerssoft.ComicInformation.utility;

import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * The connection class
 */
@Component
public class MyConnection {
    private final String url = "jdbc:mysql://localhost:3306/Comic_Information";
    private  final String user = "root";
    private final  String pass = "admin";
    public  Connection ConnectJDBC() throws SQLException {
      Connection connection =  DriverManager.getConnection(url,user,pass);
      return connection;
    }
}
