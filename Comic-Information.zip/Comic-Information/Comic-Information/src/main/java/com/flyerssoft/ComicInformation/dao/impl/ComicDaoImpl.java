package com.flyerssoft.ComicInformation.dao.impl;

import com.flyerssoft.ComicInformation.dao.ComicDao;
import com.flyerssoft.ComicInformation.entity.Comic;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.exception.AppException;
import com.flyerssoft.ComicInformation.utility.MyConnection;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * The comic dao implementation
 */
public class ComicDaoImpl implements ComicDao {

    @Autowired
    private MyConnection myConnection;

    @Override
    public Comic addComic(Comic comic) {

        Connection connection;
        Statement statement;

        String addComicDetailQuery = "INSERT INTO COMIC (COMICNAME) VALUE ('"+comic.getComicName()+"')";
        try {
         connection =    myConnection.ConnectJDBC();
         statement = connection.createStatement();
         int addResult = statement.executeUpdate(addComicDetailQuery);
         if (addResult == 1){
             String getComicDetailQuery = "SELECT * FROM COMIC WHERE COMICNAME='"+comic.getComicName()+"'";
             ResultSet getResult = statement.executeQuery(getComicDetailQuery);
             if (getResult.next()){
                 int comicId = getResult.getInt("COMICID");
                 comic.setComicId(comicId);
             }
         }
         if (Objects.nonNull(comic.getSuperHeroes())){
           List<SuperHero> superHeroes =   comic.getSuperHeroes();
           for (SuperHero hero :superHeroes) {
              String heroName =  hero.getHeroName();
              int age = hero.getHeroAge();
              String addHeroQuery = "INSERT INTO HERO(HERONAME,HEROAGE,COMICID) VALUE('"+heroName+"','"+age+"','"+comic.getComicId()+"')";
              statement.executeUpdate(addHeroQuery);
             }
             String getHeroDetailQuery = "SELECT * FROM HERO WHERE COMICID='"+comic.getComicId()+"'";
             ResultSet getResult = statement.executeQuery(getHeroDetailQuery);
             List<SuperHero> superHeroes1 = new ArrayList<>();
             while (getResult.next()){
                 int id = getResult.getInt("HEROID");
                 String name = getResult.getString("HERONAME");
                 int age = getResult.getInt("HEROAGE");

                 SuperHero superHero = new SuperHero();
                 superHero.setHeroId(id);
                 superHero.setHeroName(name);
                 superHero.setHeroAge(age);
                 superHeroes1.add(superHero);
             }
             comic.setSuperHeroes(superHeroes1);
         }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return comic;
    }
}
