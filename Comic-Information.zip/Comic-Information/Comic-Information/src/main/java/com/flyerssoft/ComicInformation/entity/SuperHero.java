package com.flyerssoft.ComicInformation.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * The superhero entity
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SuperHero {

    private  int heroId;
    private  String heroName;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private int heroAge;
    private  List<Power> powers;

    public int getHeroId() {
        return heroId;
    }

    public void setHeroId(int heroId) {
        this.heroId = heroId;
    }

    public String getHeroName() {
        return heroName;
    }

    public void setHeroName(String heroName) {
        this.heroName = heroName;
    }

    public List<Power> getPowers() {
        return powers;
    }

    public void setPowers(List<Power> powers) {
        this.powers = powers;
    }

    public int getHeroAge() {
        return heroAge;
    }

    public void setHeroAge(int heroAge) {
        this.heroAge = heroAge;
    }
}
