package com.flyerssoft.ComicInformation.controller;

import com.flyerssoft.ComicInformation.entity.Power;
import com.flyerssoft.ComicInformation.service.PowerService;
import com.flyerssoft.ComicInformation.service.impl.PowerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * The power controller
 */
@RestController
public class PowerController {

    @Autowired
    private PowerService powerService;

    @GetMapping("/power/{powerId}")
   public Power getPower(@PathVariable int powerId){
   return powerService.getPower(powerId);
    }

    @DeleteMapping("/power/{powerId}")
    public Boolean deletePower(@PathVariable int powerId){
        return powerService.deletePower(powerId);
    }

}
