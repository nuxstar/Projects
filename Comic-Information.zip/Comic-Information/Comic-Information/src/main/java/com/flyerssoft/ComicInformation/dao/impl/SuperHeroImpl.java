package com.flyerssoft.ComicInformation.dao.impl;

import com.flyerssoft.ComicInformation.dao.SuperHeroDao;
import com.flyerssoft.ComicInformation.entity.Power;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.exception.AppException;
import com.flyerssoft.ComicInformation.exception.NotFoundException;
import com.flyerssoft.ComicInformation.utility.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 * The superhero implementation
 */
public class SuperHeroImpl implements SuperHeroDao {
    private final MyConnection myConnection = new MyConnection();
    @Override
    public SuperHero updateSuperHero(int heroId,SuperHero superHero) {

        Connection connection;
        Statement statement;
        String checkHeroQuery="SELECT HEROID FROM HERO WHERE HEROID='"+heroId+"'";

        String updateQuery= null;
        if (Objects.nonNull(superHero.getHeroAge())){
            updateQuery= "UPDATE HERO SET HEROAGE='"+superHero.getHeroAge()+"' WHERE HEROID='"+heroId+"' ";
        }

        String getUpdatedHeroQuery = "SELECT * FROM HERO WHERE HEROID='"+heroId+"'";
        try {
             connection =   myConnection.ConnectJDBC();
             statement = connection.createStatement();
             ResultSet checkResult = statement.executeQuery(checkHeroQuery);
            if (!checkResult.next()){
                throw new NotFoundException("Hero Not Found!!!!!");
            }
            int updateResult = statement.executeUpdate(updateQuery);
            if (updateResult==1){
               ResultSet updateResultSet =  statement.executeQuery(getUpdatedHeroQuery);
               if (updateResultSet.next()){
                 int id = updateResultSet.getInt("HEROID");
                 String name =  updateResultSet.getString("HERONAME");
                 int age = updateResultSet.getInt("HEROAGE");
                 superHero.setHeroId(id);
                 superHero.setHeroName(name);
                 superHero.setHeroAge(age);
               }
            }

            if (Objects.nonNull(superHero.getPowers())){

              List<Power> powerList = superHero.getPowers();
              List<Power> powerList1 = new ArrayList<>();
                for (Power power:powerList) {
                    Power powerObj = new Power();
                       String name = power.getPowerName();
                        powerObj.setPowerName(name);
                        String checkPowerNameQuery="SELECT POWERNAME FROM SPOWER WHERE POWERNAME = '"+name+"'";
                        ResultSet checkPower = statement.executeQuery(checkPowerNameQuery);
                        if (!checkPower.next()){
                            String addPowerQuery = "INSERT INTO SPOWER (POWERNAME) VALUE('"+name+"')";
                            statement.executeUpdate(addPowerQuery);
                            String getAddPowerQuery="SELECT POWERID FROM SPOWER WHERE POWERNAME = '"+name+"'";
                            ResultSet powerResult = statement.executeQuery(getAddPowerQuery);
                            if (powerResult.next()){
                                int id =  powerResult.getInt("POWERID");
                                powerObj.setPowerId(id);
                                String relationQuery = "INSERT INTO HERO_POWER(HEROID,POWERID) VALUE('"+heroId+"','"+id+"')";
                                statement.executeUpdate(relationQuery);
                            }
                        }
                        else {
                            String getExitPowerID = "SELECT POWERID FROM SPOWER WHERE POWERNAME = '"+name+"'";
                            ResultSet getExitPowerResult = statement.executeQuery(getExitPowerID);
                            if (getExitPowerResult.next()){
                                int powerId = getExitPowerResult.getInt("POWERID");
                                powerObj.setPowerId(powerId);
                                String relationQuery = "INSERT INTO HERO_POWER(HEROID,POWERID) VALUE('"+heroId+"','"+powerId+"')";
                                statement.executeUpdate(relationQuery);
                            }
                        }

                       powerList1.add(powerObj);
                }

                superHero.setPowers(powerList1);
            }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return superHero;
    }

    @Override
    public List<SuperHero> getAllHero() {

        Connection connection;
        Statement statement;
        String getHeroDetailQuery = "SELECT HEROID FROM HERO";
        List<Integer> heroIds = new ArrayList<>();
        String innerJoinQuery = "SELECT * FROM HERO INNER JOIN HERO_POWER ON HERO.HEROID = HERO_POWER.HEROID";
        try {
             connection = myConnection.ConnectJDBC();
             statement = connection.createStatement();
             ResultSet heroResult =  statement.executeQuery(getHeroDetailQuery);
             while (heroResult.next()){
                int id = heroResult.getInt("HEROID");
                heroIds.add(id);
             }

            int count = 0;
            Map<Integer,Integer> map = new HashMap<>();
            for (Integer ids: heroIds) {
                String getHeroPowerQuery = "SELECT POWERID FROM hero_power WHERE heroId= '"+ids+"'";
                ResultSet heroPowerResult = statement.executeQuery(getHeroPowerQuery);
                while (heroPowerResult.next()){
                    heroPowerResult.getInt("POWERID");
                    count++;
                }
                map.put(ids,count);
                count=0;
            }

           List<Map.Entry<Integer,Integer>> entryListist = new ArrayList<>(map.entrySet());

            Collections.sort(entryListist, new Comparator<Map.Entry<Integer, Integer>>() {
                @Override
                public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });

            List<SuperHero> superHeroList = new ArrayList<>();
            List<Integer> ids= new ArrayList<>();
            for(Map.Entry<Integer, Integer> entry : entryListist){

                String HeroDetailQuery = "SELECT * FROM HERO WHERE HEROID = '"+entry.getKey()+"'";
                ids.add(entry.getKey());
                ResultSet heroList = statement.executeQuery(HeroDetailQuery);

                while (heroList.next()){
                     int heroId =  heroList.getInt("HEROID");
                     String heroName = heroList.getString("HERONAME");
                     int heroAge = heroList.getInt("HEROAGE");

                     SuperHero superHero = new SuperHero();
                     superHero.setHeroId(heroId);
                     superHero.setHeroName(heroName);
                     superHero.setHeroAge(heroAge);
                     superHeroList.add(superHero);
                }
            }


            List<Power> powers = new ArrayList<>();
            for (Integer entry:ids) {
                String getPowersQuery = "SELECT POWERID FROM HERO_POWER WHERE HEROID= '" +entry+ "' ";
                ResultSet powerResult = statement.executeQuery(getPowersQuery);
                Set<Integer> s = new LinkedHashSet<>();
                while (powerResult.next()) {
                    int id = powerResult.getInt("POWERID");
                    s.add(id);
                }
                for (Integer i :s) {
                    String powerDetail = "SELECT * FROM SPOWER WHERE POWERID = '"+i+"'";
                   ResultSet res = statement.executeQuery(powerDetail);
                   while (res.next()){
                       int id = res.getInt("POWERID");
                       String name = res.getString("POWERNAME");
                       Power power = new Power();
                       power.setPowerId(id);
                       power.setPowerName(name);
                       powers.add(power);
                       SuperHero superHero = new SuperHero();
                       superHero.setPowers(powers);
                       superHeroList.add(superHero);
                   }

                }

            }

            return superHeroList;
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
    }
}
