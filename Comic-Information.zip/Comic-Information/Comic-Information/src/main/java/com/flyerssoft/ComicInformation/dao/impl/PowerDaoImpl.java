package com.flyerssoft.ComicInformation.dao.impl;

import com.flyerssoft.ComicInformation.dao.PowerDao;
import com.flyerssoft.ComicInformation.entity.Power;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.exception.AppException;
import com.flyerssoft.ComicInformation.exception.NotFoundException;
import com.flyerssoft.ComicInformation.utility.MyConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * The power dao implementation
 */
public class PowerDaoImpl implements PowerDao {
    private final MyConnection myConnection = new MyConnection();
    @Override
    public Power getPower(int powerId) {

        Connection connection;
        Statement statement;
        String checkPowerQuery = "SELECT * FROM SPOWER WHERE POWERID='"+powerId+"'";
        Power power = new Power();
        try {
            connection =  myConnection.ConnectJDBC();
            statement =  connection.createStatement();
            ResultSet checkPower = statement.executeQuery(checkPowerQuery);
            if (!checkPower.next()){
                throw new NotFoundException("Power Not Found!!!!");
            }
            int powId = checkPower.getInt("POWERID");
            String powName = checkPower.getString("POWERNAME");
            power.setPowerId(powId);
            power.setPowerName(powName);

            String getHeroListPowerQuery = "SELECT HEROID FROM HERO_POWER WHERE POWERID='"+powerId+"'";
            ResultSet heroIdList = statement.executeQuery(getHeroListPowerQuery);

            List<Integer> heroId = new ArrayList<>();
            while (heroIdList.next()){
               int id = heroIdList.getInt("HEROID");
               heroId.add(id);
            }

            List<SuperHero> superHeroList = new ArrayList<>();
            for (int i=0; i<heroId.size(); i++){

                String getHeroDetailQuery = "SELECT * FROM HERO WHERE HEROID='"+heroId.get(i)+"'";
                ResultSet result = statement.executeQuery(getHeroDetailQuery);

                if (result.next()){
                    int id = result.getInt("HEROID");
                    String name = result.getString("HERONAME");
                    int age =result.getInt("HEROAGE");

                    SuperHero superHero = new SuperHero();
                    superHero.setHeroId(id);
                    superHero.setHeroName(name);
                    superHero.setHeroAge(age);
                    superHeroList.add(superHero);

                }

                power.setSuperHeroes(superHeroList);
            }





        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return power;
    }

    @Override
    public Boolean deletePower(int powerId) {

        Connection connection;
        Statement statement;
        String checkPowerQuery = "SELECT POWERID FROM SPOWER WHERE POWERID='"+powerId+"'";
        String deleteHeroPowerRelationQuery = "DELETE FROM HERO_POWER WHERE POWERID='"+powerId+"' ";
        String deletePowerQuery = "DELETE FROM SPOWER WHERE POWERID='"+powerId+"'";


        try {
            connection = myConnection.ConnectJDBC();
            statement = connection.createStatement();
            ResultSet checkPowerId = statement.executeQuery(checkPowerQuery);
            if (!checkPowerId.next()){
                throw new NotFoundException("Power Not Found!!!!");
            }
            int deleteResult =  statement.executeUpdate(deleteHeroPowerRelationQuery);
            int deletePowerResult = statement.executeUpdate(deletePowerQuery);
            if (deletePowerResult == 1)
                return true;
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }


        System.out.println("success");
        return false;
    }
}
