package com.flyerssoft.ComicInformation.dto;

public class ComicDto {

}
