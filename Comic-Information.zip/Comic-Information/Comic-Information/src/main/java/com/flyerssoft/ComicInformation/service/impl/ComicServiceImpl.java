package com.flyerssoft.ComicInformation.service.impl;

import com.flyerssoft.ComicInformation.dao.ComicDao;
import com.flyerssoft.ComicInformation.dao.impl.ComicDaoImpl;
import com.flyerssoft.ComicInformation.entity.Comic;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.service.ComicService;
import java.util.List;

/**
 * The comic service implementation
 */
public class ComicServiceImpl implements ComicService {

    private  final ComicDao comicDao = new ComicDaoImpl();

    @Override
    public Comic addComic(Comic comic) {
        return comicDao.addComic(comic);
    }

}
