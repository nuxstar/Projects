package com.flyerssoft.ComicInformation.dao;

import com.flyerssoft.ComicInformation.entity.Power;

/**
 * The power dao
 */
public interface PowerDao {
    /**
     * Get power details.
     *
     * @param powerId powerId
     * @return power details
     */
    Power getPower(int powerId);

    /**
     * Delete power details.
     *
     * @param powerId powerId
     * @return delete power details
     */
    Boolean deletePower(int powerId);
}
