package com.flyerssoft.ComicInformation.service.impl;

import com.flyerssoft.ComicInformation.dao.SuperHeroDao;
import com.flyerssoft.ComicInformation.dao.impl.SuperHeroImpl;
import com.flyerssoft.ComicInformation.entity.SuperHero;
import com.flyerssoft.ComicInformation.service.SuperHeroService;
import java.util.List;

/**
 * The superhero service implementation
 */
public class SuperHeroServiceImpl implements SuperHeroService {
    private final SuperHeroDao superHeroDao = new SuperHeroImpl();
    @Override
    public SuperHero updateSuperHero(int heroId, SuperHero superHero) {
        return superHeroDao.updateSuperHero(heroId,superHero);
    }
    @Override
    public List<SuperHero> getAllHero() {

        return superHeroDao.getAllHero();
    }
}
