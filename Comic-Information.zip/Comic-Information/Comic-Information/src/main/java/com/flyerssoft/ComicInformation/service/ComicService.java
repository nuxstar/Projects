package com.flyerssoft.ComicInformation.service;

import com.flyerssoft.ComicInformation.entity.Comic;
import com.flyerssoft.ComicInformation.entity.SuperHero;

import java.util.List;

/**
 * The comic service
 */
public interface ComicService  {

    /**
     * Add comic details.
     *
     * @param comic comic
     * @param superHeroes superheros
     * @return comic details
     */
    Comic addComic(Comic comic);

}
