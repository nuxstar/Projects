package com.flyerssoft.ComicInformation.dao;

import com.flyerssoft.ComicInformation.entity.Power;
import com.flyerssoft.ComicInformation.entity.SuperHero;

import java.util.List;

/**
 * The superhero dao
 */
public interface SuperHeroDao {

    /**
     * Add superhero details.
     *
     * @param heroId heroid
     * @param powers powers
     * @return hero details
     */
    SuperHero updateSuperHero(int heroId,SuperHero superHero);


    /**
     * Get all hero details.
     *
     * @return all hero details
     */
    List<SuperHero> getAllHero();
}
