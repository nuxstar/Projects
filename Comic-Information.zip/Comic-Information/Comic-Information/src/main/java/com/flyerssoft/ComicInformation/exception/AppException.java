package com.flyerssoft.ComicInformation.exception;

public class AppException extends RuntimeException{

    public  AppException(String message){

        super(message);
    }
}
