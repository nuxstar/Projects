package com.flyerssoft.ComicInformation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComicInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
