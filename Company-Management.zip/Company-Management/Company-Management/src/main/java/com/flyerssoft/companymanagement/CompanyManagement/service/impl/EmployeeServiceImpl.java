package com.flyerssoft.companymanagement.CompanyManagement.service.impl;

import com.flyerssoft.companymanagement.CompanyManagement.dao.EmployeeDao;
import com.flyerssoft.companymanagement.CompanyManagement.dao.impl.EmployeeDaoImpl;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Employee;
import com.flyerssoft.companymanagement.CompanyManagement.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

    private  final EmployeeDao employeeDao = new EmployeeDaoImpl();

    @Override
    public Employee addEmployeeDetail(int companyId, Employee employee) {
        return employeeDao.addEmployeeDetail(companyId,employee);
    }

    @Override
    public Employee getEmployeeDetail(int employeeId) {
        return employeeDao.getEmployeeDetail(employeeId);
    }

    @Override
    public Boolean deleteEmployeeDetail(int employeeId) {
        return employeeDao.deleteEmployeeDetail(employeeId);
    }
}
