package com.flyerssoft.companymanagement.CompanyManagement.service.impl;

import com.flyerssoft.companymanagement.CompanyManagement.dao.CompanyDao;
import com.flyerssoft.companymanagement.CompanyManagement.dao.impl.CompanyDaoImpl;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Company;
import com.flyerssoft.companymanagement.CompanyManagement.service.CompanyService;

public class CompanyServiceImpl implements CompanyService {

    private CompanyDao companyDao = new CompanyDaoImpl();

    @Override
    public Company addCompanyDetail(Company company) {
        return companyDao.addCompanyDetail(company);
    }

    @Override
    public Company getCompanyDetail(int companyId) {
        return companyDao.getCompanyDetail(companyId);
    }

    @Override
    public Boolean deleteCompanyDetail(int companyId) {
        return companyDao.deleteCompanyDetail(companyId);
    }


}
