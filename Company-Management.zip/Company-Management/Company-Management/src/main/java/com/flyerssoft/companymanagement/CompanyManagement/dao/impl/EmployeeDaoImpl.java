package com.flyerssoft.companymanagement.CompanyManagement.dao.impl;

import com.flyerssoft.companymanagement.CompanyManagement.dao.EmployeeDao;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Company;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Employee;
import com.flyerssoft.companymanagement.CompanyManagement.exception.AppException;
import com.flyerssoft.companymanagement.CompanyManagement.exception.NotFoundException;
import com.flyerssoft.companymanagement.CompanyManagement.utility.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

public class EmployeeDaoImpl implements EmployeeDao {

    private final MyConnection myConnection = new MyConnection();
    @Override
    public Employee addEmployeeDetail(int companyId, Employee employee) {

        Connection connection;
        Statement statement;
        String checkCompanyQuery = "SELECT * FROM COMPANY WHERE COMPANYID='"+companyId+"'";
        try {
             connection = myConnection.connectJDBC();
             statement = connection.createStatement();
            ResultSet checkCompany = statement.executeQuery(checkCompanyQuery);

            if (!Objects.nonNull(checkCompany)){
                throw new NotFoundException("Company Not Found Exception");
            }

            String addEmployeeQuery = "INSERT INTO EMPLOYEE(EMPLOYEENAME,EMPLOYEEEMAIL,EMPLOYEENUMBER,COMPANYID) VALUE('"+employee.getEmployeeName()+"','"+employee.getEmployeeEmail()+"','"+employee.getEmployeeNumber()+"','"+companyId+"')";
            int addResult = statement.executeUpdate(addEmployeeQuery);

            if (addResult==1){

                String getAddEmployeeQuery="SELECT * FROM EMPLOYEE WHERE EMPLOYEENAME='"+employee.getEmployeeName()+"'";
                ResultSet getEmployeeResult = statement.executeQuery(getAddEmployeeQuery);

                if (getEmployeeResult.next()){

                 int empId =  getEmployeeResult.getInt("EMPLOYEEID");
                 String empName =  getEmployeeResult.getString("EMPLOYEENAME");
                 String empMail =  getEmployeeResult.getString("EMPLOYEEEMAIL");
                 long num =   getEmployeeResult.getLong("EMPLOYEENUMBER");
                 int cId = getEmployeeResult.getInt("COMPANYID");

                  employee.setEmployeeId(empId);
                  employee.setEmployeeName(empName);
                  employee.setEmployeeEmail(empMail);
                  employee.setEmployeeNumber(num);
                }
            }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return employee;
    }

    @Override
    public Employee getEmployeeDetail(int employeeId) {

        String getEmployeeDetails = "SELECT * FROM EMPLOYEE WHERE EMPLOYEEID = '"+employeeId+"'";
        Connection connection;
        Statement statement;
        Employee employee = new Employee();
        try {
           connection = myConnection.connectJDBC();
           statement = connection.createStatement();
          ResultSet employeeResult = statement.executeQuery(getEmployeeDetails);
          if (employeeResult.next()){
            int empId = employeeResult.getInt("EMPLOYEEID");
            String empName = employeeResult.getString("EMPLOYEENAME");
            String empMail = employeeResult.getString("EMPLOYEEEMAIL");
            long empNumber = employeeResult.getLong("EMPLOYEENUMBER");

            employee.setEmployeeId(empId);
            employee.setEmployeeName(empName);
            employee.setEmployeeEmail(empMail);
            employee.setEmployeeNumber(empNumber);
          }

          String getEmpCompanyDetails = "SELECT COMPANYID FROM EMPLOYEE WHERE EMPLOYEEID='"+employeeId+"'";
          ResultSet companyResult = statement.executeQuery(getEmpCompanyDetails);

          if (companyResult.next()){
            int companyId =   companyResult.getInt("COMPANYID");

            String companyDetails = "SELECT * FROM COMPANY WHERE COMPANYID='"+companyId+"'";

           ResultSet cmpResult = statement.executeQuery(companyDetails);

           if (cmpResult.next()){
               int cId =   cmpResult.getInt("COMPANYID");
              String cName =  cmpResult.getString("COMPANYNAME");
              String cLocation =  cmpResult.getString("COMPANYLOCATION");

               Company company = new Company();
               company.setCompanyId(cId);
               company.setCompanyName(cName);
               company.setCompanyLocation(cLocation);
               employee.setCompany(company);
           }
          }


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return employee;
    }

    @Override
    public Boolean deleteEmployeeDetail(int employeeId) {

        Connection connection;
        Statement statement;
        String deleteQuery = "DELETE FROM EMPLOYEE WHERE EMPLOYEEID= '"+employeeId+"'";
        try {
             connection = myConnection.connectJDBC();
             statement =   connection.createStatement();
            int deleteResult =  statement.executeUpdate(deleteQuery);

            if (deleteResult == 1){
                return true;
            }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return false;
    }
}
