package com.flyerssoft.companymanagement.CompanyManagement.dao;

import com.flyerssoft.companymanagement.CompanyManagement.entity.Employee;

/**
 * The employee dao
 */
public interface EmployeeDao {
    /**
     * Add employee details.
     *
     * @return employee details
     */
    Employee addEmployeeDetail(int companyId,Employee employee);

    /**
     * Get employee details.
     *
     * @return employee details
     */
    Employee getEmployeeDetail(int employeeId);

    /**
     * Delete employee details.
     *
     * @return delete employee details
     */
    Boolean deleteEmployeeDetail(int employeeId);
}
