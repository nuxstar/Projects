package com.flyerssoft.companymanagement.CompanyManagement.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    private final String userName = "root";
    private final String pass = "admin";
    private final String url = "jdbc:mysql://localhost:3306/ProjectManagement";

    public  Connection connectJDBC() throws SQLException {
     Connection connection =  DriverManager.getConnection(url,userName,pass);
     return connection;
    }
}
