package com.flyerssoft.companymanagement.CompanyManagement.exception;

public class AppException extends RuntimeException {

    public  AppException(String message){
        super(message);
    }
}
