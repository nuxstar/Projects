package com.flyerssoft.companymanagement.CompanyManagement.service;

import com.flyerssoft.companymanagement.CompanyManagement.entity.Employee;

/**
 * The employee service
 */
public interface EmployeeService {

    /**
     * Add employee details.
     *
     * @return employee details
     */
    Employee addEmployeeDetail(int companyId,Employee employee);

    /**
     * Get employee details.
     *
     * @return employee details
     */
    Employee getEmployeeDetail(int employeeId);

    /**
     * Delete employee details.
     *
     * @return delete employee details
     */
    Boolean deleteEmployeeDetail(int employeeId);
}
