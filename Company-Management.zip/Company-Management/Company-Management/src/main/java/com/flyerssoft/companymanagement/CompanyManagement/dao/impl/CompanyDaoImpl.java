package com.flyerssoft.companymanagement.CompanyManagement.dao.impl;

import com.flyerssoft.companymanagement.CompanyManagement.dao.CompanyDao;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Company;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Employee;
import com.flyerssoft.companymanagement.CompanyManagement.exception.AppException;
import com.flyerssoft.companymanagement.CompanyManagement.utility.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CompanyDaoImpl  implements CompanyDao {

    private MyConnection myConnection = new MyConnection();

    @Override
    public Company addCompanyDetail(Company company) {

        String addCompanyDetailsQuery = "INSERT INTO COMPANY(COMPANYNAME,COMPANYLOCATION) VALUE('"+company.getCompanyName()+"','"+company.getCompanyLocation()+"')";
        Connection connection;
        Statement statement;

        try {
             connection =  myConnection.connectJDBC();
             statement = connection.createStatement();

            int addClientDetail = statement.executeUpdate(addCompanyDetailsQuery);

            if (addClientDetail == 1){
                String getAddedClientQuery = "SELECT * FROM COMPANY WHERE COMPANYNAME='"+company.getCompanyName()+"'";
                ResultSet clientResult = statement.executeQuery(getAddedClientQuery);

                if (clientResult.next()){
                 int id =    clientResult.getInt("COMPANYID");
                 company.setCompanyId(id);
                }

            }

            if (Objects.nonNull(company.getEmployees())){

             List<Employee> employees =  company.getEmployees();


                for (Employee employeeList:employees) {
                    String empName =  employeeList.getEmployeeName();
                    String empMail = employeeList.getEmployeeEmail();
                    long empNumber = employeeList.getEmployeeNumber();
                    String addEmployeeDetails = "INSERT INTO EMPLOYEE(EMPLOYEENAME,EMPLOYEEEMAIL,EMPLOYEENUMBER,COMPANYID) VALUE('"+empName+"','"+empMail+"','"+empNumber+"','"+company.getCompanyId()+"')";
                    statement.executeUpdate(addEmployeeDetails);
                }

                    String getEmployeeDetails = "SELECT * FROM EMPLOYEE WHERE COMPANYID='"+company.getCompanyId()+"'";
                    ResultSet resultSet = statement.executeQuery(getEmployeeDetails);

                    List<Employee> employeeList = new ArrayList<>();
                    while (resultSet.next()){

                       int empId =  resultSet.getInt("EMPLOYEEID");
                       String empName = resultSet.getString("EMPLOYEENAME");
                       String empMail = resultSet.getString("EMPLOYEEEMAIL");
                       long empNum = resultSet.getLong("EMPLOYEENUMBER");

                       Employee employee = new Employee();
                       employee.setEmployeeId(empId);
                       employee.setEmployeeName(empName);
                       employee.setEmployeeEmail(empMail);
                       employee.setEmployeeNumber(empNum);

                       employeeList.add(employee);
                    }
                    company.setEmployees(employeeList);
            }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return company;
    }

    @Override
    public Company getCompanyDetail(int companyId) {

        String getClientDetailsQuery = "SELECT * FROM COMPANY WHERE COMPANYID='"+companyId+"'";
        String getEmployeeDetails = "SELECT * FROM EMPLOYEE WHERE COMPANYID = '"+companyId+"'";
        Connection connection;
        Statement statement;
        Company company = null;
        try {
             connection = myConnection.connectJDBC();
             statement = connection.createStatement();
             ResultSet companyResult = statement.executeQuery(getClientDetailsQuery);
             if (companyResult.next()){

               String name = companyResult.getString("COMPANYNAME");
               String location = companyResult.getString("COMPANYLOCATION");

                company = new Company();
                company.setCompanyId(companyId);
               company.setCompanyName(name);
               company.setCompanyLocation(location);
             }

            ResultSet employeeDetails = statement.executeQuery(getEmployeeDetails);
             List<Employee> employeeList = new ArrayList<>();
             while (employeeDetails.next()){

                 int id = employeeDetails.getInt("EMPLOYEEID");
                 String name = employeeDetails.getString("EMPLOYEENAME");
                 String mail = employeeDetails.getString("EMPLOYEEEMAIL");
                 long num = employeeDetails.getLong("EMPLOYEENUMBER");

                 Employee employee = new Employee();
                 employee.setEmployeeId(id);
                 employee.setEmployeeName(name);
                 employee.setEmployeeEmail(mail);
                 employee.setEmployeeNumber(num);
                 employeeList.add(employee);
             }

             company.setEmployees(employeeList);

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }


        return company;
    }

    @Override
    public Boolean deleteCompanyDetail(int companyId) {

        String deleteCompanyQuery = "DELETE FROM  COMPANY WHERE COMPANYID='"+companyId+"'";
        String deleteEmployeeCompany = "DELETE FROM EMPLOYEE WHERE COMPANYID = '"+companyId+"'";
        Connection connection;
        Statement statement;
        try {
             connection = myConnection.connectJDBC();
             statement = connection.createStatement();
            int deleteEmployee = statement.executeUpdate(deleteEmployeeCompany);
           int deleteCompany =  statement.executeUpdate(deleteCompanyQuery);


           if (deleteCompany == 1)
               return true;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }
}
