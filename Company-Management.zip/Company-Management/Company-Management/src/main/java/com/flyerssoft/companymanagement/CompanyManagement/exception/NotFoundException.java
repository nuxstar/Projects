package com.flyerssoft.companymanagement.CompanyManagement.exception;

public class NotFoundException extends AppException{

    public NotFoundException(String message) {
        super(message);
    }
}
