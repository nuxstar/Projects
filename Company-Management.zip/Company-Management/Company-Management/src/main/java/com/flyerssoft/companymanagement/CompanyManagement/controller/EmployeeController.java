package com.flyerssoft.companymanagement.CompanyManagement.controller;

import com.flyerssoft.companymanagement.CompanyManagement.entity.Employee;
import com.flyerssoft.companymanagement.CompanyManagement.service.EmployeeService;
import com.flyerssoft.companymanagement.CompanyManagement.service.impl.EmployeeServiceImpl;
import org.springframework.web.bind.annotation.*;

/**
 * The employee controller
 */
@RestController
public class EmployeeController {

    private final EmployeeService employeeService = new EmployeeServiceImpl();

    @PostMapping("employee/{companyId}")
    public  Employee addEmployee(@PathVariable int companyId,@RequestBody Employee employee){
    return employeeService.addEmployeeDetail(companyId,employee);
    }

    @GetMapping("employee/{employeeId}")
    public  Employee getEmployee(@PathVariable int employeeId){
        return employeeService.getEmployeeDetail(employeeId);
    }

    @DeleteMapping("/employee/{employeeId}")
    public Boolean deleteEmployee(@PathVariable int employeeId){
        return employeeService.deleteEmployeeDetail(employeeId);
    }
}
