package com.flyerssoft.companymanagement.CompanyManagement.dao;

import com.flyerssoft.companymanagement.CompanyManagement.entity.Company;

/**
 * The company dao
 */
public interface CompanyDao {
    /**
     * Add company details.
     *
     * @return company details
     */
    Company addCompanyDetail(Company company);

    /**
     * Get company details.
     *
     * @return company details
     */
    Company getCompanyDetail(int companyId);

    /**
     * Delete company details.
     *
     * @return delete company details
     */
    Boolean deleteCompanyDetail(int companyId);
}
