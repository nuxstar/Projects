package com.flyerssoft.companymanagement.CompanyManagement.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.flyerssoft.companymanagement.CompanyManagement.entity.Company;
import com.flyerssoft.companymanagement.CompanyManagement.service.CompanyService;
import com.flyerssoft.companymanagement.CompanyManagement.service.impl.CompanyServiceImpl;
import org.springframework.web.bind.annotation.*;

/**
 * The company controller
 */
@RestController
public class CompanyController {

    private CompanyService companyService = new CompanyServiceImpl();

    @PostMapping("/company")
    public  Company addCompany(@RequestBody Company company){
          return companyService.addCompanyDetail(company);
    }

    @GetMapping("/company/{companyId}")
    public  Company getCompany(@PathVariable int companyId){
        return companyService.getCompanyDetail(companyId);
    }

    @DeleteMapping("/company/{companyId}")
    public Boolean deleteCompany(@PathVariable int companyId){
        return companyService.deleteCompanyDetail(companyId);
    }
}
