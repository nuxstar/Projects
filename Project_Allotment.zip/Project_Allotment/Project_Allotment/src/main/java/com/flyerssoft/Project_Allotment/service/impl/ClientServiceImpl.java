package com.flyerssoft.Project_Allotment.service.impl;

import com.flyerssoft.Project_Allotment.dao.ClientDao;
import com.flyerssoft.Project_Allotment.dao.impl.ClientDaoImpl;
import com.flyerssoft.Project_Allotment.entity.Client;
import com.flyerssoft.Project_Allotment.entity.Project;
import com.flyerssoft.Project_Allotment.service.ClientService;

import java.util.List;

public class ClientServiceImpl implements ClientService {

    private ClientDao clientDao = new ClientDaoImpl();

    @Override
    public Client addClient(Client client) {
        return  clientDao.addClient(client);
    }

    @Override
    public Client updateClient(int clientId,List<Project> projects) {
        return clientDao.updateClient(clientId,projects);
    }

    @Override
    public Client getClient(int clientId) {
        return clientDao.getClient(clientId);
    }

    @Override
    public Boolean deleteClient(int clientId) {
        return clientDao.deleteClient(clientId);
    }

    @Override
    public List<Client> getAllClient() {
        return clientDao.getAllClient();
    }
}
