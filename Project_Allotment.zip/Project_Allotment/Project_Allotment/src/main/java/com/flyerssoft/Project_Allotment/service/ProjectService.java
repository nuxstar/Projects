package com.flyerssoft.Project_Allotment.service;

import com.flyerssoft.Project_Allotment.entity.Employee;
import com.flyerssoft.Project_Allotment.entity.Project;

import java.util.List;
import java.util.Optional;

/**
 * The project service.
 */
public interface ProjectService {

    /**
     * Update project details.
     *
     * @param projectId
     * @param project
     * @return
     */
    Project updateProject(int projectId,Project project);

    /**
     * Get project  details.
     *
     * @param projectId project id
     * @return project details
     */
    Project getProjectById(int projectId,int clientId);

    /**
     * Delete project details.
     *
     * @param projectId projectId
     * @return delete project details
     */
    Boolean deleteProject(int projectId);



}
