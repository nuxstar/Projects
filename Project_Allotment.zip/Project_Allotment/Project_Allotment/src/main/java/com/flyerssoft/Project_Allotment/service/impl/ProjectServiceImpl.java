package com.flyerssoft.Project_Allotment.service.impl;

import com.flyerssoft.Project_Allotment.dao.ProjectDao;
import com.flyerssoft.Project_Allotment.dao.impl.ProjectDaoImpl;
import com.flyerssoft.Project_Allotment.entity.Employee;
import com.flyerssoft.Project_Allotment.entity.Project;
import com.flyerssoft.Project_Allotment.service.ProjectService;
import java.util.List;

public class ProjectServiceImpl implements ProjectService {

    private ProjectDao projectDao = new ProjectDaoImpl();

    @Override
    public Project updateProject(int projectId, Project project) {
        return  projectDao.updateProject(projectId,project);
    }

    @Override
    public Project getProjectById(int projectId,int clientId) {
        return projectDao.getProjectById(projectId,clientId);
    }

    @Override
    public Boolean deleteProject(int projectId) {
        return projectDao.deleteProject(projectId);
    }
}
