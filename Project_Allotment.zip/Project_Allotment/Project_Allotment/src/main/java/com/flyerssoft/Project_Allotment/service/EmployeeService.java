package com.flyerssoft.Project_Allotment.service;

import com.flyerssoft.Project_Allotment.entity.Employee;

/**
 * The employee service
 */
public interface EmployeeService {

    /**
     * Add employee details.
     *
     * @param employee employee
     * @return employee details
     */
    Employee addEmployee(Employee employee);

    /**
     * Update employee details.
     *
     * @param employeeId employeeId
     * @param employee employee
     * @return employee details
     */
    Employee updateEmployee(int employeeId,Employee employee);

    /**
     * Get employee details.
     *
     * @param employeeId employeeId
     * @return employee details
     */
    Employee getEmployeeById(int employeeId);

    /**
     * Delete employee details.
     *
     * @param employeeId employeeId
     * @return delete employee details.
     */
    boolean deleteEmployee(int employeeId);

}
