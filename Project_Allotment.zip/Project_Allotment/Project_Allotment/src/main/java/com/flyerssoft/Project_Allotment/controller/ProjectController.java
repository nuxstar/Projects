package com.flyerssoft.Project_Allotment.controller;

import com.flyerssoft.Project_Allotment.entity.Project;
import com.flyerssoft.Project_Allotment.service.ProjectService;
import com.flyerssoft.Project_Allotment.service.impl.ProjectServiceImpl;
import org.springframework.web.bind.annotation.*;

@RestController("/api")
public class ProjectController {

    private ProjectService projectService = new ProjectServiceImpl();

    @PutMapping("/project/{projectId}")
    public Project updateProject(@PathVariable  int projectId, Project project){
      return  projectService.updateProject(projectId,project);
    }

    @GetMapping("/project/{projectId}/{clientId}")
    public Project getProject(@PathVariable  int projectId,@PathVariable int clientId){
      return   projectService.getProjectById(projectId,clientId);
    }

    @DeleteMapping("/project/{projectID}")
    public Boolean deleteProject(@PathVariable int projectId){
        return  projectService.deleteProject(projectId);
    }

}
