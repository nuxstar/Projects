package com.flyerssoft.Project_Allotment.utility;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * The connection class
 */
public class MyConnection {

    private final String user = "root";
    private final String pass = "admin";
    private final String url = "jdbc:mysql://localhost:3306/Project_Allocation";

    public Connection connectJDBC() throws SQLException {
      Connection  connect = DriverManager.getConnection(url, user, pass);
        return  connect;
    }

}
