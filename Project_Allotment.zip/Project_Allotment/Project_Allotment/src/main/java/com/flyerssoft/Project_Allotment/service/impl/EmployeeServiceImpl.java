package com.flyerssoft.Project_Allotment.service.impl;

import com.flyerssoft.Project_Allotment.dao.EmployeeDao;
import com.flyerssoft.Project_Allotment.dao.impl.EmployeeDaoImpl;
import com.flyerssoft.Project_Allotment.entity.Employee;
import com.flyerssoft.Project_Allotment.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeDao employeeDao = new EmployeeDaoImpl();

    @Override
    public Employee addEmployee(Employee employee) {
        return employeeDao.addEmployee(employee);
    }

    @Override
    public Employee updateEmployee(int employeeId, Employee employee) {
        return employeeDao.updateEmployee(employeeId,employee);
    }

    @Override
    public Employee getEmployeeById(int employeeId) {
        return employeeDao.getEmployeeById(employeeId);
    }

    @Override
    public boolean deleteEmployee(int employeeId) {
        return employeeDao.deleteEmployee(employeeId);
    }
}
