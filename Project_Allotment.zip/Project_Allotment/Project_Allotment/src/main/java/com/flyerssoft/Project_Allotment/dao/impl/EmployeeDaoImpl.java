package com.flyerssoft.Project_Allotment.dao.impl;

import com.flyerssoft.Project_Allotment.dao.EmployeeDao;
import com.flyerssoft.Project_Allotment.entity.Employee;
import com.flyerssoft.Project_Allotment.entity.Skill;
import com.flyerssoft.Project_Allotment.exception.AppException;
import com.flyerssoft.Project_Allotment.exception.NotFoundException;
import com.flyerssoft.Project_Allotment.utility.MyConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class EmployeeDaoImpl implements EmployeeDao {

   private  MyConnection myConnection = new MyConnection();

    @Override
    public Employee addEmployee(Employee employee) {

        Connection connection;

        String addEmployeeQuery = "INSERT INTO EMPLOYEE (EMPLOYEENAME,DESIGNATION ,employeeEmail) VALUE('"+employee.getEmployeeName()+"','"+employee.getDesignation()+"','"+employee.getEmployeeMail()+"') ";
        String getAddEmployeeQuery = "SELECT * FROM EMPLOYEE WHERE EMPLOYEENAME = '"+employee.getEmployeeName()+"'";
        try {
             connection =  myConnection.connectJDBC();
             Statement statement = connection.createStatement();
             int result =  statement.executeUpdate(addEmployeeQuery);

             if (result ==1){
                ResultSet getEmployeeResult =  statement.executeQuery(getAddEmployeeQuery);
                if (getEmployeeResult.next()){
                   int id =  getEmployeeResult.getInt("EmployeeId");
                   employee.setEmployeeId(id);
                }
             }

             if (Objects.nonNull(employee.getSkills())){

                List<Skill> skills =   employee.getSkills();

               for (Skill skill: skills){
                 String skillName = skill.getSkillName();
                 String addSkillQuery = "INSERT INTO SKILL (skillName) VALUE ('"+skillName+"')";
                 statement.executeUpdate(addSkillQuery);
               }
             }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return null;
    }

    @Override
    public Employee updateEmployee(int employeeId, Employee employee) {

        String updateEmployeeQuery = "UPDATE EMPLOYEE SET DESIGNATION = '"+employee.getDesignation()+"' , EMPLOYEEMAIL = '"+employee.getEmployeeMail()+"' PROJECTID = '"+employee.getProjectId()+"' ";

        try {
           Connection connection =  myConnection.connectJDBC();
            Statement statement = connection .createStatement();
            int result = statement.executeUpdate(updateEmployeeQuery);




        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return null;
    }

    @Override
    public Employee getEmployeeById(int employeeId) {

        String getEmployeeQuery = "SELECT * FROM EMPLOYEE WHERE EMPLOYEEID = '"+employeeId+"'";

        Connection connection;
        Statement statement;
        try {
             connection = myConnection.connectJDBC();
             statement = connection.createStatement();
             ResultSet getEmployeeResult =  statement.executeQuery(getEmployeeQuery);

             if (getEmployeeResult.next()){

                int id =  getEmployeeResult.getInt("employeeId");
               String empName =   getEmployeeResult.getString("EmployeeName");
               String designation =   getEmployeeResult.getString("designation");
               String email =   getEmployeeResult.getString("EmployeeEmail");


                Employee employee = new Employee();
                employee.setEmployeeId(id);
                employee.setEmployeeName(empName);
                employee.setDesignation(designation);
                employee.setEmployeeMail(email);

                return  employee;
             }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteEmployee(int employeeId) {

        String deleteEmployeeQuery = "DELETE FROM EMPLOYEE WHERE EMPLOYEEID ='"+employeeId+"'";

        try {
            Connection connection =  myConnection.connectJDBC();
            Statement statement = connection.createStatement();
            int result = statement.executeUpdate(deleteEmployeeQuery);

            if (result == 1)
                return true;
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return false;
    }
}
