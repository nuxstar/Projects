package com.flyerssoft.Project_Allotment.controller;

import com.flyerssoft.Project_Allotment.entity.Client;
import com.flyerssoft.Project_Allotment.entity.Project;
import com.flyerssoft.Project_Allotment.service.ClientService;
import com.flyerssoft.Project_Allotment.service.impl.ClientServiceImpl;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * The client controller
 */
@RequestMapping("/api")
@RestController
public class ClientController {

    private ClientService clientService = new ClientServiceImpl();

    @PostMapping("/client")
    public Client addClient(@RequestBody Client client){
      return  clientService.addClient(client);
    }

    @PutMapping("/client/{clientId}")
    public Client updateClient(@PathVariable int clientId, @RequestBody List<Project> projects){
        return clientService.updateClient(clientId,projects);
    }

    @GetMapping("/ClientById/{clientId}")
    public Client getClient(@PathVariable  int clientId){
        return clientService.getClient(clientId);
    }

    @GetMapping("/clients")
    public List<Client> getAllClient(){
        return clientService.getAllClient();
    }

    @DeleteMapping("/Client/{clientId}")
    public Boolean deleteClient(@PathVariable int clientId){
        return clientService.deleteClient(clientId);
    }



}
