package com.flyerssoft.Project_Allotment.dao;

import com.flyerssoft.Project_Allotment.entity.Client;
import com.flyerssoft.Project_Allotment.entity.Project;
import java.util.List;

/**
 * The client dao
 */
public interface ClientDao {

    /**
     * Add client details.
     *
     * @param client client
     * @param projects projects
     * @return client details
     */
    Client addClient(Client client);

    /**
     * Update client details.
     *
     * @param clientId clientId
     * @param client client
     * @param projects projects
     * @return client details
     */
    Client updateClient(int clientId,List<Project> projects);

    /**
     * Get client details.
     *
     * @param clientId clientId
     * @return client details
     */
    Client getClient(int clientId);

    /**
     * Delete client details.
     *
     * @param clientId clientId
     * @return delete client details
     */
    Boolean deleteClient(int clientId);

    /**
     * Get all client details.
     *
     * @return all client details
     */
    List<Client> getAllClient();
}
