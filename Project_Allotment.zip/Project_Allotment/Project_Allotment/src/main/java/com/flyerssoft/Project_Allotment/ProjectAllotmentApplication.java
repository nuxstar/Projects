package com.flyerssoft.Project_Allotment;

import com.flyerssoft.Project_Allotment.controller.ClientController;
import com.flyerssoft.Project_Allotment.entity.Client;
import com.flyerssoft.Project_Allotment.entity.Project;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class ProjectAllotmentApplication {


	public static void main(String[] args) {
		SpringApplication.run(ProjectAllotmentApplication.class, args);

	}

}

