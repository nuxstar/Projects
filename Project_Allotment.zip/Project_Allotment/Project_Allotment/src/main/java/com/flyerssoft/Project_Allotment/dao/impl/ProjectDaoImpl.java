package com.flyerssoft.Project_Allotment.dao.impl;

import com.flyerssoft.Project_Allotment.dao.ProjectDao;
import com.flyerssoft.Project_Allotment.entity.Project;
import com.flyerssoft.Project_Allotment.exception.AppException;
import com.flyerssoft.Project_Allotment.exception.NotFoundException;
import com.flyerssoft.Project_Allotment.utility.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ProjectDaoImpl implements ProjectDao {

    private final MyConnection myConnection = new MyConnection();

    @Override
    public Project updateProject(int projectId, Project project) {

        Connection connection;
        Statement statement;
        String checkProject = "SELECT * FROM PROJECT WHERE PROJECTID = '"+projectId+"' ";
        String executeQuery = "UPDATE PROJECT SET projectName='"+project.getProjectName()+"', project_StartDate='"+project.getProjectStartDate()+"', project_EndDate = '"+project.getProjectEndDate()+"' ";
        String getUpdateProjectQuery = "SELECT * FROM PROJECT WHERE PROJECTNAME='"+project.getProjectName()+"'";
        try {
             connection = myConnection.connectJDBC();
             statement = connection.createStatement();

            ResultSet checkResult =  statement.executeQuery(checkProject);

            if (!checkResult.next()){
               throw  new NotFoundException("Project Not Found Exception");
            }
            int result =  statement.executeUpdate(executeQuery);

            if (result == 1){

                ResultSet updateResult =   statement.executeQuery(getUpdateProjectQuery);

                if (updateResult.next()){
                    int id =   updateResult.getInt("PROJECTID");
                    String projectName =  updateResult.getString("projectName");
                    String sDate =   updateResult.getString("project_StartDate");
                    String eDate =   updateResult.getString("project_EndDate");
                    project.setProjectId(id);
                    project.setProjectName(projectName);
                    project.setProjectStartDate(sDate);
                    project.setProjectEndDate(eDate);
                }

           }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return project;
    }

    @Override
    public Project getProjectById(int projectId,int clientId) {

        String getByProjectIdQuery="SELECT * FROM PROJECT WHERE PROJECTID='"+projectId+"'";
        Connection connection;
        Statement statement;

        try {
             connection =   myConnection.connectJDBC();
             statement = connection.createStatement();
            ResultSet projectResultSet = statement.executeQuery(getByProjectIdQuery);

            if (projectResultSet.next()){

                int id = projectResultSet.getInt("CLIENTID");
                String name =   projectResultSet.getString("CLIENT_NAME");
                String sDate = projectResultSet.getString("CONTRACT_STARTDATE");
                String eDate =  projectResultSet.getString("CONTRACT_ENDDATE");
                Project project = new Project();
                project.setProjectName(name);
                project.setProjectStartDate(sDate);
                project.setProjectEndDate(eDate);
                return project;

            }




        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return null;
    }

    @Override
    public Boolean deleteProject(int projectId) {

        String deleteProjectQuery = "DELETE FROM PROJECT WHERE PROJECTID='"+projectId+"'";

        try {
            Connection connection =  myConnection.connectJDBC();
            Statement statement = connection.createStatement();
           int result =  statement.executeUpdate(deleteProjectQuery);

           if (result == 1)
               return  true;

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        return false;
    }
}
