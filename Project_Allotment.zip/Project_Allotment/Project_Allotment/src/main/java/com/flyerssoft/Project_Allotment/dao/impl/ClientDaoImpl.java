package com.flyerssoft.Project_Allotment.dao.impl;

import com.flyerssoft.Project_Allotment.dao.ClientDao;
import com.flyerssoft.Project_Allotment.entity.Client;
import com.flyerssoft.Project_Allotment.entity.Employee;
import com.flyerssoft.Project_Allotment.entity.Project;
import com.flyerssoft.Project_Allotment.exception.AppException;
import com.flyerssoft.Project_Allotment.exception.NotFoundException;
import com.flyerssoft.Project_Allotment.utility.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ClientDaoImpl implements ClientDao {
    private final MyConnection myConnection = new MyConnection();

    @Override
    public Client addClient(Client client) {

        Connection connection = null;
        Statement statement;
        int count = 0;
        if(Objects.nonNull(client.getProjects())) {
            count = client.getProjects().size();
        }
        String addClientQuery="INSERT INTO CLIENT_(CLIENT_NAME,CONTRACT_STARTDATE,CONTRACT_ENDDATE,PROJECTCOUNT) VALUE('"+client.getClientName()+"','"+client.getClientStartDate()+"','"+client.getClientEndDate()+"','"+count+"')";
        String getAddedClientQuery = "SELECT * FROM CLIENT_ WHERE CLIENT_NAME='"+client.getClientName()+"'";

        try {

             connection = myConnection.connectJDBC();
              statement = connection.createStatement();
             int clientResult = statement.executeUpdate(addClientQuery);

            if (clientResult == 1){
                ResultSet resultSet =  statement.executeQuery(getAddedClientQuery);
                if (resultSet.next()){
                    int clientId = resultSet.getInt("clientId");
                    client.setClientId(clientId);
                }
            }

             if (Objects.nonNull(client.getProjects())) {

                 List<Project> projects =  client.getProjects();


                 for (Project project: projects) {

                   String projectName = project.getProjectName();
                   String startDate = project.getProjectStartDate();
                   String endDate = project.getProjectEndDate();
                   String addProjectsQuery = "INSERT INTO PROJECT (PROJECTNAME,PROJECT_STARTDATE,PROJECT_ENDDATE) VALUE('"+projectName+"','"+startDate+"','"+endDate+"')";
                   statement.executeUpdate(addProjectsQuery);
                 }

                 String getProjectDetailQuery="SELECT * FROM PROJECT WHERE CLIENTID='"+client.getClientId()+"'";
                 ResultSet projectDetails =  statement.executeQuery(getProjectDetailQuery);

                 List<Project> projectList = new ArrayList<>();
                 while (projectDetails.next()){
                     int id =  projectDetails.getInt("PROJECTID");
                     String name =  projectDetails.getString("PROJECTNAME");
                     String sDate =  projectDetails.getString("PROJECT_STARTDATE");
                     String eDate = projectDetails.getString("PROJECT_ENDDATE");

                     Project project = new Project();
                     project.setProjectId(id);
                     project.setProjectName(name);
                     project.setProjectStartDate(sDate);
                     project.setProjectEndDate(eDate);

                     projectList.add(project);
                 }
                client.setProjects(projectList);

             }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }
        return client;
    }

    @Override
    public Client updateClient(int clientId,List<Project> projects) {

        Connection connection;
        Statement statement;
        String checkClientQuery = "SELECT * FROM CLIENT_ WHERE CLIENTID='"+clientId+"'";
        try {
             connection = myConnection.connectJDBC();
             statement = connection.createStatement();
             ResultSet checkClient = statement.executeQuery(checkClientQuery);

             if (!checkClient.next()){
                 throw new NotFoundException("Client Not Found Exception");
             }

            int updateResult = 0;
             for (Project project : projects){
                 String name =  project.getProjectName();
                 String startDate = project.getProjectStartDate();
                 String endDate = project.getProjectEndDate();

                 String updateProjectDetailsQuery = "UPDATE PROJECT SET PROJECTNAME ='"+name+"', PROJECT_STARTDATE = '"+startDate+"', PROJECT_ENDDATE ='"+endDate+"'";
                 updateResult = statement.executeUpdate(updateProjectDetailsQuery);
             }

            if (updateResult == 0){

                String getClientQuery="select * from client_ where clientId='"+clientId+"'";
                ResultSet getClientDetail =  statement.executeQuery(getClientQuery);

                if (getClientDetail.next()){

                   int id = getClientDetail.getInt("CLIENTID");
                   String name = getClientDetail.getString("CLIENT_NAME");
                   String sDate = getClientDetail.getString("CONTRACT_STARTDATE");
                   String eDate = getClientDetail.getString("CONTRACT_ENDDATE");
                }

                String getUpdateDetailQuery = "SELECT * PROJECT WHERE CLIENTID ='"+clientId+"'";
               ResultSet getUpdateDetail =  statement.executeQuery(getUpdateDetailQuery);

               List<Employee> employees = new ArrayList<>();
               while (getUpdateDetail.next()){

                 int id =   getUpdateDetail.getInt("PROJECTID");
                 String pName =   getUpdateDetail.getString("PROJECTNAME");
                 String sDate = getUpdateDetail.getString("PROJECT_STARTDATE");
                 String eDate = getUpdateDetail.getString("PROJECT_ENDDATE");

                Employee employee = new Employee();
                employee.setEmployeeId(id);
                employee.setEmployeeName(pName);



               }
            }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return null;
    }

    @Override
    public Client getClient(int clientId) {

      String getByClientIdQuery="SELECT * FROM CLIENT_ WHERE clientId='"+clientId+"'";


        try {
            Connection connection =   myConnection.connectJDBC();
            Statement statement = connection.createStatement();
            ResultSet clientResultSet = statement.executeQuery(getByClientIdQuery);

            if (clientResultSet.next()){
                int id = clientResultSet.getInt("CLIENTID");
                String name =   clientResultSet.getString("CLIENT_NAME");
                String sDate = clientResultSet.getString("CONTRACT_STARTDATE");
                String eDate =  clientResultSet.getString("CONTRACT_ENDDATE");
                Client  client = new Client();
                client.setClientId(id);
                client.setClientName(name);
                client.setClientStartDate(sDate);
                client.setClientEndDate(eDate);
                return client;

            }




        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

return null;
    }

    @Override
    public List<Client> getAllClient() {

        String getQuery = "SELECT * FROM CLIENT_";
        Connection  connection;
        Statement statement;
        ResultSet resultSet;

        try {
            connection =  myConnection.connectJDBC();
            statement = connection.createStatement();
            resultSet  = statement.executeQuery(getQuery);

            List<Client> clients = new ArrayList<>();

            while (resultSet.next()){

                int clientId = resultSet.getInt("clientId");
                String clientName = resultSet.getString("client_Name");
                String sDate = resultSet.getString("contract_StartDate");
                String eDate = resultSet.getString("contract_EndDate");
                Byte count = resultSet.getByte("projectCount");

                Client client = new Client();
                client.setClientId(clientId);
                client.setClientName(clientName);
                client.setClientStartDate(sDate);
                client.setClientEndDate(eDate);
                client.setProjectCount(count);
                clients.add(client);

            }

            return clients;

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

    }

    @Override
    public Boolean deleteClient(int clientId) {

        String deleteQuery = "DELETE FROM CLIENT_ WHERE clientId='"+clientId+"'";

        try {
            Connection connection = myConnection.connectJDBC();
            Statement statement = connection.createStatement();
            int resultSet = statement.executeUpdate(deleteQuery);

            if (resultSet == 1)
                return true;

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }


        return false;
    }


}
