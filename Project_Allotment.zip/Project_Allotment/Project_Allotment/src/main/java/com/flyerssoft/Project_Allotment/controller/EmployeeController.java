package com.flyerssoft.Project_Allotment.controller;

import com.flyerssoft.Project_Allotment.entity.Employee;
import com.flyerssoft.Project_Allotment.service.EmployeeService;
import com.flyerssoft.Project_Allotment.service.impl.EmployeeServiceImpl;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

    private EmployeeService employeeService = new EmployeeServiceImpl();

    @PostMapping
    public  Employee addEmployee(@RequestBody Employee employee){
       return employeeService.addEmployee(employee);
    }

    @PutMapping
    public  Employee updateEmployee(@RequestBody int employeeId, Employee employee){
        return employeeService.updateEmployee(employeeId,employee);
    }

    public  void getEmployee(int )

}
