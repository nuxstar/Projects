package com.flyerssoft.Project_Allotment.entity;

import java.util.List;

/**
 * The client entity
 */
public class Client {

    private int clientId;
    private String clientName;
    private String clientStartDate;
    private String ClientEndDate;
    private byte projectCount;
    private List<Project> projects;



    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientStartDate() {
        return clientStartDate;
    }

    public void setClientStartDate(String clientStartDate) {
        this.clientStartDate = clientStartDate;
    }

    public String getClientEndDate() {
        return ClientEndDate;
    }

    public void setClientEndDate(String ClientEndDate) {
        this.ClientEndDate = ClientEndDate;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

    public byte getProjectCount() {
        return projectCount;
    }

    public void setProjectCount(byte projectCount) {
        this.projectCount = projectCount;
    }
}
