package com.flyerssoft.ams.model.repository;

import com.flyerssoft.ams.model.entity.Project;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


/**
 * The project repository.
 */
@Repository
public interface ProjectRepository extends JpaRepository<Project, Integer> {

  @Query(value = "SELECT * FROM project p1 JOIN employee_project "
      + "e1 ON p1.id = e1.project_id WHERE e1.employee_id=:employee_id", nativeQuery = true)
  List<Project> findAllByEmployeeId(@Param("employee_id") int employeeId, Pageable pageable);
}
