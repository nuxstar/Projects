package com.flyerssoft.ams.service;

import com.flyerssoft.ams.exception.IllegalStateException;
import com.flyerssoft.ams.exception.NotFoundException;
import com.flyerssoft.ams.model.dto.project.ProjectDto;
import java.util.List;

/**
 * The project service.
 */
public interface ProjectService {

  /**
   * Create project.
   *
   * @param projectDto projectDto
   * @return project details
   */
  ProjectDto createProject(ProjectDto projectDto);

  /**
   * Get all projects under employee.
   *
   * @return all project details
   */
  List<ProjectDto> readProject(int employeeId, int page, int size) throws NotFoundException;

  /**
   * Update project details.
   *
   * @param projectId projectId
   * @param projectDto projectDto
   * @return project details
   */
  ProjectDto updateProject(int projectId, ProjectDto projectDto) throws NotFoundException;

  /**
   * Update (map or un map) project with employee.
   *
   * @param projectId projectId
   * @param employeeId employeeId
   * @return updated project details
   */
  String assignOrRemoveEmployee(
      int projectId,
      int employeeId,
      boolean isAssign) throws NotFoundException, IllegalStateException;

  /**
   * Delete project.
   *
   * @param projectId projectId
   */
  void deleteProject(int projectId) throws NotFoundException;
}
