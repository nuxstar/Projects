package com.flyerssoft.ams.service.impl;

import com.flyerssoft.ams.client.microsoft.auth.MicrosoftAuthClient;
import com.flyerssoft.ams.client.microsoft.dto.Profile;
import com.flyerssoft.ams.client.microsoft.dto.TokenResponse;
import com.flyerssoft.ams.client.microsoft.graph.MicrosoftGraphClient;
import com.flyerssoft.ams.model.dto.LoginResponseDto;
import com.flyerssoft.ams.service.AuthService;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Implementation class for the AuthService interface.
 */
@Service
public class AuthServiceImpl implements AuthService {

  /**
   * Holds the end points Microsoft Authentication client.
   */
  @Autowired
  private MicrosoftAuthClient microsoftAuthClient;

  /**
   * Microsoft Tenant I'd which is present in application properties.
   */
  @Value("${api.microsoft.sso.tenant.id}")
  String tenantId;

  /**
   * Microsoft Client I'd which is present in application properties.
   */
  @Value("${api.microsoft.sso.client.id}")
  private String clientId;

  /**
   * Microsoft Client secret which is present in application properties.
   */
  @Value("${api.microsoft.sso.client.secret}")
  private String clientSecret;

  /**
   * Microsoft Redirect URL which is present in application properties.
   */
  @Value("${api.microsoft.sso.redirectUri}")
  private String redirectUri;

  /**
   * Microsoft Scopes for our api to consume
   * which is present in application properties.
   */
  @Value("${api.microsoft.sso.scopes}")
  private String scopes;

  /**
   * Grant type holds the flow in which we want to achieve
   * microsoft authentication.
   */
  @Value("${api.microsoft.sso.grantType}")
  private String grantType;

  /**
   * Holds the end points Microsoft Graph client.
   */
  @Autowired
  private MicrosoftGraphClient microsoftGraphClient;

  /**
   * Authenticates the user based on the provided authorization code.
   *
   * @param authCode The authorization code obtained from the
   *                 authentication process.
   * @return A LoginResponseDto object containing the profile information
   *         and access token.
   * @throws ParseException If there is an error parsing the response.
   */
  public LoginResponseDto login(
      final String authCode
  ) throws ParseException {

    Map<String, String> urlEncodedFormData = new HashMap<>();

    urlEncodedFormData.put("code", authCode);
    urlEncodedFormData.put("client_id", clientId);
    urlEncodedFormData.put("redirect_uri", redirectUri);
    urlEncodedFormData.put("grant_type", grantType);
    urlEncodedFormData.put("client_secret", clientSecret);

    TokenResponse tokenResponse = microsoftAuthClient.getAccessToken(tenantId, urlEncodedFormData);

    String bearerToken = "Bearer " + tokenResponse.accessToken();

    Profile profileResponse = microsoftGraphClient.getUserById(bearerToken);

    return new LoginResponseDto(
        profileResponse,
        tokenResponse.expiresIn(),
        tokenResponse.accessToken()
    );
  }

}
