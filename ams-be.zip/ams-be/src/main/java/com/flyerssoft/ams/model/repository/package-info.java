/**
 * This package contains classes related to repository functionality.
 *
 * <p>They encapsulate the logic for interacting with the underlying database
 */
package com.flyerssoft.ams.model.repository;
