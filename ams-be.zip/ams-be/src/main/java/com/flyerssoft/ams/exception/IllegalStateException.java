package com.flyerssoft.ams.exception;

/**
 * The illegal state exception class.
 *
 */
public class IllegalStateException extends AmsException {
  public IllegalStateException(String message) {
    super(message);
  }
}
