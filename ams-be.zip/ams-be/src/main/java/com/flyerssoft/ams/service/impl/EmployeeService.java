package com.flyerssoft.ams.service.impl;

import com.flyerssoft.ams.client.microsoft.dto.Profile;
import com.flyerssoft.ams.mapper.EmployeeMapper;
import com.flyerssoft.ams.model.dto.EmployeeDto;
import com.flyerssoft.ams.model.entity.Employee;
import com.flyerssoft.ams.model.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The EmployeeService interface provides methods
 * for managing employees in the system.
 */
@Service
@Slf4j
public class EmployeeService {

  @Autowired
  EmployeeMapper employeeMapper;

  @Autowired
  EmployeeRepository employeeRepository;

  /**
   * Adds an employee using the provided profile response.
   *
   * @param profileResponse The profile response containing employee details
   *                        from microsoft graph client.
   * @return The EmployeeDto representing the added employee.
   */
  public EmployeeDto addEmployee(Profile profileResponse) {
    Employee employee = employeeMapper.profileResponseToEmployee(profileResponse);
    employeeRepository.save(employee);
    return employeeMapper.employeeToEmployeeDto(employee);
  }
}
