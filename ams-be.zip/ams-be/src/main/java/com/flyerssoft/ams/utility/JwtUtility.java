package com.flyerssoft.ams.utility;

import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import java.text.ParseException;
import org.springframework.stereotype.Component;

/**
 * The JwtUtility interface provides utility methods for
 * working with JWT (JSON Web Tokens).
 */
@Component
public interface JwtUtility {

  /**
   * Parses the access token and returns the parsed JWT claims set.
   *
   * @param accessToken the access token to parse
   * @return the parsed JWT claims set
   * @throws ParseException if the access token cannot be parsed
   */

  static JWTClaimsSet getParsedAccessToken(String accessToken) throws ParseException {
    return (JWTClaimsSet) JWTParser.parse(accessToken).getJWTClaimsSet();
  }

  /**
   * Retrieves a specific claim from the access token.
   *
   * @param property    the claim property name
   * @param accessToken the access token
   * @return the value of the claim
   * @throws ParseException if the access token cannot be parsed
   */
  static String getClaim(String property, String accessToken) throws ParseException {
    JWTClaimsSet jwtProperties = JwtUtility.getParsedAccessToken(accessToken);
    return jwtProperties.getClaim(accessToken).toString();
  }
}
