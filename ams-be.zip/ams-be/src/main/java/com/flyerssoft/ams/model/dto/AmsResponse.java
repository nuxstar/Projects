package com.flyerssoft.ams.model.dto;

/**
 * Generic class representing a response in the AMS application.
 * The {@code AmsResponse} class encapsulates the response data
 * returned by the API endpoints.
 * It includes the status code, a flag indicating the success of the
 * response, and the data payload.
 * The generic type {@code T} represents the type of data being returned in
 * the response.
 * This class provides a standardized structure for returning responses from
 * the AMS API.
 *
 * @param <T> the type of data being returned in the response
 */
public class AmsResponse<T> {

  private Integer statusCode;

  private Boolean response;

  private T data;

  /**
   * The status code indicating the result of the operation.
   */
  public AmsResponse(Integer statusCode, Boolean response, T data) {
    this.statusCode = statusCode;
    this.response = response;
    this.data = data;
  }

  public Integer getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(Integer statusCode) {
    this.statusCode = statusCode;
  }

  public Boolean getResponse() {
    return response;
  }

  public void setResponse(Boolean response) {
    this.response = response;
  }

  public T getData() {
    return data;
  }

  public void setData(T data) {
    this.data = data;
  }
}
