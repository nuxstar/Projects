package com.flyerssoft.ams.mapper;

import com.flyerssoft.ams.client.microsoft.dto.Profile;
import com.flyerssoft.ams.model.dto.EmployeeDto;
import com.flyerssoft.ams.model.entity.Employee;
import org.mapstruct.Mapper;

/**
 * The EmployeeMapper interface is responsible for
 * mapping Employee objects to EmployeeDto objects
 * and Profile objects to Employee objects.
 */
@Mapper(componentModel = "spring")
public interface EmployeeMapper {
  public  Employee profileResponseToEmployee(Profile profileResponse);

  public EmployeeDto employeeToEmployeeDto(Employee employee);
}
