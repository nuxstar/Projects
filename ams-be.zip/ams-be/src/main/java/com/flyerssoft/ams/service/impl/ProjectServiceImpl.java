package com.flyerssoft.ams.service.impl;

import com.flyerssoft.ams.exception.IllegalStateException;
import com.flyerssoft.ams.exception.NotFoundException;
import com.flyerssoft.ams.mapper.ProjectMapper;
import com.flyerssoft.ams.model.dto.project.ProjectDto;
import com.flyerssoft.ams.model.entity.Project;
import com.flyerssoft.ams.model.repository.EmployeeRepository;
import com.flyerssoft.ams.model.repository.ProjectRepository;
import com.flyerssoft.ams.service.ProjectService;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

/**
 * The project service implementation class.
 */
@Service
@Slf4j
public class ProjectServiceImpl implements ProjectService {

  @Autowired
  private ProjectRepository projectRepository;
  @Autowired
  private ProjectMapper projectMapper;
  @Autowired
  private EmployeeRepository employeeRepository;

  /**
   * Create project details.
   *
   * @param projectDto projectDto projectDto
   * @return created project details
   */
  @Override
  public ProjectDto createProject(ProjectDto projectDto) {
    Project project = projectRepository.save(projectMapper.toEntity(projectDto));
    log.info("Project details after saved into DB {}", project);
    return projectMapper.toDto(project);
  }

  /**
   * To get projects under employee.
   *
   * @param employeeId employeeId
   * @param page page
   * @param size size
   * @return project details
   */
  @Override
  public List<ProjectDto> readProject(int employeeId, int page, int size) {
    employeeRepository.findById(employeeId).orElseThrow(() ->
        new NotFoundException(String.format("Employee with ID %d not found", employeeId)));
    PageRequest pageRequest = PageRequest.of(page, size);
    List<Project> projectPage = projectRepository.findAllByEmployeeId(employeeId, pageRequest);
    return projectMapper.toDtoList(projectPage);
  }

  /**
   * Update project details.
   *
   * @param projectId projectId
   * @param projectDto projectDto
   * @return updated project details
   */
  @Override
  public ProjectDto updateProject(int projectId, ProjectDto projectDto) {
    var project = projectRepository.findById(projectId).orElseThrow(() ->
        new NotFoundException(String.format("Project with ID %d not found", projectId)));
    if (Objects.nonNull(projectDto.getProjectName())) {
      project.setProjectName(projectDto.getProjectName());
    }
    return projectMapper.toDto(projectRepository.save(project));
  }

  /**
   * To assign or remove the employee from a project.
   *
   * @param projectId projectId
   * @param employeeId employeeId
   * @param isAssign value
   * @return project with employee details
   */
  @Override
  public String assignOrRemoveEmployee(int projectId, int employeeId, boolean isAssign) {
    var project = projectRepository.findById(projectId).orElseThrow(() ->
        new NotFoundException(String.format("Project with ID %d not found", projectId)));

    var isEmployeeExist = project.getEmployees().stream().anyMatch(
        e -> e.getEmployeeId() == employeeId);

    if (!isEmployeeExist && isAssign) {
      //Employee not present in the project
      throw new IllegalStateException(String.format("Employee with ID %d not"
          + " present in the project", employeeId));
    } else if (isEmployeeExist && !isAssign) {
      //Employee already mapped to this project
      throw new IllegalStateException(String.format("Employee with ID %d is "
          + " already mapped to this project", employeeId));
    }
    var employees = project.getEmployees();

    if (!isAssign) {
      var employee = employeeRepository.findById(employeeId).orElseThrow(() ->
          new NotFoundException(String.format("Employee with ID %d not found", employeeId)));
      if (Objects.nonNull(employees)) {
        employees.add(employee);
      } else {
        employees = List.of(employee);
      }
      project.setEmployees(employees);
      project.setEmployeesCount((short) employees.size());
      projectRepository.save(project);
      return "Employee" + employeeId + " is mapped to project " + projectId + " successfully";
    } else {
      employees.removeIf(e -> e.getEmployeeId() == employeeId);
      project.setEmployees(employees);
      project.setEmployeesCount((short) employees.size());
      projectRepository.save(project);
      return "Employee " + employeeId + " is unmapped to project " + projectId + " successfully";
    }
  }

  /**
   * Delete project details.
   *
   * @param projectId projectId
   */
  @Override
  public void deleteProject(int projectId) {
    var project = projectRepository.findById(projectId).orElseThrow(() -> new NotFoundException(
        String.format("Project with ID %d not found", projectId)));
    projectRepository.delete(project);
  }
}
