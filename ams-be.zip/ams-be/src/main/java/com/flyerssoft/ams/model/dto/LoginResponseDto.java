package com.flyerssoft.ams.model.dto;

import com.flyerssoft.ams.client.microsoft.dto.Profile;

/**
 * This record will set transfer object on successful login.
 *
 * @param profile The profile associated with the login response.
 * @param expiresIn The expiration time of the access token.
 * @param accessToken The access token.
 */
public record LoginResponseDto(
    Profile profile,
    String expiresIn,
    String accessToken
) {}
