package com.flyerssoft.ams.config;

import com.flyerssoft.ams.model.dto.CallerData;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

/**
 * The configuration class.
 */
@Configuration
public class AmsConfiguration {

  @Bean
  @RequestScope
  public CallerData requestScopeCallerData() {
    return new CallerData();
  }
}
