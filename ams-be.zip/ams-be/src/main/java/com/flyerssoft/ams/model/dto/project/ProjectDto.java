package com.flyerssoft.ams.model.dto.project;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * The project dto.
 */
@Data
public class ProjectDto {

  private int projectId;
  @NotEmpty(message = "Project name should not be empty")
  private String projectName;
  private short employeesCount;
}
