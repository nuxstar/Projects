package com.flyerssoft.ams.mapper;

import com.flyerssoft.ams.model.dto.project.ProjectDto;
import com.flyerssoft.ams.model.entity.Project;
import java.util.List;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

/**
 * The project mapper interface.
 *
 */
@Mapper(componentModel = "spring")
public interface ProjectMapper {

  Project toEntity(ProjectDto projectDto);

  ProjectDto toDto(Project project);


  List<ProjectDto> toDtoList(List<Project> task);

  default Page<ProjectDto> pageEntityToPageDto(Page<Project> page) {
    List<ProjectDto> dtoList = toDtoList(page.getContent());
    return new PageImpl(dtoList, page.getPageable(), page.getTotalElements());
  }
}
