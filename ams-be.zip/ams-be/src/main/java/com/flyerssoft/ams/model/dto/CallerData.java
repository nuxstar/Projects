package com.flyerssoft.ams.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The CallerData class represents data related to a caller.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CallerData {

  public String callerId;

  public String accessToken;
}
