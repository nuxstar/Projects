package com.flyerssoft.ams.utility;

import java.text.ParseException;

/**
 * Utility class for working with Microsoft SSO tokens.
 */
public interface MicrosoftSsoTokenUtility {

  /**
   * Retrieves the user's Object ID (OID) from the provided access token.
   *
   * @param accessToken The access token.
   * @return The user's Object ID.
   * @throws ParseException If an error occurs while parsing the access token.
   */
  static String getUsersOid(String accessToken) throws ParseException {
    return JwtUtility
        .getParsedAccessToken(accessToken)
        .getClaim("oid")
        .toString();
  }
}
