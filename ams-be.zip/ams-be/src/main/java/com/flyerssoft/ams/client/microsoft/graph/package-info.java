/**
 * The client.microsoft.graph package provides classes and interfaces
 * for graph apis which will interact with Microsoft services.
 */
package com.flyerssoft.ams.client.microsoft.graph;
