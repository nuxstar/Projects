package com.flyerssoft.ams.exception;

/**
 * The not found exception class.
 *
 */
public class NotFoundException extends AmsException {

  public NotFoundException(String message) {
    super(message);
  }

}
