package com.flyerssoft.ams.rest.advice;

import com.flyerssoft.ams.exception.AmsException;
import com.flyerssoft.ams.exception.IllegalStateException;
import com.flyerssoft.ams.exception.NotFoundException;
import com.flyerssoft.ams.exception.UpstreamException;
import com.flyerssoft.ams.model.dto.AmsErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * This method will catch the given exception and send the custom error response
 * to the client.
 */
@RestControllerAdvice
public class AmsControllerAdvice {

  /**
   * This method will catch the upstreamException exception and send the custom error response
   * to the client.
   */
  @ExceptionHandler(UpstreamException.class)
  @ResponseBody
  public AmsErrorResponse upstreamException(UpstreamException ex) {
    return new AmsErrorResponse(
        ex.getStatusCode().value(),
        ex.getMessage(),
        ex.getStatusCode()
    );
  }

  @ExceptionHandler(NotFoundException.class)
  @ResponseBody
  @ResponseStatus(HttpStatus.NOT_FOUND)
  public AmsErrorResponse notFound(AmsException ex) {
    return new AmsErrorResponse(404, ex.getMessage(), HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(IllegalStateException.class)
  @ResponseBody
  @ResponseStatus(HttpStatus.CONFLICT)
  public AmsErrorResponse illegalState(AmsException ex) {
    return new AmsErrorResponse(409, ex.getMessage(), HttpStatus.CONFLICT);
  }
}
