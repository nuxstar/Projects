package com.flyerssoft.ams.rest.controller;

import com.flyerssoft.ams.model.dto.AmsResponse;
import com.flyerssoft.ams.model.dto.project.ProjectDto;
import com.flyerssoft.ams.service.ProjectService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * The project controller class.
 *
 */
@RestController
@RequestMapping("/v1")
public class ProjectController {

  @Autowired
  ProjectService projectService;

  /**
   * Create project.
   *
   * @param projectDto projectDto
   * @return created project details
   */
  @PostMapping("/projects")
  public ResponseEntity<AmsResponse<ProjectDto>> createProject(@RequestBody ProjectDto projectDto) {
    return new ResponseEntity<>(new AmsResponse<>(
        201,
        true,
        projectService.createProject(projectDto)),
        HttpStatus.CREATED);
  }

  /**
   * Get projects based on employee id using pagination.
   *
   * @param employeeId employeeId
   * @param page page
   * @param size size
   * @return all projects
   */
  @GetMapping("/projects")
  public ResponseEntity<AmsResponse<List<ProjectDto>>> readProject(
      @RequestParam(name = "employeeId") int employeeId,
      @RequestParam(name = "page") int page,
      @RequestParam(name = "size") int size) {
    List<ProjectDto> response = projectService.readProject(employeeId, page, size);
    return new ResponseEntity<>(new AmsResponse<>(200, true, response), HttpStatus.OK);
  }

  /**
   * Update project details.
   *
   * @param projectId projectId
   * @param projectDto projectDto
   *
   * @return updated project details
   */
  @PutMapping("/projects/{projectId}")
  public ResponseEntity<AmsResponse<String>> updateProjectById(
      @PathVariable int projectId,
      @RequestBody ProjectDto projectDto) {
    ProjectDto projectResponse = projectService.updateProject(projectId, projectDto);
    return new ResponseEntity<>(new AmsResponse<>(
        200, true, "Project "
        + projectResponse.getProjectName() +  " is updated successfully"),
        HttpStatus.OK);
  }

  /**
   * Map / un map employee with project.
   *
   * @param projectId projectId
   * @param employeeId employeeId
   * @return updated project details
   */
  @PutMapping("/projects/{projectId}/{employeeId}")
  public ResponseEntity<AmsResponse<String>> updateProject(
      @PathVariable int projectId,
      @PathVariable int employeeId,
      @RequestParam (name = "value") boolean isAssign) {

    String response =  projectService.assignOrRemoveEmployee(projectId, employeeId, isAssign);
    return new ResponseEntity<>(new AmsResponse<>(200, true, response), HttpStatus.OK);
  }

  /**
   * Delete project.
   *
   * @param projectId projectId
   * @return successfully message
   */
  @DeleteMapping("/projects/{projectId}")
  public ResponseEntity<AmsResponse<String>> deleteProject(@PathVariable int projectId) {
    projectService.deleteProject(projectId);
    return new ResponseEntity<>(new AmsResponse<>(
        200,
        true,
        "project " + projectId + " is deleted successfully"), HttpStatus.OK);
  }

}
