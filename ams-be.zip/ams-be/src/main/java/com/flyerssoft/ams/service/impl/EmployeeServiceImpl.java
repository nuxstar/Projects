package com.flyerssoft.ams.service.impl;

import com.flyerssoft.ams.client.microsoft.dto.Profile;
import com.flyerssoft.ams.mapper.EmployeeMapper;
import com.flyerssoft.ams.model.dto.EmployeeDto;
import com.flyerssoft.ams.model.entity.Employee;
import com.flyerssoft.ams.model.repository.EmployeeRepository;
import com.flyerssoft.ams.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The implementation of the EmployeeService interface.
 * This class provides methods for adding employees and
 * interacting with the EmployeeRepository.
 */
@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

  /**
   * The EmployeeMapper used for mapping Profile objects
   * to Employee objects.
   */
  @Autowired
  private EmployeeMapper employeeMapper;

  /**
   * The EmployeeRepository used for accessing and persisting Employee objects.
   */
  @Autowired
  private EmployeeRepository employeeRepository;

  /**
   * Adds an employee based on the provided profileResponse.
   *
   * @param profileResponse The profileResponse containing the employee details.
   * @return The EmployeeDto representing the added employee.
   */
  @Override
  public EmployeeDto addEmployee(final Profile profileResponse) {
    Employee employee = employeeMapper.profileResponseToEmployee(
        profileResponse
    );
    employeeRepository.save(employee);
    return employeeMapper.employeeToEmployeeDto(employee);
  }
}
