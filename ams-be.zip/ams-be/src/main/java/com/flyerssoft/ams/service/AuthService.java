package com.flyerssoft.ams.service;

import com.flyerssoft.ams.model.dto.LoginResponseDto;
import java.text.ParseException;

/**
 * The auth service.
 */
public interface AuthService {

  /**
   * login response.
   *
   * @param authCode authCode
   * @return login response dto
   * @throws ParseException parse exception
   */
  LoginResponseDto login(String authCode) throws ParseException;
}
