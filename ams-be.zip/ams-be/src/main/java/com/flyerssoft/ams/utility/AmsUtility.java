package com.flyerssoft.ams.utility;

import java.time.Instant;

/**
 * This class contains all the helper functions for
 * ams project.
 */
public interface AmsUtility {

  /*
   * Method to get current time In zone time format
   */
  public static String getCurrentZoneTimeFormatTime() {
    return Instant.now().toString();
  }

}
