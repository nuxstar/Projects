/**
 * The client.microsoft.auth package provides classes and interfaces
 * for authenticating and interacting with Microsoft services.
 */
package com.flyerssoft.ams.client.microsoft.auth;
