package com.flyerssoft.ams.model.dto;

import org.springframework.http.HttpStatus;

/**
 * Represents an error response for the AMS API.
 * The {@code AmsErrorResponse} class encapsulates information
 * about an error that occurred during API processing.
 * It contains details such as the status code, error message, and
 * HTTP status. This class is used to provide consistent error
 * responses to clients consuming the AMS API.
 */

public class AmsErrorResponse {

  private int status;
  private String message;
  private HttpStatus restStatus;

  /**
   * Represents an employee data transfer object (DTO).
   *
   * @param statusCode http status code.
   * @param message    custom error message.
   * @param restStatus represents http status of the error response.
   */
  public AmsErrorResponse(int statusCode, String message, HttpStatus restStatus) {
    this.status = statusCode;
    this.message = message;
    this.restStatus = restStatus;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public HttpStatus getRestStatus() {
    return restStatus;
  }

  public void setRestStatus(HttpStatus restStatus) {
    this.restStatus = restStatus;
  }
}
