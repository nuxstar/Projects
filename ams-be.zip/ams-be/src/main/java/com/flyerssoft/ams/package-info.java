/**
 * Attendance Management System is a time tracker and
 * leave management app that lets you track work hours and
 * leave approvals of all employees across projects.
 */
package com.flyerssoft.ams;
