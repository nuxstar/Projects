package com.Hospital_Appointment_Booking.Service;

import com.Hospital_Appointment_Booking.Entity.Appointment;
import com.Hospital_Appointment_Booking.Entity.Hospital;

public interface AppointmentService {

    Appointment addAppointment(int patientId,int doctorId,int hospitalId,Appointment appointment);
    Appointment updateAppointmentDetail(int appointmentId,Appointment appointment);
    Appointment getAppointmentDetail(int appointmentId);
    boolean     deleteAppointmentDetail(int appointmentId);

}
