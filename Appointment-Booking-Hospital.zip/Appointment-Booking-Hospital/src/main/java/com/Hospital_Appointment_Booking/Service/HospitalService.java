package com.Hospital_Appointment_Booking.Service;

import com.Hospital_Appointment_Booking.Entity.Hospital;

import java.sql.SQLException;

public interface HospitalService {

   Hospital addHospital(Hospital hospital) throws SQLException;
   Hospital updateHospital(int hospitalId,Hospital hospital) throws SQLException;
   Hospital getHospitalDetails(int hospitalId) throws SQLException;
   Boolean deleteHospital(int hospitalId) throws SQLException;

}
