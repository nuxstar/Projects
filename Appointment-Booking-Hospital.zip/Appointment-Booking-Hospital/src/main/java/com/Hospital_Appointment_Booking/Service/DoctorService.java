package com.Hospital_Appointment_Booking.Service;

import com.Hospital_Appointment_Booking.Entity.Doctor;
import com.Hospital_Appointment_Booking.expection.AppException;

public interface DoctorService {

    Doctor addDoctor(Doctor doctor,int hospitalId) throws AppException;
    Doctor updateDoctorDetail(int doctorId,Doctor doctor);
    Doctor getDoctorDetail(int doctorId);
    Boolean deleteDoctorDetail(int doctorId);

}
