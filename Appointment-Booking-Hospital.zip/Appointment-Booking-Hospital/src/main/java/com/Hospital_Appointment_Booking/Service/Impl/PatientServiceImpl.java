package com.Hospital_Appointment_Booking.Service.Impl;

import com.Hospital_Appointment_Booking.Dao.DaoImpl.PatientDaoImpl;
import com.Hospital_Appointment_Booking.Dao.PatientDao;
import com.Hospital_Appointment_Booking.Entity.Patient;
import com.Hospital_Appointment_Booking.Service.PatientService;

public class PatientServiceImpl implements PatientService {

    private PatientDao patientDao = new PatientDaoImpl();

    @Override
    public Patient addPatient(Patient patient) {

      Patient patient1 =   patientDao.addPatient(patient);
        return patient1;
    }

    @Override
    public Patient updatePatientDetail(String name,Patient patient) {

        Patient patient1 =  patientDao.updatePatientDetail(name,patient);

        return patient1;
    }

    @Override
    public Patient getPatientDetail(int patientId) {

      Patient patient =   patientDao.getPatientDetail(patientId);

        return patient;
    }

    @Override
    public boolean deletePatientDetail(int patientId) {

       Boolean b =  patientDao.deletePatientDetail(patientId);

        return b;
    }
}
