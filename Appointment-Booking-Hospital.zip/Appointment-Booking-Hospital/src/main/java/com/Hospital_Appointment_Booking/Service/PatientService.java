package com.Hospital_Appointment_Booking.Service;

import com.Hospital_Appointment_Booking.Entity.Patient;

public interface PatientService {

    Patient addPatient(Patient patient);
    Patient updatePatientDetail(String patientName,Patient patient);
    Patient getPatientDetail(int patientId);
    boolean deletePatientDetail(int patientId);


}
