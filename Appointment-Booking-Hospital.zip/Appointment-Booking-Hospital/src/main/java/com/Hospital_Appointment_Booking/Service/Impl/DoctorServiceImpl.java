package com.Hospital_Appointment_Booking.Service.Impl;

import com.Hospital_Appointment_Booking.Dao.DaoImpl.DoctorDaoImpl;
import com.Hospital_Appointment_Booking.Dao.DoctorDao;
import com.Hospital_Appointment_Booking.Entity.Doctor;
import com.Hospital_Appointment_Booking.Service.DoctorService;
import com.Hospital_Appointment_Booking.expection.AppException;

public class DoctorServiceImpl implements DoctorService {

    DoctorDao doctorDao = new DoctorDaoImpl();

    @Override
    public Doctor addDoctor(Doctor doctor, int hospitalId) throws AppException {

     Doctor addDoctor =    doctorDao.addDoctor(doctor,hospitalId);
        return addDoctor;
    }


    @Override
    public Doctor updateDoctorDetail(int doctorId, Doctor doctor) {

      Doctor updateDoctorDoctor =   doctorDao.updateDoctorDetail(doctorId,doctor);

        return updateDoctorDoctor;
    }

    @Override
    public Doctor getDoctorDetail(int doctorId) {


       Doctor doctor =  doctorDao.getDoctorDetail(doctorId);

        return doctor;
    }

    @Override
    public Boolean deleteDoctorDetail(int doctorId)
    {

       Boolean bool =  doctorDao.deleteDoctorDetail(doctorId);

        return bool;
    }
}
