package com.Hospital_Appointment_Booking.Service.Impl;

import com.Hospital_Appointment_Booking.Dao.DaoImpl.HospitalDaoImpl;
import com.Hospital_Appointment_Booking.Dao.HospitalDao;
import com.Hospital_Appointment_Booking.Entity.Hospital;
import com.Hospital_Appointment_Booking.Service.HospitalService;

import java.sql.SQLException;

public class HospitalServiceImpl implements HospitalService {

    private HospitalDao hospitalDao = new HospitalDaoImpl();

    @Override
    public Hospital addHospital(Hospital hospital) throws SQLException {

       Hospital result =  hospitalDao.addHospital(hospital);

        return result;
    }

    @Override
    public Hospital updateHospital(int branchId, Hospital hospital) throws SQLException {

       Hospital result  =  hospitalDao.updateHospital(branchId,hospital);

        return result;
    }

    @Override
    public Hospital getHospitalDetails(int branchId) throws SQLException {


      Hospital hospital = hospitalDao.getHospitalDetails(branchId);

      return hospital;
    }

    @Override
    public Boolean deleteHospital(int branchId) throws SQLException {

      Boolean bool =  hospitalDao.deleteHospital(branchId);

        return bool;
    }
}
