package com.Hospital_Appointment_Booking.Service.Impl;

import com.Hospital_Appointment_Booking.Dao.AppointmentDao;
import com.Hospital_Appointment_Booking.Dao.DaoImpl.AppointmentDaoImpl;
import com.Hospital_Appointment_Booking.Entity.Appointment;
import com.Hospital_Appointment_Booking.Service.AppointmentService;

public class AppointmentServiceImpl implements AppointmentService {

    private AppointmentDao appointmentDao = new AppointmentDaoImpl();

    @Override
    public Appointment addAppointment(int patientId,int doctorId,int hospitalId,Appointment appointment) {

        Appointment appointment1 = appointmentDao.addAppointment(patientId,doctorId,hospitalId,appointment);

        return appointment1;
    }

    @Override
    public Appointment updateAppointmentDetail(int appointmentId, Appointment appointment) {

      Appointment appointment1 =   appointmentDao.updateAppointmentDetail(appointmentId,appointment);

        return appointment1;
    }

    @Override
    public Appointment getAppointmentDetail(int appointmentId) {

      Appointment appointment =   appointmentDao.getAppointmentDetail(appointmentId);

        return appointment;
    }

    @Override
    public boolean deleteAppointmentDetail(int appointmentId) {

       Boolean b =  appointmentDao.deleteAppointmentDetail(appointmentId);
        return b;
    }
}
