package com.Hospital_Appointment_Booking;

import com.Hospital_Appointment_Booking.Client.AppointmentClient;
import com.Hospital_Appointment_Booking.Client.DoctorClient;
import com.Hospital_Appointment_Booking.Client.HospitalClient;
import com.Hospital_Appointment_Booking.Client.PatientClient;
import com.Hospital_Appointment_Booking.Entity.Appointment;
import com.Hospital_Appointment_Booking.Entity.Doctor;
import com.Hospital_Appointment_Booking.Entity.Hospital;
import com.Hospital_Appointment_Booking.Entity.Patient;
import com.Hospital_Appointment_Booking.expection.AppException;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Scanner;

public class Application {

    public static void main(String[] args) throws SQLException {

        HospitalClient hospitalClient = new HospitalClient();
        DoctorClient doctorClient = new DoctorClient();

        Scanner str = new Scanner(System.in);
        System.out.println("Which Module to Add :");
        System.out.println("Enter 1 To-HOSPITAL ");
        System.out.println("Enter 2 To-DOCTOR ");
        System.out.println("Enter 3 To-PATIENT");
        System.out.println("Enter 4 To-APPOINTMENT");
       int module =  str.nextInt();

       switch (module){


           case 1:{

               Scanner sc = new Scanner(System.in);
               System.out.println("Enter a Action You Want To Perform For HOSPITAL");
               System.out.println("Enter 1 To-ADD ");
               System.out.println("Enter 2 To-UPDATE ");
               System.out.println("Enter 3 To-READ ");
               System.out.println("Enter 4 To-DELETE ");
               int action = sc.nextInt();
               switch (action){


                   case 1: {

                       System.out.println("Add Hospital Details :");
                       System.out.println("Enter Branch Code:");
                       int code = sc.nextInt();
                       System.out.println("Enter Name:");
                       String name = sc.next();
                       System.out.println("Enter Address:");
                       String add = sc.next();

                       Hospital result = hospitalClient.addHospital(code, name, add);
                       if (Objects.nonNull(result)) {
                           System.out.println("Successfully Added Hospital Record");
                       } else {
                           System.out.println("Something Wrong");
                       }

                       break;
                   }

                   case 2:{

                       System.out.println("Update Hospital Details :");
                       System.out.println("Enter Branch ID:");
                       int branch =sc.nextInt();
                       System.out.println("Update Hospital Address");
                       String address = sc.next();

                       Hospital result = hospitalClient.updateHospital(branch,address);

                       if (Objects.nonNull(result)){
                           System.out.println("Update Successfully "+" Hospital ID:"+ result.getHospitalId()+" Hospital Branch "+result.getHospitalBranch()+" Hospital Name :"+result.getHospitalName()+" Hospital Address "+ result.getHospitalAddress());
                       }
                       else {
                           System.out.println("Update Not Successfully");
                       }
                       break;
                   }

                   case 3 :{

                       System.out.println("Enter Branch ID To Get Hospital Details :");
                       int id = sc.nextInt();

                       Hospital result =  hospitalClient.getHospitalDetail(id);

                       if (Objects.nonNull(result)){

                           int i =  result.getHospitalId();
                           int code =  result.getHospitalBranch();
                           String  name =   result.getHospitalName();
                           String address =   result.getHospitalAddress();

                           System.out.println("Id :"+i+" "+"BranchCode :"+code+" "+"Name :"+name+" "+"Address: "+address);
                       }
                       else {
                           System.out.println("Invalid Code");
                       }

                       break;
                   }

                   case 4:{

                       System.out.println("Enter Branch Id To Delete Hospital");
                       int id = sc.nextInt();
                       Boolean bool = hospitalClient.deleteHospitalDetails(id);

                       if (bool){

                           System.out.println("Successfully Deleted");
                       }
                       else {

                           System.out.println("Not Deleted");
                       }

                       break;
                   }

                   default:
                       System.out.println("Invalid Code;");

               }

               break;
           }

           case 2:{

               Scanner sc = new Scanner(System.in);
               System.out.println("Enter a Action You Want To Perform For Doctor :");
               System.out.println("Enter 1 To-ADD ");
               System.out.println("Enter 2 To-UPDATE ");
               System.out.println("Enter 3 To-READ ");
               System.out.println("Enter 4 To-DELETE ");
               int DoctorAction = sc.nextInt();
               switch (DoctorAction){


                   case 1: {

                       System.out.println("Enter Hospital ID :");
                       int id = sc.nextInt();
                       System.out.println("Enter Doctor Name:");
                       String name = sc.next();
                       System.out.println("Enter Doctor specialization:");
                       String specialization = sc.next();

                       Doctor doctor = null;
                       try {
                            doctor =  doctorClient.addDoctor(name,specialization,id);
                       }
                       catch (AppException e){

                           System.out.println(e.getMessage());
                       }
                       if (Objects.nonNull(doctor)){

                           System.out.println("Added Successfully");
                       }
                       else {

                           System.out.println("Not Added");
                       }

                       break;
                   }

                   case 2 : {

                       System.out.println("Enter Doctor ID");
                       int id =  sc.nextInt();
                       System.out.println("Update to Doctor Name");
                       String name =sc.next();
                       System.out.println("Update to Doctor Specialization");
                       String spec =sc.next();

                       Doctor doctor = doctorClient.updateDoctor(id,name,spec);
                       System.out.println("Doctor Id :" + doctor.getDoctorId()+"Doctor Name :"+doctor.getDoctorName()+"Doctor Specialization :"+"Doctor Specialization:"+doctor.getDoctorSpecialization() );


                       break;
                   }

                   case 3 :{

                       System.out.println("Enter Doctor ID");
                       int id =  sc.nextInt();

                      Doctor doctor = doctorClient.getDoctorDetails(id);

                       System.out.println("Doctor Id : " + doctor.getDoctorId()+"Doctor Name : "+doctor.getDoctorName()+"Doctor Specialization : "+doctor.getDoctorSpecialization() );

                       break;
                   }

                   case 4 :{

                       System.out.println("Enter Doctor ID");
                       int id =  sc.nextInt();

                       Boolean bool = doctorClient.deleteDoctor(id);

                       if (bool){
                           System.out.println("Successfully Deleted Doctor Details");
                       }
                       else {
                           System.out.println("Not Deleted Invalid Code!!!!!");
                       }

                       break;
                   }
           }

           break;

       }

           case 3 :{

               Scanner sc = new Scanner(System.in);
               System.out.println("Enter a Action You Want To Perform For Patient :");
               System.out.println("Enter 1 To-ADD ");
               System.out.println("Enter 2 To-UPDATE ");
               System.out.println("Enter 3 To-READ ");
               System.out.println("Enter 4 To-DELETE ");
               int patientAction = sc.nextInt();

               PatientClient client = new PatientClient();

               switch (patientAction){

                   case 1:{

                       System.out.println("Add Operation :");
                       System.out.println("Enter Patient Name:");
                       String name = sc.next();
                       System.out.println("Enter Patient Gender:");
                       String gender = sc.next();
                       System.out.println("Enter patient Number:");
                       Long num = sc.nextLong();

                       Patient patient =  client.addPatient(name,gender,num);
                       System.out.println("Successfully Added Patient Details :");


                       break;
                   }
                   case  2:{

                       System.out.println("Update Operation :");
                       System.out.println("Enter Patient Name You Want To Update:");
                       String name = sc.next();
                       System.out.println("Enter Patient Gender:");
                       String gender = sc.next();
                       System.out.println("Enter patient Number:");
                       Long num = sc.nextLong();

                     Patient patient =   client.updatePatient(name,gender,num);

                    System.out.println("Patient Details Updated :");

                    break;
                   }
                   case 3:{

                       System.out.println("Get Operation :");
                       System.out.println("Enter Patient ID You Want To Get:");
                       int id = sc.nextInt();

                      Patient patient =  client.getPatient(id);

                      String name = patient.getPatientName();
                      String gender = patient.getPatientGender();
                      long num = patient.getPatientNumber();

                      System.out.println("Patient_Name :"+name+" "+"Patient_Gender :"+gender+" "+"Patient_Number :"+" "+num);

                      break;
                   }
                   case 4:{

                       System.out.println("Delete Operation :");
                       System.out.println("Enter Patient ID You Want To Delete:");
                       int id = sc.nextInt();

                     Boolean b =   client.deletePatient(id);

                     if (b)
                         System.out.println("Successfully Deleted Patient Detail");
                     else
                         System.out.println("Not Deleted Successfully");
                   }
                   break;
               }
               break;

           }

           case 4 :{

               Scanner sc = new Scanner(System.in);
               System.out.println("Enter a Action You Want To Perform For Appointment :");
               System.out.println("Enter 1 To-ADD ");
               System.out.println("Enter 2 To-UPDATE ");
               System.out.println("Enter 3 To-READ ");
               System.out.println("Enter 4 To-DELETE ");
               int appointmentAction = sc.nextInt();

               AppointmentClient appointmentClient = new AppointmentClient();

               switch (appointmentAction){

                   case 1:{

                       System.out.println("Add Operation :");
                       System.out.println("Add Appointment Time :");
                       String time = sc.next();
                       System.out.println("Enter patient Id:");
                       int pId = sc.nextInt();
                       System.out.println("Enter Hospital Id:");
                       int hId = sc.nextInt();
                       System.out.println("Enter Doctor Id:");
                       int dId = sc.nextInt();

                    Appointment appointment =   appointmentClient.addAppointment(pId,dId,hId,time);

                    System.out.println("Appointment Added Successfully :");

                       break;
                   }
                   case 2:{




                   }
                   case 3:{

                       System.out.println("Get  Operation :");
                       System.out.println("Enter Appointment To Get Details :");
                       int id = sc.nextInt();

                    Appointment appointment =  appointmentClient.getAppointment(id);
                   int appointmentId = appointment.getAppointmentId();
                       String time = appointment.getAppointmentTime();

                       System.out.println("Appointment Id :"+" "+appointmentId+" "+"Appointment Time :"+" "+time);

                   }
                   case 4:{

                       System.out.println("Delete Operation :");
                       System.out.println("Enter Appointment ID You Want To Delete:");
                       int id = sc.nextInt();

                       Boolean b =   appointmentClient.deleteAppointment(id);

                       if (b)
                           System.out.println("Successfully Deleted Patient Detail");
                       else
                           System.out.println("Not Deleted Successfully");

                   }
                   default:
                       System.out.println("Invalid");
               }

               break;
           }





           default:
               System.out.println("Invalid");



    }


    }

}
