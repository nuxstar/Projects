package com.Hospital_Appointment_Booking.Entity;

import java.util.Date;

public class Appointment {

    private  int appointmentId;

    private String appointmentTime;

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }
}
