package com.Hospital_Appointment_Booking.Entity;

public class Hospital {

    private int hospitalId;
    private int HospitalBranch;
    private String hospitalName;
    private String hospitalAddress;

    public int getHospitalBranch() {
        return HospitalBranch;
    }



    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public void setHospitalBranch(int hospitalBranch) {
        HospitalBranch = hospitalBranch;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getHospitalAddress() {
        return hospitalAddress;
    }

    public void setHospitalAddress(String hospitalAddress) {
        this.hospitalAddress = hospitalAddress;
    }



}
