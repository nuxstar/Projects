package com.Hospital_Appointment_Booking.Client;

import com.Hospital_Appointment_Booking.Entity.Hospital;
import com.Hospital_Appointment_Booking.Service.HospitalService;
import com.Hospital_Appointment_Booking.Service.Impl.HospitalServiceImpl;

import java.sql.SQLException;

public class HospitalClient {

    private HospitalService hospitalService = new HospitalServiceImpl();

   public Hospital addHospital(int branchCode,String name,String address) throws SQLException {

       Hospital hospital = new Hospital();

        hospital.setHospitalBranch(branchCode);
        hospital.setHospitalName(name);
        hospital.setHospitalAddress(address);
        Hospital result =  hospitalService.addHospital(hospital);

     return result;

    }

    public  Hospital updateHospital(int branchId,String add) throws SQLException {

       Hospital hospital = new Hospital();
       hospital.setHospitalAddress(add);

      Hospital result =  hospitalService.updateHospital(branchId,hospital);

      return result;

    }


    public  Hospital  getHospitalDetail(int branchId) throws SQLException {

     Hospital hospital =  hospitalService.getHospitalDetails(branchId);

     return hospital;
    }

    public Boolean deleteHospitalDetails(int id) throws SQLException {

         Boolean bool =   hospitalService.deleteHospital(id);

         return bool;

    }



}
