package com.Hospital_Appointment_Booking.Client;

import com.Hospital_Appointment_Booking.Entity.Doctor;
import com.Hospital_Appointment_Booking.Entity.Hospital;
import com.Hospital_Appointment_Booking.Service.DoctorService;
import com.Hospital_Appointment_Booking.Service.Impl.DoctorServiceImpl;
import com.Hospital_Appointment_Booking.expection.AppException;

public class DoctorClient {

    DoctorService doctorService = new DoctorServiceImpl();

   public Doctor  addDoctor(String name,String doctorSpecialization,int hospitalId) throws AppException {

       Doctor doctor = new Doctor();
       doctor.setDoctorName(name);
       doctor.setDoctorSpecialization(doctorSpecialization);

      Doctor doctor1 =  doctorService.addDoctor(doctor,hospitalId);
      return doctor1;

    }

    public  Doctor updateDoctor(int id,String name,String spec){

       Doctor doctor = new Doctor();
       doctor.setDoctorId(id);
       doctor.setDoctorName(name);
       doctor.setDoctorSpecialization(spec);

      Doctor updateDoctor = doctorService.updateDoctorDetail(id,doctor);

      return updateDoctor;

    }

    public Doctor getDoctorDetails(int id){

      Doctor doctor =  doctorService.getDoctorDetail(id);

      return  doctor;
    }

    public  Boolean deleteDoctor(int id){

      Boolean bool=  doctorService.deleteDoctorDetail(id);

      return  bool;
    }

}
