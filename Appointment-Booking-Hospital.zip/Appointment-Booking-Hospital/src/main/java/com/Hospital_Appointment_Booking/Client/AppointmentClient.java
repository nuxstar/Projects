package com.Hospital_Appointment_Booking.Client;

import com.Hospital_Appointment_Booking.Entity.Appointment;
import com.Hospital_Appointment_Booking.Service.AppointmentService;
import com.Hospital_Appointment_Booking.Service.Impl.AppointmentServiceImpl;

public class AppointmentClient{


    private AppointmentService appointmentService = new AppointmentServiceImpl();

    public  Appointment addAppointment(int pId,int dId,int hId,String time){

        Appointment appointment = new Appointment();
        appointment.setAppointmentTime(time);

        Appointment appointment1 =   appointmentService.addAppointment(pId,dId,hId,appointment);

        return appointment1;
    }

    public  void updateAppointment(){

    }
    public  Appointment getAppointment(int id){

     Appointment appointment =  appointmentService.getAppointmentDetail(id);

     return  appointment;
    }
    public  Boolean deleteAppointment(int id){

        Boolean b = appointmentService.deleteAppointmentDetail(id);

        return b; 
    }



}
