package com.Hospital_Appointment_Booking.Client;
import com.Hospital_Appointment_Booking.Entity.Patient;
import com.Hospital_Appointment_Booking.Service.Impl.PatientServiceImpl;
import com.Hospital_Appointment_Booking.Service.PatientService;

public class PatientClient {


    private PatientService patientService = new PatientServiceImpl();

    public  Patient addPatient(String name,String gender,long num){

        Patient patient = new Patient();
        patient.setPatientName(name);
        patient.setPatientGender(gender);
        patient.setPatientNumber(num);

       Patient result =  patientService.addPatient(patient);

       return result;
    }

    public Patient updatePatient(String name,String gender ,long num){

        Patient patient = new Patient();
        patient.setPatientGender(gender);
        patient.setPatientNumber(num);

      Patient result =   patientService.updatePatientDetail(name,patient);

      return result;
    }

    public  Patient getPatient(int id){

     Patient patient =    patientService.getPatientDetail(id);

        return  patient;
    }

    public  Boolean deletePatient(int id){


      Boolean b =   patientService.deletePatientDetail(id);

      return b;
    }

}
