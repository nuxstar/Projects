package com.Hospital_Appointment_Booking.Utility;

public class AppConstants {

    public static final String NOT_FOUND_EXCEPTION = "%s is not found with this %s";
}
