package com.Hospital_Appointment_Booking.Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    private final String user = "root";
    private final String pass = "admin";
    private final String url = "jdbc:mysql://localhost:3306/Hospital_Booking";

    public Connection connectJdbc() throws SQLException {

        Connection connect =DriverManager.getConnection(url,user,pass);

        return connect;
    }

}
