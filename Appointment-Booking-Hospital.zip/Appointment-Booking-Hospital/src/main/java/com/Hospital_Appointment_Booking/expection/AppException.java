package com.Hospital_Appointment_Booking.expection;

public class AppException extends RuntimeException{
    public AppException(String message) {
        super(message);
    }
}
