package com.Hospital_Appointment_Booking.expection;

public class NotFoundException extends AppException{
    public NotFoundException(String message) {
        super(message);
    }
}
