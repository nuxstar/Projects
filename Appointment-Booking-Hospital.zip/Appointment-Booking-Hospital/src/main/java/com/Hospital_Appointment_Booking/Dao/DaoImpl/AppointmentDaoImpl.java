package com.Hospital_Appointment_Booking.Dao.DaoImpl;

import com.Hospital_Appointment_Booking.Dao.AppointmentDao;
import com.Hospital_Appointment_Booking.Entity.Appointment;
import com.Hospital_Appointment_Booking.Entity.Patient;
import com.Hospital_Appointment_Booking.Utility.MyConnection;
import com.Hospital_Appointment_Booking.expection.AppException;
import com.Hospital_Appointment_Booking.expection.NotFoundException;

import java.sql.*;

public class AppointmentDaoImpl implements AppointmentDao {

    private MyConnection myConnection = new MyConnection();


    @Override
    public Appointment addAppointment(int patientId,int doctorId,int hospitalId,Appointment appointment) {

        String checkDoctorQuery = "SELECT * FROM DOCTOR WHERE DOCTOR_ID ='"+doctorId+"'";

        Connection connection=null;
        try {
             connection =  myConnection.connectJdbc();
             Statement statement = connection.createStatement();
            ResultSet checkDoctor = statement.executeQuery(checkDoctorQuery);

            if (!checkDoctor.next()){

                throw  new NotFoundException("Hospital and Doctor Not Found");
            }
            String addAppointmentQuery = "INSERT INTO APPOINTMENT_DETAILS(APPOINTMENT_TIME ,PATIENT_ID ,DOCTOR_ID,HOSPITAL_ID) VALUE(?,?,?,?)";
           PreparedStatement preparedStatement =  connection.prepareStatement(addAppointmentQuery);
            preparedStatement.setString(1,appointment.getAppointmentTime());
            preparedStatement.setInt(2,patientId);
            preparedStatement.setInt(3,doctorId);
            preparedStatement.setInt(4,hospitalId);
           int result =  preparedStatement.executeUpdate();


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

        return null;
    }

    @Override
    public Appointment updateAppointmentDetail(int appointmentId, Appointment appointment) {


        Connection connection=null;
        try {
            connection =  myConnection.connectJdbc();

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


        return null;
    }

    @Override
    public Appointment getAppointmentDetail(int appointmentId) {



        Connection connection=null;
        try {
            connection =  myConnection.connectJdbc();
           Statement statement =  connection.createStatement();
         ResultSet resultSet =   statement.executeQuery("SELECT * FROM APPOINTMENT_DETAILS WHERE APPOINTMENT_ID='"+appointmentId+"'");

         while (resultSet.next()){

          String time = resultSet.getString("APPOINTMENT_TIME");
          int aId = resultSet.getInt("APPOINTMENT_ID");
           int pId =    resultSet.getInt("PATIENT_ID");
           int dId = resultSet.getInt("DOCTOR_ID");
           int hId =   resultSet.getInt("HOSPITAL_ID");

           Appointment appointment = new Appointment();
           appointment.setAppointmentTime(time);
           appointment.setAppointmentId(aId);


           return  appointment;
         }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


        return null;
    }

    @Override
    public boolean deleteAppointmentDetail(int appointmentId) {

        Connection connection=null;
        try {
            connection =  myConnection.connectJdbc();
            Statement statement =  connection.createStatement();
          int result =  statement.executeUpdate("DELETE * FROM APPOINTMENT WHERE='"+appointmentId+"'");

          if (result == 1)
              return true;

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


        return false;
    }
}
