package com.Hospital_Appointment_Booking.Dao;

import com.Hospital_Appointment_Booking.Entity.Appointment;

public interface AppointmentDao {

    Appointment addAppointment(int patientId,int doctorId,int hospitalId,Appointment appointment);
    Appointment updateAppointmentDetail(int appointmentId,Appointment appointment);
    Appointment getAppointmentDetail(int appointmentId);
    boolean     deleteAppointmentDetail(int appointmentId);
}
