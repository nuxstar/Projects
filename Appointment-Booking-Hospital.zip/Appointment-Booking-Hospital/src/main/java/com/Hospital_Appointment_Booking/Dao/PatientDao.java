package com.Hospital_Appointment_Booking.Dao;

import com.Hospital_Appointment_Booking.Entity.Patient;

public interface PatientDao {

    Patient addPatient(Patient patient);
    Patient updatePatientDetail(String patientId, Patient patient);
    Patient getPatientDetail(int patientId);
    boolean deletePatientDetail(int patientId);
}
