package com.Hospital_Appointment_Booking.Dao;

import com.Hospital_Appointment_Booking.Entity.Doctor;

import java.sql.SQLException;

public interface DoctorDao {

    Doctor addDoctor(Doctor doctor, int hospitalId);
    Doctor updateDoctorDetail(int doctorId,Doctor doctor);
    Doctor getDoctorDetail(int doctorId);
    Boolean deleteDoctorDetail(int doctorId);
}
