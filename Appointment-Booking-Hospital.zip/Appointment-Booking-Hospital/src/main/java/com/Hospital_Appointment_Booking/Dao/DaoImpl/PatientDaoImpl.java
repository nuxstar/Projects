package com.Hospital_Appointment_Booking.Dao.DaoImpl;

import com.Hospital_Appointment_Booking.Dao.PatientDao;
import com.Hospital_Appointment_Booking.Entity.Patient;
import com.Hospital_Appointment_Booking.Utility.MyConnection;
import com.Hospital_Appointment_Booking.expection.AppException;

import java.sql.*;

public class PatientDaoImpl implements PatientDao {

   private  MyConnection connection = new MyConnection();
    @Override
    public Patient addPatient(Patient patient) {

        String addPatientQuery = "INSERT INTO PATIENT(PATIENT_NAME,PATIENT_GENDER,PATIENT_mobileNO) VALUE(?,?,?) ";


        Connection connection1= null;
        try {
             connection1 =  connection.connectJdbc();

           PreparedStatement preparedStatement =   connection1.prepareStatement(addPatientQuery);
           preparedStatement.setString(1,patient.getPatientName());
           preparedStatement.setString(2,patient.getPatientGender());
           preparedStatement.setLong(3,patient.getPatientNumber());
           preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection1.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }


        return null;
    }

    @Override
    public Patient updatePatientDetail(String patientName, Patient patient) {

        String updateQuery = "UPDATE PATIENT SET PATIENT_GENDER=(?), PATIENT_mobileNO=(?) WHERE PATIENT_NAME=(?)";
        Connection connection1= null;
        PreparedStatement preparedStatement;
        try {
            connection1 =  connection.connectJdbc();
            preparedStatement =  connection1.prepareStatement(updateQuery);
            preparedStatement.setString(1,patient.getPatientGender());
            preparedStatement.setLong(2,patient.getPatientNumber());
            preparedStatement.setString(3,patientName);

          int result =   preparedStatement.executeUpdate();

          if (result == 1 ){
              Statement statement =  connection1.createStatement();
              ResultSet resultSet = statement.executeQuery("SELECT * FROM PATIENT WHERE PATIENT_ID='"+patientName+"'");

              while (resultSet.next()){

                  int id =  resultSet.getInt("PATIENT_ID");
                  String name =  resultSet.getString("PATIENT_NAME");
                  String gender =  resultSet.getString("PATIENT_GENDER");
                  Long num = resultSet.getLong("PATIENT_mobileNo");

                  Patient patient1 = new Patient();

                  patient1.setPatientId(id);
                  patient1.setPatientName(name);
                  patient1.setPatientGender(gender);
                  patient1.setPatientNumber(num);

                  return  patient1;
              }
          }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection1.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }


        return null;
    }

    @Override
    public Patient getPatientDetail(int patientId) {

        Connection connection1 = null;
        try {
            connection1 = connection.connectJdbc();
            Statement statement =  connection1.createStatement();
            ResultSet result =  statement.executeQuery("SELECT * FROM PATIENT WHERE PATIENT_ID='"+patientId+"'");

            while (result.next()){

              int id =   result.getInt("PATIENT_ID");
              String name =   result.getString("PATIENT_NAME");
               String gender =  result.getString("PATIENT_GENDER");
               long num = result.getLong("PATIENT_mobileNO");

               Patient patient = new Patient();
               patient.setPatientId(id);
               patient.setPatientName(name);
               patient.setPatientGender(gender);
               patient.setPatientNumber(num);

                return patient;
            }


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection1.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }

        return null;
    }

    @Override
    public boolean deletePatientDetail(int patientId) {

        Connection connection1 = null;
        try {
             connection1 = connection.connectJdbc();
           Statement statement =  connection1.createStatement();
          int result =  statement.executeUpdate("DELETE FROM PATIENT WHERE PATIENT_ID='"+patientId+"'");

          if (result == 1){

              return  true;
          }
        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {
            try {
                connection1.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }

        return false;
    }
}
