package com.Hospital_Appointment_Booking.Dao.DaoImpl;

import com.Hospital_Appointment_Booking.Dao.HospitalDao;
import com.Hospital_Appointment_Booking.Entity.Hospital;
import com.Hospital_Appointment_Booking.Utility.MyConnection;
import java.sql.*;

public class HospitalDaoImpl implements HospitalDao {

    private MyConnection connection = new MyConnection();
    private  static  Connection  connect;

    @Override
    public Hospital addHospital(Hospital hospital) throws SQLException {

        String addQuery = "INSERT INTO HOSPITAL(Hospital_BranchCode,Hospital_Name,Hospital_Address) VALUE(?,?,?)";
         connect = connection.connectJdbc();
        PreparedStatement statement = connect.prepareStatement(addQuery);
        statement.setInt(1,hospital.getHospitalBranch());
        statement.setString(2, hospital.getHospitalName());
        statement.setString(3, hospital.getHospitalAddress());
        int result = statement.executeUpdate();

        if (result == 1){

           Statement state =  connect.createStatement();
          ResultSet resultSet = state.executeQuery("SELECT * FROM HOSPITAL WHERE HOSPITAL_BranchCode='"+hospital.getHospitalBranch()+"'");

          while (resultSet.next()){
            int id =  resultSet.getInt("HOSPITAL_ID");
            int branch = resultSet.getInt("HOSPITAL_BranchCode");
            String name= resultSet.getString("HOSPITAL_NAME");
            String add = resultSet.getString("HOSPITAL_ADDRESS");

            hospital.setHospitalId(id);
            hospital.setHospitalBranch(branch);
            hospital.setHospitalName(name);
            hospital.setHospitalAddress(add);
          }
          return hospital;
        }

        return null;
    }

    @Override
    public Hospital updateHospital(int branchId, Hospital hospital) throws SQLException {

        String query = "UPDATE HOSPITAL SET HOSPITAL_ADDRESS=(?) WHERE HOSPITAL_BranchCode=(?) ";
         connect = connection.connectJdbc();
        PreparedStatement statement =   connect.prepareStatement(query);
        statement.setString(1,hospital.getHospitalAddress());
        statement.setInt(2,branchId);
        int result = statement.executeUpdate();

        if (result == 1){

              Statement statement1 =  connect.createStatement();
              ResultSet resultSet =  statement1.executeQuery("SELECT * FROM HOSPITAL WHERE HOSPITAL_ID='"+branchId+"'");

              while (resultSet.next()){

              int id = resultSet.getInt("HOSPITAL_ID");
              int branch = resultSet.getInt("HOSPITAL_BranchCode");
              String hName = resultSet.getString("HOSPITAL_NAME");
              String hAddress = resultSet.getString("HOSPITAL_ADDRESS");

              hospital.setHospitalId(id);
              hospital.setHospitalBranch(branch);
              hospital.setHospitalName(hName);
              hospital.setHospitalAddress(hAddress);

              return  hospital;

              }
        }

        return null;
    }

    @Override
    public Hospital getHospitalDetails(int branchId) throws SQLException {

        connect = connection.connectJdbc();
      Statement statement =  connect.createStatement();
      ResultSet resultSet = statement.executeQuery("SELECT * FROM HOSPITAL WHERE HOSPITAL_ID='"+branchId+"'");

      while (resultSet.next()){

          int code = resultSet.getInt("HOSPITAL_BranchCode");
          String name = resultSet.getString("HOSPITAL_NAME");
          String address = resultSet.getString("HOSPITAL_ADDRESS");

          Hospital hospital = new Hospital();
          hospital.setHospitalBranch(code);
          hospital.setHospitalName(name);
          hospital.setHospitalAddress(address);

          return hospital;
      }


      return null;
    }

    @Override
    public Boolean deleteHospital(int branchId) throws SQLException {

        connect = connection.connectJdbc();
       Statement statement =  connect.createStatement();
       int result= statement.executeUpdate("DELETE FROM HOSPITAL WHERE HOSPITAL_ID='"+branchId+"' ");

       if (result == 1){

           return true;
       }

        return false;
    }
}
