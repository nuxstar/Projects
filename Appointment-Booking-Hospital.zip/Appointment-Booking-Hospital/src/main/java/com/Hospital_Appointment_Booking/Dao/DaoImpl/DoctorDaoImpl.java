package com.Hospital_Appointment_Booking.Dao.DaoImpl;

import com.Hospital_Appointment_Booking.Dao.DoctorDao;
import com.Hospital_Appointment_Booking.Entity.Doctor;
import com.Hospital_Appointment_Booking.Utility.MyConnection;
import com.Hospital_Appointment_Booking.expection.AppException;
import com.Hospital_Appointment_Booking.expection.NotFoundException;

import java.sql.*;
import java.util.Scanner;

public class DoctorDaoImpl implements DoctorDao {

    private MyConnection myConnection = new MyConnection();

    @Override
    public Doctor addDoctor(Doctor doctor, int hospitalId) throws AppException{

        /**
         *  check hosiptal exists or not based on id;
         *  if id exists -> success add doctor.
         *  if not throw hospital not found ex.
         */

        String checkHospitalQuery = "SELECT * FROM HOSPITAL WHERE HOSPITAL_ID = '"+hospitalId+"'";
        String addDoctorQuery = "INSERT INTO DOCTOR(DOCTOR_NAME,Specialization) VALUE(?,?)";

        Statement statement;
        PreparedStatement preparedStatement;
        try (Connection connection = myConnection.connectJdbc();
             Scanner sc = new Scanner(System.in)){
            statement = connection.createStatement();
            ResultSet hospitalResultSet = statement.executeQuery(checkHospitalQuery);
            if(!hospitalResultSet.next()){
                throw new NotFoundException("Hospital not found");
            }
            preparedStatement = connection.prepareStatement(addDoctorQuery);
            preparedStatement.setString(1, doctor.getDoctorName());
            preparedStatement.setString(2, doctor.getDoctorSpecialization());
            int result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }

        return null;
    }

    @Override
    public Doctor updateDoctorDetail(int doctorId, Doctor doctor) {

        String updateQuery = " UPDATE DOCTOR SET DOCTOR_NAME = (?), Specialization = (?) WHERE DOCTOR_ID =(?)";

        Connection connection = null;
        PreparedStatement preparedStatement;
        try {
             connection = myConnection.connectJdbc();
             preparedStatement =   connection.prepareStatement(updateQuery);
             preparedStatement.setString(1, doctor.getDoctorName());
             preparedStatement.setString(2, doctor.getDoctorSpecialization());
            preparedStatement.setInt(3,doctorId);
            int result =  preparedStatement.executeUpdate();


             Statement statement = connection.createStatement();
             ResultSet set =  statement.executeQuery("SELECT * FROM DOCTOR WHERE DOCTOR_ID ='"+doctorId+"'");

             if (!set.next())
             {
                 throw new NotFoundException("Update Details Invalid");
             }

             while (set.next()){

               int id  = set.getInt("DOCTOR_ID");
               String name = set.getString("DOCTOR_NAME");
               String spec = set.getString("Specialization");

               doctor.setDoctorId(id);
               doctor.setDoctorName(name);
               doctor.setDoctorSpecialization(spec);

                 return  doctor;
             }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {

            try {
                connection.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }

        return null;
    }

    @Override
    public Doctor getDoctorDetail(int doctorId) {


        Connection connection = null;
        Statement statement;

        try {
            connection =   myConnection.connectJdbc();
            statement =  connection.createStatement();
           ResultSet resultSet = statement.executeQuery("SELECT * FROM DOCTOR WHERE DOCTOR_ID='"+doctorId+"'");

            if (!resultSet.next())
            {
                throw new NotFoundException("Get Details Invalid");
            }

           while (resultSet.next()){

              int id = resultSet.getInt("DOCTOR_ID");
              String name = resultSet.getString("DOCTOR_NAME");
              String spec = resultSet.getString("SPECIALIZATION");

              Doctor doctor = new Doctor();
              doctor.setDoctorId(id);
              doctor.setDoctorName(name);
              doctor.setDoctorSpecialization(spec);

               return  doctor;
           }


        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
            finally {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }

        return null;
    }

    @Override
    public Boolean deleteDoctorDetail(int doctorId) {

        Connection connection = null;
        Statement statement;
        try {
             connection =  myConnection.connectJdbc();
            statement =  connection.createStatement();
          int resultSet =   statement.executeUpdate("DELETE FROM DOCTOR WHERE DOCTOR_ID='"+doctorId+"'");

          if (resultSet==1){

              return true;
          }

        } catch (SQLException e) {
            throw new AppException(e.getMessage());
        }
        finally {

            try {
                connection.close();
            } catch (SQLException e) {
                throw new AppException(e.getMessage());
            }
        }

        return false;
    }

}
