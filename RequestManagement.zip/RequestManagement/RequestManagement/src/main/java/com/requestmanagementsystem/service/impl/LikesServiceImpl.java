package com.requestmanagementsystem.service.impl;

import com.requestmanagementsystem.dto.LikesDto;
import com.requestmanagementsystem.dto.TicketDto;
import com.requestmanagementsystem.entity.Likes;
import com.requestmanagementsystem.exception.NotFoundException;
import com.requestmanagementsystem.repository.LikesRepository;
import com.requestmanagementsystem.repository.TicketRepository;
import com.requestmanagementsystem.repository.UserRepository;
import com.requestmanagementsystem.service.LikesService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LikesServiceImpl implements LikesService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    TicketRepository ticketRepository;

    @Autowired
    LikesRepository likesRepository;

    @Autowired
    ModelMapper modelMapper;

    @Override
    public LikesDto addLike(int userId, int ticketId, LikesDto likesDto) {
        userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        ticketRepository.findById(ticketId).orElseThrow(() -> new NotFoundException("Ticket Not Found"));
        Likes likeRequest = modelMapper.map(likesDto, Likes.class);
        Likes likeResponse = likesRepository.save(likeRequest);
        return modelMapper.map(likeResponse, LikesDto.class);
    }
}
