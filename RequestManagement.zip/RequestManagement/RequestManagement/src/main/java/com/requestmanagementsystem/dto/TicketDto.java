package com.requestmanagementsystem.dto;

import com.requestmanagementsystem.entity.PriorityLevel;
import com.requestmanagementsystem.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The TicketDto entity
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TicketDto {

    private int ticketId;
    private String ticketTitle;
    private String ticketDescription;
    private int ticketLikeCount;
    @Enumerated(EnumType.STRING)
    private PriorityLevel priorityLevel;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private User user;
}
