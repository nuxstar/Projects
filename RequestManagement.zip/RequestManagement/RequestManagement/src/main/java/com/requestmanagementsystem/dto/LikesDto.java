package com.requestmanagementsystem.dto;

import com.requestmanagementsystem.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The LikeDto entity
 */

@Data
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorColumn(name = "like_type")
public class LikesDto {

    private int likeId;
    private User user;
}
