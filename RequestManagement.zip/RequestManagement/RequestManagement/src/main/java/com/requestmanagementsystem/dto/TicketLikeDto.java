package com.requestmanagementsystem.dto;

import com.requestmanagementsystem.entity.Ticket;
import jakarta.persistence.*;
import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue(value = "ticket")
public class TicketLikeDto extends LikesDto{

    private Ticket ticket;

}
