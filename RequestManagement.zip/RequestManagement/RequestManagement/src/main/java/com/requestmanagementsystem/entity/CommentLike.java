package com.requestmanagementsystem.entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue(value = "comment")
public class CommentLike extends Likes {
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private Comment comment;
}