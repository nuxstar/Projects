package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The UserRepository
 */
@Repository
public interface UserRepository extends JpaRepository<User,Integer> {
}
