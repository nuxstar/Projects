package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The TicketRepository
 */
@Repository
public interface TicketRepository extends JpaRepository<Ticket,Integer> {
}
