package com.requestmanagementsystem.dto;
/**
 * The PriorityLevelDto entity
 */
public enum PriorityLevelDto {
    CRITICAL,
    HIGH,
    NORMAL;

}
