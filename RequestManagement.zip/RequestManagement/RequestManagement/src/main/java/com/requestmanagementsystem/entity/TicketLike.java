package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue(value = "ticket")
public class TicketLike extends Likes {
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private Ticket ticket;
}
