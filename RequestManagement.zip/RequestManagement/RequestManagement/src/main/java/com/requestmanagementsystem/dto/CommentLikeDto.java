package com.requestmanagementsystem.dto;

import com.requestmanagementsystem.entity.Comment;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue(value = "comment")
public class CommentLikeDto extends LikesDto{

    private Comment comment;
}
