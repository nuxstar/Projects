package com.requestmanagementsystem.controller;

public class LikesController {
}
