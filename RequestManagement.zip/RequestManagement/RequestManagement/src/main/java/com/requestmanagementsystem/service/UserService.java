package com.requestmanagementsystem.service;

import com.requestmanagementsystem.dto.UserDto;
import org.springframework.stereotype.Service;

@Service
public interface UserService{
    /**
     * Add User details
     * @param userDto UserDto
     * @return User details
     */
    UserDto addUser(UserDto userDto);
}
