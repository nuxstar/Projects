package com.requestmanagementsystem.repository;

import com.requestmanagementsystem.entity.Likes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The LikesRepository
 */
@Repository
public interface LikesRepository extends JpaRepository<Likes,Integer> {
}
