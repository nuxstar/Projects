package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * The Ticket entity
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ticketId;
    private String ticketTitle;
    private String ticketDescription;
    private int ticketLikeCount;
    @Enumerated(EnumType.STRING)
    private PriorityLevel priorityLevel;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private User user;
}
