package com.requestmanagementsystem.service.impl;

import com.requestmanagementsystem.dto.TicketDto;
import com.requestmanagementsystem.entity.Ticket;
import com.requestmanagementsystem.entity.User;
import com.requestmanagementsystem.exception.NotFoundException;
import com.requestmanagementsystem.repository.TicketRepository;
import com.requestmanagementsystem.repository.UserRepository;
import com.requestmanagementsystem.service.TicketService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketServiceImpl implements TicketService {

    @Autowired
    TicketRepository ticketRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ModelMapper modelMapper;


    @Override
    public TicketDto addTicket(int userId, TicketDto ticketDto) {
        userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User Need To SignUp"));
        User user = userRepository.findById(userId).get();
        Ticket ticketRequest = modelMapper.map(ticketDto, Ticket.class);
        ticketRequest.setUser(user);
        Ticket ticketResponse = ticketRepository.save(ticketRequest);
        return modelMapper.map(ticketResponse, TicketDto.class);
    }

    @Override
    public Boolean deleteTicket(int ticketId) {
        
        ticketRepository.findById(ticketId).orElseThrow(() -> new NotFoundException("Ticket Not Found"));
        ticketRepository.deleteById(ticketId);
        return true;
    }
}
