package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * The Comment entity
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "commentId", nullable = false)
    private int commentId;
    private int commentLikeCount;
    private String commentDescription;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private User user;


}
