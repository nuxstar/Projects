package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * The Like entity
 */
@Entity
@Getter
@Setter
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorColumn(name = "like_type")
public abstract class Likes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "likeId", nullable = false)
    private int likeId;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private User user;
}
