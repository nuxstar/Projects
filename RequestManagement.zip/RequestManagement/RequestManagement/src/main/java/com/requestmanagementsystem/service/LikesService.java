package com.requestmanagementsystem.service;

import com.requestmanagementsystem.dto.LikesDto;
import com.requestmanagementsystem.dto.TicketDto;
import org.springframework.stereotype.Service;

/**
 * The like service
 */
public interface LikesService {

    /**
     * Add like
     * @param userId userId
     * @param ticketId ticketId
     * @param likesDto ticketDto
     * @return add like
     */
    LikesDto addLike(int userId, int ticketId,LikesDto likesDto);

}
