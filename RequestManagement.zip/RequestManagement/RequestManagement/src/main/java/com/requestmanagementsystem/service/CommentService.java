package com.requestmanagementsystem.service;

import com.requestmanagementsystem.dto.CommentDto;

public interface CommentService {

    /**
     *Add comment.
     *
     * @param userId userId
     * @param commentDto commentDto
     * @return comment message
     */
    CommentDto addComment(int userId,int ticketId,CommentDto commentDto);

    /**
     *Delete comment details .
     *
     * @param commentId commentId
     * @return delete comment
     */
    Boolean deleteComment(int commentId);
}
