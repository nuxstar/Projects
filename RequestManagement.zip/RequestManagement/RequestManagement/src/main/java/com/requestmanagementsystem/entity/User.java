package com.requestmanagementsystem.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * The User entity
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    private String userName;
    private String userEmail;
}
