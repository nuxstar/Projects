package com.requestmanagementsystem.service;

import com.requestmanagementsystem.dto.TicketDto;
import com.requestmanagementsystem.entity.Ticket;

/**
 * The ticket service
 */
public interface TicketService {

    /**
     * Add ticket details.
     *
     * @param userId userID
     * @param ticket ticket
     * @return ticket details
     */
    TicketDto addTicket(int userId, TicketDto ticketDto);

    Boolean deleteTicket(int ticketId);
}
